# Open-source research notes

The project was scoped against public Minecraft cosmetic-mod examples:

- `coding-jona/buildmc-cosmetics` (MIT): https://github.com/coding-jona/buildmc-cosmetics — a newer-version crystal-wing implementation. Its MIT license permits reuse with attribution, but it targets Minecraft 1.21.11 and uses a more involved mesh/renderer implementation. No code from it is copied into this 1.21.4 build.
- `Zik9k/fabric-cosmetics-mod`: https://github.com/Zik9k/fabric-cosmetics-mod — describes hats/capes/wings for 1.21.4, but the repository metadata did not declare an open-source license. Its code was not reused.

BAROX VS therefore implements its effects independently. Since v005 it does not use the game's particle system at all (see below). Before importing code from another project, its license and version compatibility must be checked.

## 3D cosmetics (v004)
The 3D models (wings, halo, crown, horns, ears, tail, visor, cape, jetpack, gyro rings, orbit orbs, drone,
hologram, floor rune) are generated procedurally in `WingModels`, `CosmeticModels` and `FloatModels` as plain
quad meshes (`Mesh`), then drawn by `CosmeticFeature` / `MeshRenderer` as one more Fabric feature renderer on the
player model. No model files, textures (other than a 4x4 white pixel texture) or code from other projects are used.

## Effects without particles (v005)
`FxShapes` (shape library), `FxEngine` (simulation of orbiting shapes, glints, atmosphere, trails, ribbons,
lightning, the swing bounce) and `FxSky` (the aura sky dome) generate plain coloured quads into a `Mesh`;
`FxRenderer` draws them once per frame from Fabric's `WorldRenderEvents.AFTER_TRANSLUCENT` with the
`position_color` shader (alpha pass, then an additive glow pass; depth writes off). The settings window runs
the same engine for its live preview. No particle class, `addParticle` call or particle texture is used.
