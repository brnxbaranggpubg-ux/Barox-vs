# BAROX VS — v005

Minecraft Java 1.21.4 • Fabric • Java 21

A client-side **visuals** mod: a fully customizable cyber-glass ClickGUI, **14 real 3D cosmetics**
(wings, halo, crown, horns, ears, tail, visor, cape, jetpack, gyro rings, orbit orbs, drone, hologram,
floor rune), **effects and trails drawn by the mod itself**, an **aura sky** and HUD widgets. No cheats — see
[Scope](#scope).

**New in v005 — no vanilla particles at all.** Every glint, atmosphere, trail and aura is our own geometry
(coloured quads, drawn in the world), so everything is sized, coloured and shaped by you:
- **Shapes around you** (squares, cubes, diamonds, triangles, rings, stars, crosses, hearts, hexagons, shards,
  orbs, petals, notes, flames) circle your player — and **spring back when you swing at the air**.
- **Aura Sky** recolours the sky (aurora, gradient, nebula, neon grid, portal rings) with stars and ribbons.
- Effects, trails and the sky have a **live preview** in their settings window (with a *Swing* / *Jump* test button).

> **Kısa özet (TR):** Sağ Shift ile menüyü aç. Bir satıra sol tık = aç/kapat, sağ tık (veya sağdaki ayar
> ikonu) = o modülün **ayar penceresi**. Kanatların rengi, boyutu, çırpma hızı, parlaklığı... her şey orada
> ayarlanır; 3D önizleme canlı güncellenir. Ayarlar `config/baroxvs.json` dosyasına kaydedilir.

## ClickGUI (Right Shift)
Six glass columns — **Cosmetics, Effects, Trails, HUD, Misc, Themes** — with an `Ara...` search bar that
filters every column while you type. Enabled modules get an accent bar and a small colour dot.

- **Left click** a row: switch the module on / off.
- **Right click**, or the small sliders icon on the row: open the module's **settings window**.
- Mouse wheel or drag: scroll a column. The whole menu scales down on small screens / high GUI scale.
- Hover a row for a short description.

### Settings window (every option is editable)
| Control | How it works |
| --- | --- |
| Colour | Click the swatch: saturation/brightness box, hue bar, `#hex` field, preset swatches, and two chips — **Theme** (follow the menu theme) and **Rainbow** (animated) |
| Slider | Drag, or use the arrows for fine steps (size, spread, flap speed, opacity, glow, radius, amount ...) |
| Choice | Chips (wing design, animation mode, effect shape, trigger ...) |
| Text | Click and type (ticker text, music title/artist) |
| Reset | Right click any single control to reset just that one; the **Reset** button restores the whole module |
| Preview | Cosmetics show a live 3D preview next to a mannequin; effects, trails and the sky show a **live preview** of the real effect (walking / swinging / jumping mannequin) — drag to rotate, wheel to zoom |

Example: *Wings → Main color = red, Size = 1.4, Flap speed = 0.6, Glow = high.*

### Themes
Cyber Blue, Olive, Violet Void, Sunset, Neon Green, Abyss Blue, Sakura, Cyber Dragon, Aurora, Matrix,
Hellfire, Mint Pulse, plus **Custom** (right click it to edit its colours). The theme tints the GUI and every
HUD widget; any colour option can follow it with the **Theme** chip.

## 3D cosmetics (Cosmetics column)
Real 3D models drawn on your own player — visible in third-person view and in the inventory preview (the
vanilla game does not draw your own body in first person) — generated procedurally in Java, no external assets. Each one has its own design list, colours, size, glow, opacity and animation options.

| Cosmetic | Designs / shapes |
| --- | --- |
| Wings | Cyber, Angel, Dragon, Butterfly, Bat, Crystal, Mech, Fairy, Phoenix, Pixel (18 options: colours, size, spread, flap speed/amount, thickness, opacity, glow, feathers, height, distance, animation, fullbright, hide with elytra, tip sparkles) |
| Halo | Ring, Double, Spiky, Hex |
| Crown | Royal, Spikes, Flame, Cyber (+ gem colour) |
| Horns | Devil, Unicorn, Ram, Spikes |
| Ears | Cat, Fox, Bunny, Wolf |
| Tail | Fox, Dragon, Cyber, Devil (wave speed / amount) |
| Visor | Cyber, Shades, Mask, Monocle (scan line) |
| Cape | Flowing, Short, Hologram |
| Jetpack | Twin Jet, Single, Cube (animated flame shapes) |
| Gyro Rings | 1–4 spinning rings |
| Orbit Orbs | Orb, Cube, Diamond, Star, Crystal |
| Drone | Drone, Orb, Cube, Ring |
| Hologram | Cube, Octahedron, Diamond (+ inner shape) |
| Floor Rune | Magic Circle, Ring, Hex, Radar |

The mod is client side: nobody else sees your cosmetics, and cosmetics are only ever drawn on your own player.

## Effects and trails (no vanilla particles)
Everything below is built from our own shapes (`FxShapes`) and simulated by `FxEngine`; the mod never calls the
game's particle system. Every effect has colour, second colour, size, amount, glow and its own options.

- **Effects (14):** Orbit Shapes, Aura Ring, Glints, Atmosphere (motes, snow, embers, fireflies, rain, bubbles, leaves, digital rain),
  Hand Glow, Slash Trail, Shoulder Wisp, Lightning, Helix Swirl, Flames, Rune Glyphs, Rain Cloud, Energy Beam,
  **Aura Sky**.
- **Trails (11):** Footsteps, Jump Burst, Landing Shockwave, Glint Trail, Heart, Bubble, Note, Flame, Rainbow,
  Cherry and Wing trail.
- **Shapes:** Square, Cube, Diamond, Triangle, Ring, Star, Cross, Heart, Hexagon, Shard, Orb, Petal, Note, Flame.

### Orbit Shapes — bounce back when you hit the air
Shapes circle your player in up to 3 rings. When you **swing at the air** (no block or mob under the crosshair)
they are pushed away and a spring brings them back, overshooting a little. Options: shape, colours, count, rings,
radius, height, size, speed, spin, wave, fill, glow, neon outline, 3D tumble, orbit path, **Bounce on** (air swing /
any swing / entity hit / jump / never), **Reaction** (push out / pull in / swing direction / scatter), bounce
strength, return speed and elasticity.

### Aura Sky
A dome of our own geometry around the camera at the far edge of the view (terrain hides it): **Aurora** (curtains), **Gradient**,
**Nebula**, **Cyber Grid** or **Portal Rings**, with stars and ribbons. Options: three colours, opacity, glow,
speed, aurora height, ribbons, stars, horizon glow, *when* (always / night / day) and *dimension* (overworld only
or everywhere). It is a tint over the real sky, not a replacement of the game's sky pass.

### Effects Quality (Misc)
Global amount, size and opacity multipliers, density preset, maximum number of shapes, distance fade and whether
effects are drawn in first person. Lower them first if you need more FPS.

## HUD widgets
| Widget | What it shows |
| --- | --- |
| Info Panel | FPS, direction, biome, ping, clock — each line is its own switch |
| Coordinates | Your XYZ in a compact pill |
| Speed | Your own blocks-per-second with a small graph |
| Potions List | Your active effects and remaining time |
| KeyBinds | The BAROX keybinds, enabled modules highlighted |
| Armor HUD | Durability of the armor you wear |
| Top Bar | Ticker bar with equalizer (custom text) |
| Now Playing | Decorative music card (**display only, no audio**) |
| Target Card | Name, distance and health of the entity under your vanilla crosshair |
| Hit Numbers | Floating damage numbers near the crosshair |
| Crosshair Ring | Ring that fills with your attack cooldown |
| Toasts | `Enabled X` / `Disabled X` notifications |

`HUD Layout` sets the HUD scale, panel opacity and the corner of the Info Panel; `Menu Style` changes the
menu's opacity, cyber grid and animations.

## Controls
| Key | Action |
| --- | --- |
| Right Shift | Open / close the GUI |
| Right Alt | Show / hide the BAROX HUD |
| Z / V / B / N | Wings / Aura Ring / Hand Glow / Aura Sky (rebindable in Controls) |

Settings are saved to `config/baroxvs.json` (only values that differ from the defaults are stored).

## Build
`gradle clean build --no-daemon`

Output: `BAROX-VS-v005.jar`. The GitHub Actions workflow builds it on every push to `main`
(download it from the run's **Artifacts**, or from **Releases**).

### Updating a repo that still has the v004 chunk pipeline
The v004 workflow restored its sources from `source-chunks/*.b64` and deleted `src` first on every run, so it
would keep rebuilding v004. Upload this project **including `.github/workflows/build.yml`**: that file replaces the
old workflow, and the new one removes the old leftovers (`source-chunks`, the old `CosmeticEngine.java`) by itself.
Afterwards the `source-chunks` folder can be deleted from the repo.

## Status
v005 was checked with offline tests (module catalog, config round trips, 3D mesh generation for every
design and slider extreme, the effect engine — including the swing bounce, the sky and a scan that no vanilla
particle class is used —, GUI layout at many window sizes, mouse/keyboard flows) against
API stubs named after the Yarn `1.21.4+build.8` mappings, and every Minecraft class/method/field the mod
uses was cross-checked against those mappings. It has **not** been run inside a real Minecraft client yet —
if the Actions build or the game reports a problem, please include the log.

## Scope
All BAROX modules are local cosmetics, HUD or interface options. This project does not include combat
automation, movement automation, anti-cheat bypasses, packet manipulation, entity ESP or server exploit
features. The Target Card and Hit Numbers only use the entity under the vanilla crosshair; nothing is
shown through walls and nothing is sent to the server. Aura Sky only tints the sky with extra geometry; it does
not change the world or what other players see.

## Open-source research and credits
The feature research reviewed public projects and their documented approaches:
- [BetterF3](https://github.com/TreyRuffy/BetterF3) — MIT; configurable HUD design inspiration.
- [MiniHUD](https://github.com/maruohon/minihud) — LGPL-3.0; configurable information overlays.
- [HudFabric](https://modrinth.com/mod/hudfabric) — MIT; movable HUD module ideas.
- [Particle Effects](https://github.com/LopyMine/Particle-Effects) — visual particle presentation inspiration.
- [Finery](https://www.curseforge.com/minecraft/mc-mods/finery) — MIT; 3D wearable cosmetics reference.
- [Pi's Cosmetics](https://modrinth.com/project/piscosmetics) — MIT; animated cosmetic rendering reference.

No third-party source code or assets are copied into this build; all 3D models are generated in code.
