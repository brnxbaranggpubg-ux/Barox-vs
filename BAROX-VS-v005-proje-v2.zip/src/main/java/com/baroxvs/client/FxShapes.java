package com.baroxvs.client;

/**
 * Every visual of the effects is built from these shapes. They are plain geometry written by this mod (quads in a
 * {@link Mesh}), not vanilla particles: nothing here uses the particle system of the game.
 *
 * <p>Pure Java (no Minecraft types), so the same code draws the effects in the world, in the menu preview and in the
 * offline tests. All shapes are defined with a radius of one and scaled by the caller.
 */
final class FxShapes {
    private FxShapes() {}

    static final String[] NAMES = {"Square", "Cube", "Diamond", "Triangle", "Ring", "Star", "Cross", "Heart",
        "Hexagon", "Shard", "Orb", "Petal", "Note", "Flame"};
    /** Same list with "Auto" in front (the module picks the shape that suits it). */
    static final String[] NAMES_AUTO = {"Auto", "Square", "Cube", "Diamond", "Triangle", "Ring", "Star", "Cross", "Heart",
        "Hexagon", "Shard", "Orb", "Petal", "Note", "Flame"};

    static final int SQUARE = 0, CUBE = 1, DIAMOND = 2, TRIANGLE = 3, RING = 4, STAR = 5, CROSS = 6, HEART = 7,
            HEXAGON = 8, SHARD = 9, ORB = 10, PETAL = 11, NOTE = 12, FLAME = 13;
    /** Internal only (not in the shape lists): rune glyphs, and a plain soft glow dot. */
    static final int GLYPH = 100, DOT = 101;

    /** Shape for a choice index of a list that starts with "Auto". */
    static int resolve(int choice, int auto) { return choice <= 0 ? auto : Math.min(NAMES.length - 1, choice - 1); }

    /** The camera's axes (right, up, forward) in world space; flat shapes use them to face the viewer. */
    static final class Cam {
        float rx = -1f, ry, rz, ux, uy = 1f, uz, fx, fy, fz = 1f;

        /** Minecraft convention: yaw 0 looks along +Z, yaw 90 along -X, positive pitch looks down. */
        void set(float yawDeg, float pitchDeg) {
            double yaw = Math.toRadians(yawDeg), pitch = Math.toRadians(pitchDeg);
            double cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
            fx = (float) (-sy * cp);
            fy = (float) -sp;
            fz = (float) (cy * cp);
            rx = (float) -cy;
            ry = 0f;
            rz = (float) -sy;
            ux = ry * fz - rz * fy;
            uy = rz * fx - rx * fz;
            uz = rx * fy - ry * fx;
        }
    }

    // ---------------------------------------------------------------- outlines (star shaped around the origin)

    private static final float[] SQUARE_P = {-1f, -1f, 1f, -1f, 1f, 1f, -1f, 1f};
    private static final float[] TRIANGLE_P = regular(3, 90f);
    private static final float[] HEXAGON_P = regular(6, 0f);
    private static final float[] STAR_P = star(4, 1f, 0.28f);
    private static final float[] CROSS_P = {0.34f, 1f, -0.34f, 1f, -0.34f, 0.34f, -1f, 0.34f, -1f, -0.34f, -0.34f, -0.34f,
        -0.34f, -1f, 0.34f, -1f, 0.34f, -0.34f, 1f, -0.34f, 1f, 0.34f, 0.34f, 0.34f};
    private static final float[] HEART_P = heart(22);
    private static final float[] PETAL_P = {0f, 1f, -0.62f, 0.2f, -0.4f, -0.65f, 0f, -1f, 0.4f, -0.65f, 0.62f, 0.2f};

    private static float[] regular(int n, float startDeg) {
        float[] out = new float[n * 2];
        for (int i = 0; i < n; i++) {
            double a = Math.toRadians(startDeg) + i * 2 * Math.PI / n;
            out[i * 2] = (float) Math.cos(a);
            out[i * 2 + 1] = (float) Math.sin(a);
        }
        return out;
    }

    private static float[] star(int points, float outer, float inner) {
        float[] out = new float[points * 4];
        for (int i = 0; i < points * 2; i++) {
            double a = Math.PI / 2 + i * Math.PI / points;
            float r = (i & 1) == 0 ? outer : inner;
            out[i * 2] = (float) (Math.cos(a) * r);
            out[i * 2 + 1] = (float) (Math.sin(a) * r);
        }
        return out;
    }

    private static float[] heart(int n) {
        float[] out = new float[n * 2];
        for (int i = 0; i < n; i++) {
            double t = Math.PI / 2 + i * 2 * Math.PI / n;
            double x = 16 * Math.pow(Math.sin(t), 3);
            double y = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t);
            out[i * 2] = (float) (x / 17.0);
            out[i * 2 + 1] = (float) (y / 17.0 + 0.15);
        }
        return out;
    }

    // ---------------------------------------------------------------- colour helpers

    /** 0xRRGGBB plus an alpha between 0 and 1 to ARGB. */
    static int argb(int rgb, float alpha) {
        int a = Math.max(0, Math.min(255, Math.round(alpha * 255f)));
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    /** Blend of two 0xRRGGBB colours. */
    static int mix(int rgb0, int rgb1, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = Math.round(Colors.r(rgb0) + (Colors.r(rgb1) - Colors.r(rgb0)) * t);
        int g = Math.round(Colors.g(rgb0) + (Colors.g(rgb1) - Colors.g(rgb0)) * t);
        int b = Math.round(Colors.b(rgb0) + (Colors.b(rgb1) - Colors.b(rgb0)) * t);
        return (r << 16) | (g << 8) | b;
    }

    /** Brighter version of a colour (for outlines and cores). */
    static int light(int rgb, float t) { return mix(rgb, 0xFFFFFF, t); }

    static boolean isFlat(int shape) {
        return shape != CUBE && shape != DIAMOND && shape != SHARD && shape != ORB && shape != FLAME;
    }

    // ---------------------------------------------------------------- drawing

    /**
     * Draws one shape.
     *
     * @param s       radius in blocks
     * @param rx,ry,rz Euler angles (radians). Flat shapes that face the camera only use rz (their spin).
     * @param tumble  flat shapes turn freely in 3D instead of facing the camera
     * @param rgb0    main colour (0xRRGGBB), rgb1 the second colour (outline, tips, gradients)
     * @param alpha   overall opacity 0..1 (already includes every fade)
     * @param fill    opacity of the faces relative to alpha (0 = outline only)
     * @param glow    strength of the soft halo behind the shape (0 = none)
     * @param seed    random number per shape (rune glyphs)
     */
    static void draw(Mesh m, Cam cam, int shape, float x, float y, float z, float s, float rx, float ry, float rz,
                     boolean tumble, int rgb0, int rgb1, float alpha, float fill, boolean outline, float glow, float seed) {
        if (alpha <= 0.01f || s <= 0.0005f) return;
        int fillC = argb(rgb0, alpha * fill);
        int fillE = argb(rgb1, alpha * fill * 0.75f);
        int edgeC = argb(light(rgb1, 0.35f), alpha);
        int coreC = argb(light(rgb0, 0.5f), alpha);
        m.push();
        m.translate(x, y, z);
        if (isFlat(shape) && !tumble) {
            m.basis(cam.rx, cam.ry, cam.rz, cam.ux, cam.uy, cam.uz, cam.fx, cam.fy, cam.fz);
        } else {
            m.rotY(ry);
            m.rotX(rx);
        }
        m.rotZ(rz);
        m.scale(s, s, s);
        switch (shape) {
            case SQUARE -> polygon(m, SQUARE_P, fillC, fillE, edgeC, outline, 0.16f);
            case TRIANGLE -> polygon(m, TRIANGLE_P, fillC, fillE, edgeC, outline, 0.2f);
            case HEXAGON -> polygon(m, HEXAGON_P, fillC, fillE, edgeC, outline, 0.16f);
            case STAR -> polygon(m, STAR_P, coreC, fillE, edgeC, outline && fill > 0.05f, 0.1f);
            case CROSS -> polygon(m, CROSS_P, coreC, fillE, edgeC, outline && fill > 0.05f, 0.12f);
            case HEART -> polygon(m, HEART_P, fillC, fillE, edgeC, outline, 0.14f);
            case PETAL -> polygon(m, PETAL_P, fillC, fillE, edgeC, outline, 0.14f);
            case RING -> annulus(m, Mesh.GLOW, 0.62f, 1f, 18, argb(rgb0, alpha), argb(rgb1, alpha * 0.8f));
            case NOTE -> note(m, argb(rgb0, alpha), edgeC);
            case GLYPH -> glyph(m, seed, edgeC, argb(rgb0, alpha));
            case DOT -> { }
            case CUBE -> cube(m, fillC, fillE, edgeC, outline);
            case DIAMOND -> m.bipyramid(Mesh.SOLID, 0.62f, 1f, 1f, 4, argb(rgb1, alpha * Math.max(0.5f, fill)),
                argb(rgb0, alpha * Math.max(0.5f, fill)), argb(light(rgb0, 0.25f), alpha * Math.max(0.5f, fill)));
            case SHARD -> m.bipyramid(Mesh.SOLID, 0.3f, 1.7f, 1f, 4, argb(rgb1, alpha), argb(rgb0, alpha),
                argb(light(rgb0, 0.3f), alpha));
            case ORB -> m.sphere(Mesh.GLOW, 0.55f, s > 0.12f ? 1 : 0, argb(light(rgb0, 0.55f), alpha), argb(rgb0, alpha * 0.85f)); // small orbs need few faces
            case FLAME -> flame(m, argb(light(rgb0, 0.25f), alpha), argb(rgb0, alpha * 0.9f), argb(rgb1, 0f), argb(rgb1, alpha * 0.55f));
            default -> polygon(m, SQUARE_P, fillC, fillE, edgeC, outline, 0.16f);
        }
        m.pop();
        if (glow > 0.01f) {
            m.push();
            m.translate(x, y, z);
            m.basis(cam.rx, cam.ry, cam.rz, cam.ux, cam.uy, cam.uz, cam.fx, cam.fy, cam.fz);
            if (shape == DOT) halo(m, s * 3f, argb(rgb0, Math.min(1f, alpha * glow)));
            else halo(m, s * (shape == ORB || shape == STAR ? 3.2f : 2.4f), argb(rgb0, Math.min(1f, alpha * glow * 0.55f)));
            m.pop();
        }
    }

    /** Soft round glow disc in the local XY plane (additive layer). */
    static void halo(Mesh m, float radius, int argbCenter) {
        int rim = argbCenter & 0xFFFFFF;
        int seg = 10;
        for (int i = 0; i < seg; i++) {
            double a0 = i * 2 * Math.PI / seg, a1 = (i + 1) * 2 * Math.PI / seg;
            m.tri(Mesh.HALO, 0f, 0f, 0f, (float) Math.cos(a0) * radius, (float) Math.sin(a0) * radius, 0f,
                (float) Math.cos(a1) * radius, (float) Math.sin(a1) * radius, 0f, argbCenter, rim, rim);
        }
    }

    /** Flat ring in the local XY plane; cA is the colour at the inner edge and cB at the outer edge. */
    static void annulus(Mesh m, int lyr, float inner, float outer, int seg, int cA, int cB) {
        annulusArc(m, lyr, inner, outer, seg, 0f, (float) (Math.PI * 2), cA, cB);
    }

    static void annulusArc(Mesh m, int lyr, float inner, float outer, int seg, float start, float length, int cA, int cB) {
        for (int i = 0; i < seg; i++) {
            float a0 = start + length * i / seg, a1 = start + length * (i + 1) / seg;
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            m.quad(lyr, c0 * inner, s0 * inner, 0f, c1 * inner, s1 * inner, 0f, c1 * outer, s1 * outer, 0f,
                c0 * outer, s0 * outer, 0f, cA, cA, cB, cB);
        }
    }

    // ---------------------------------------------------------------- shape bodies

    /** Filled polygon (fan from the centre) with an optional bright frame along the edge. */
    private static void polygon(Mesh m, float[] p, int fillCenter, int fillEdge, int edge, boolean outline, float edgeWidth) {
        int n = p.length / 2;
        if (((fillCenter | fillEdge) >>> 24) > 0) {
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                m.tri(Mesh.GLOW, 0f, 0f, 0f, p[i * 2], p[i * 2 + 1], 0f, p[j * 2], p[j * 2 + 1], 0f, fillCenter, fillEdge, fillEdge);
            }
        }
        if (outline && (edge >>> 24) > 0) {
            float k = 1f - edgeWidth;
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                m.quad(Mesh.GLOW, p[i * 2], p[i * 2 + 1], 0f, p[j * 2], p[j * 2 + 1], 0f, p[j * 2] * k, p[j * 2 + 1] * k, 0f,
                    p[i * 2] * k, p[i * 2 + 1] * k, 0f, edge);
            }
        }
    }

    private static void cube(Mesh m, int face, int faceEdge, int edge, boolean outline) {
        m.box(Mesh.SOLID, 0f, 0f, 0f, 1.15f, 1.15f, 1.15f, face);
        if (outline && (edge >>> 24) > 0) {
            // a faint fullbright shell a bit larger than the cube gives it the neon edge look
            m.box(Mesh.GLOW, 0f, 0f, 0f, 1.24f, 1.24f, 1.24f, (edge & 0xFFFFFF) | (((edge >>> 24) / 4) << 24));
        }
    }

    private static void note(Mesh m, int body, int edge) {
        int seg = 8;
        for (int i = 0; i < seg; i++) {
            double a0 = i * 2 * Math.PI / seg, a1 = (i + 1) * 2 * Math.PI / seg;
            m.tri(Mesh.GLOW, -0.28f, -0.58f, 0f, -0.28f + (float) Math.cos(a0) * 0.4f, -0.58f + (float) Math.sin(a0) * 0.3f, 0f,
                -0.28f + (float) Math.cos(a1) * 0.4f, -0.58f + (float) Math.sin(a1) * 0.3f, 0f, body, body, body);
        }
        m.quad(Mesh.GLOW, 0.06f, -0.5f, 0f, 0.2f, -0.5f, 0f, 0.2f, 0.95f, 0f, 0.06f, 0.95f, 0f, body);
        m.quad(Mesh.GLOW, 0.2f, 0.95f, 0f, 0.78f, 0.52f, 0f, 0.78f, 0.2f, 0f, 0.2f, 0.5f, 0f, edge, edge, body, body);
    }

    /** A small made-up rune: three strokes between random points of a 3x3 grid (different for every seed). */
    private static void glyph(Mesh m, float seed, int edge, int body) {
        int state = Float.floatToIntBits(seed) * 747796405 + 1013904223;
        int prev = -1;
        for (int i = 0; i < 3; i++) {
            state = state * 1103515245 + 12345;
            int a = prev >= 0 ? prev : ((state >>> 16) & 0x7FFF) % 9;
            state = state * 1103515245 + 12345;
            int b = ((state >>> 16) & 0x7FFF) % 9;
            if (b == a) b = (b + 4) % 9;
            prev = b;
            float ax = (a % 3 - 1) * 0.55f, ay = (a / 3 - 1) * 0.55f, bx = (b % 3 - 1) * 0.55f, by = (b / 3 - 1) * 0.55f;
            float dx = bx - ax, dy = by - ay, len = (float) Math.sqrt(dx * dx + dy * dy);
            if (len < 1e-4f) continue;
            float nx = -dy / len * 0.1f, ny = dx / len * 0.1f;
            m.quad(Mesh.GLOW, ax + nx, ay + ny, 0f, bx + nx, by + ny, 0f, bx - nx, by - ny, 0f, ax - nx, ay - ny, 0f, edge, body, body, edge);
        }
    }

    /** Two crossed flame tongues: hot at the bottom, fading to transparent at the tip. */
    private static void flame(Mesh m, int hot, int warm, int tip, int mid) {
        for (int plane = 0; plane < 2; plane++) {
            m.push();
            m.rotY(plane * (float) (Math.PI / 2));
            m.quad(Mesh.GLOW, -0.2f, -0.95f, 0f, 0.2f, -0.95f, 0f, 0.45f, -0.4f, 0f, -0.45f, -0.4f, 0f, hot, hot, warm, warm);
            m.quad(Mesh.GLOW, -0.45f, -0.4f, 0f, 0.45f, -0.4f, 0f, 0.32f, 0.1f, 0f, -0.32f, 0.1f, 0f, warm, warm, mid, mid);
            m.tri(Mesh.GLOW, -0.32f, 0.1f, 0f, 0.32f, 0.1f, 0f, 0f, 1f, 0f, mid, mid, tip);
            m.pop();
        }
    }
}
