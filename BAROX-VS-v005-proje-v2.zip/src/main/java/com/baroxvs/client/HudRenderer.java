package com.baroxvs.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Draws the BAROX VS HUD widgets. Everything here only reads state the vanilla client already has
 * (your own player, your own effects, the entity under your crosshair) and draws it on screen.
 * Nothing is sent to the server and nothing is changed in the game.
 */
final class HudRenderer {
    private final BaroxConfig cfg;
    private int ticks;
    /** Panel background, follows the HUD Layout opacity. */
    private int panel = Ui.PANEL;
    /** Width of the widest right-column panel drawn this frame (potions / keybinds). */
    private int rightW;

    // speed readout
    private double lastX, lastZ;
    private boolean hasLast;
    private float bps;
    private final float[] history = new float[34];

    // toasts
    private record Toast(String name, boolean enabled, int born) {}
    private final ArrayDeque<Toast> toasts = new ArrayDeque<>();

    // floating hit numbers
    private record Popup(String text, int color, long born, int dx) {}
    private final List<Popup> popups = new ArrayList<>();

    // crosshair target
    private LivingEntity targetRef;
    private float targetPrevHealth;
    private String targetName = "";
    private float targetHealth, targetMax, targetDist;
    private long targetSeenMs;

    HudRenderer(BaroxConfig cfg) {
        this.cfg = cfg;
    }

    // ------------------------------------------------------------------ state

    void toast(String name, boolean enabled) {
        if (!cfg.isOn("toasts")) return;
        while (toasts.size() >= 3) toasts.pollFirst();
        toasts.addLast(new Toast(name, enabled, ticks));
    }

    void tick(MinecraftClient mc) {
        ticks++;
        PlayerEntity p = mc.player;
        if (p == null || mc.world == null) {
            hasLast = false;
            return;
        }
        if (hasLast) {
            double dx = p.getX() - lastX;
            double dz = p.getZ() - lastZ;
            float instant = (float) (Math.sqrt(dx * dx + dz * dz) * 20.0);
            bps += (instant - bps) * 0.35f;
        }
        lastX = p.getX();
        lastZ = p.getZ();
        hasLast = true;
        if (ticks % 2 == 0) {
            System.arraycopy(history, 1, history, 0, history.length - 1);
            history[history.length - 1] = bps;
        }

        if (mc.targetedEntity instanceof LivingEntity le) {
            if (le == targetRef && le.getHealth() < targetPrevHealth - 0.01f && cfg.isOn("hit_numbers")) {
                addPopup(targetPrevHealth - le.getHealth());
            }
            targetRef = le;
            targetPrevHealth = le.getHealth();
            if (le.isAlive()) {
                targetName = le.getName().getString();
                targetHealth = le.getHealth();
                targetMax = Math.max(1f, le.getMaxHealth());
                targetDist = p.distanceTo(le);
                targetSeenMs = System.currentTimeMillis();
            }
        }
    }

    private void addPopup(float damage) {
        String text = damage >= 1f ? Integer.toString(Math.round(damage)) : Ui.num(damage, 1);
        int color = damage >= 6f ? 0xFFFF4D4D : damage >= 3f ? 0xFFFFA43D : 0xFFFFE04A;
        popups.add(new Popup(text, color, System.currentTimeMillis(), ThreadLocalRandom.current().nextInt(-16, 17)));
    }

    // ------------------------------------------------------------------ render

    void render(DrawContext c, MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        if (mc.getDebugHud().shouldShowDebugHud()) return;
        float scale = Math.max(0.5f, Math.min(1.6f, cfg.f("hud_layout", "scale") / 100f));
        int sw = Math.round(mc.getWindow().getScaledWidth() / scale);
        int sh = Math.round(mc.getWindow().getScaledHeight() / scale);
        panel = Ui.alpha(0x0C0D12, Math.round(2.55f * cfg.f("hud_layout", "opacity")));
        MatrixStack matrices = c.getMatrices();
        matrices.push();
        matrices.scale(scale, scale, 1f);
        try {
            draw(c, mc, sw, sh);
        } finally {
            matrices.pop();
        }
    }

    private void draw(DrawContext c, MinecraftClient mc, int sw, int sh) {
        TextRenderer tr = mc.textRenderer;
        Theme th = Themes.current(cfg);

        // Side panels first: their widths decide how much room the centred widgets get.
        int[] info = cfg.isOn("status_bar") ? drawInfoPanel(c, tr, mc, sw, sh, th) : null;
        int pos = cfg.hudPosition();
        boolean infoRight = pos == 1 || pos == 3;
        boolean infoTop = pos == 0 || pos == 1;

        // The right column ends above the Armor HUD (or a bottom-right Info Panel), the left column above
        // the Speed graph (or a bottom-left Info Panel). Panels that do not fit are shortened or left out
        // instead of running off the screen.
        int rightFloor = info != null && !infoTop && infoRight ? info[1] : sh;
        if (cfg.isOn("armor_hud")) rightFloor = Math.min(rightFloor, armorY(sw, sh, rightFloor));
        int rightLimit = rightFloor - 4;
        int leftLimit = cfg.isOn("speed_graph") ? sh / 2 + 2 : (info != null && !infoTop && !infoRight ? info[1] : sh) - 4;

        int ry = info != null && infoTop && infoRight ? info[1] + info[3] + 4 : 6;
        int ly = info != null && infoTop && !infoRight ? info[1] + info[3] + 4 : 4;
        int leftW = info != null && infoTop && !infoRight ? info[2] + 4 : 0;
        rightW = info != null && infoTop && infoRight ? info[2] + 4 : 0;
        if (cfg.isOn("potions_list")) ry = drawPotions(c, tr, mc, sw, ry, rightLimit, th);
        int[] kb = cfg.isOn("keybinds") ? keybindsSize(tr) : null;
        if (kb != null) {
            if (ry + kb[1] <= rightLimit) {
                drawKeybinds(c, tr, sw - kb[0] - 4, ry, kb[0], kb[1], th);
                rightW = Math.max(rightW, kb[0] + 4);
            } else if (ly + kb[1] <= leftLimit) {
                drawKeybinds(c, tr, 4, ly, kb[0], kb[1], th);
                leftW = Math.max(leftW, kb[0] + 4);
            }
        }

        int centerMax = Math.max(110, sw - 2 * (Math.max(leftW, rightW) + 6));
        int y = 4;
        if (cfg.isOn("ticker")) { drawTicker(c, tr, Math.min(264, centerMax), sw, y, th); y += 21; }
        if (cfg.isOn("music_card")) { drawMusic(c, tr, Math.min(148, centerMax), sw, y, th); y += 46; }
        if (cfg.isOn("coordinates")) drawCoords(c, tr, mc, sw, y, th);

        if (cfg.isOn("speed_graph")) drawSpeed(c, tr, 4, sh / 2 + 6, th);
        if (cfg.isOn("armor_hud")) drawArmor(c, tr, mc, sw, sh, info != null && pos == 3 ? info[1] : sh);
        if (cfg.isOn("crosshair_ring")) drawCrosshairRing(c, mc, sw, sh, th);
        if (cfg.isOn("target_card")) drawTarget(c, tr, sw, sh, th);
        if (cfg.isOn("hit_numbers")) drawPopups(c, tr, sw, sh);
        drawToasts(c, tr, sw, sh, th);
    }

    // ------------------------------------------------------------------ top bar

    private void drawTicker(DrawContext c, TextRenderer tr, int limitW, int sw, int y, Theme th) {
        int accent = accent("ticker", "color");
        int w = Math.min(limitW, sw - 16);
        int x = (sw - w) / 2;
        int h = 17;
        Ui.roundRect(c, x, y, x + w, y + h, 6, panel);

        // round badge with a small crescent
        int cx = x + 9, cy = y + 8;
        Ui.circle(c, cx, cy, 6, 0xFF14141B);
        Ui.ring(c, cx, cy, 6, Ui.alpha(accent, 0xB0), 1f);
        Ui.circle(c, cx, cy, 3, accent);
        Ui.circle(c, cx + 1, cy - 1, 2, 0xFF14141B);

        // equalizer bars (optional)
        int left = x + 22;
        if (cfg.flag("ticker", "equalizer")) {
            for (int i = 0; i < 3; i++) {
                int bh = 2 + (int) (Math.abs(Math.sin(ticks * 0.22 + i * 1.9)) * 7);
                int bx = x + 20 + i * 4;
                c.fill(bx, y + 13 - bh, bx + 2, y + 13, accent);
            }
            c.fill(x + 31, y + 4, x + 32, y + 13, 0x33FFFFFF);
            left = x + 36;
        }

        // text: a window of words around the highlighted one
        String text = cfg.text("ticker", "text");
        String[] words = text == null || text.isBlank() ? new String[]{"BAROX", "VS"} : text.trim().split("\s+");
        int hi = (int) (ticks * cfg.num("ticker", "speed") / 9.0) % words.length;
        int avail = (x + w - 8) - left;
        int space = tr.getWidth(" ");
        int start = 0;
        while (start < hi && span(tr, words, start, hi, space) > avail) start++;
        int end = hi;
        while (end + 1 < words.length && span(tr, words, start, end + 1, space) <= avail) end++;
        int tx = left;
        for (int i = start; i <= end; i++) {
            c.drawText(tr, words[i], tx, y + 5, i == hi ? accent : 0xFF8A8F99, false);
            tx += tr.getWidth(words[i]) + space;
        }
    }

    private static int span(TextRenderer tr, String[] words, int from, int to, int space) {
        int total = 0;
        for (int i = from; i <= to; i++) total += tr.getWidth(words[i]) + (i > from ? space : 0);
        return total;
    }

    private int accent(String module, String setting) {
        return 0xFF000000 | cfg.rgb(module, setting, System.currentTimeMillis() / 1000.0, 0);
    }

    private int accent2(String module, String setting, Theme th) {
        if (cfg.num(module, setting) == Setting.COLOR_THEME) return th.secondary();
        return Colors.shade(accent(module, setting), 0.55f);
    }

    private void drawMusic(DrawContext c, TextRenderer tr, int limitW, int sw, int y, Theme th) {
        int w = Math.min(limitW, sw - 16), h = 42;
        int x = (sw - w) / 2;
        Ui.roundRect(c, x, y, x + w, y + h, 5, panel);

        // cover: theme gradient with a music note
        int accent = accent("music_card", "color"), accent2 = accent2("music_card", "color", th);
        c.fillGradient(x + 5, y + 5, x + 37, y + 37, accent, accent2);
        int note = 0xCC0B0B10;
        c.fill(x + 22, y + 12, x + 24, y + 28, note);
        Ui.circle(c, x + 20, y + 28, 3, note);
        c.fill(x + 24, y + 12, x + 29, y + 15, note);

        int tx = x + 43;
        int maxW = w - 43 - 6;
        c.drawText(tr, Ui.fit(tr, cfg.text("music_card", "title"), maxW, 1f), tx, y + 6, Ui.WHITE, false);
        Ui.text(c, tr, Ui.fit(tr, cfg.text("music_card", "artist"), (int) (maxW / 0.8f), 0.8f), tx, y + 16, Ui.MUTED, 0.8f, false);

        // control glyphs (display only)
        int by = y + 25;
        int cxm = tx + maxW / 2 - 12;
        c.fill(cxm, by, cxm + 1, by + 7, Ui.WHITE);
        Ui.triangleLeft(c, cxm + 2, by, 7, Ui.WHITE);
        c.fill(cxm + 12, by, cxm + 14, by + 7, Ui.WHITE);
        c.fill(cxm + 16, by, cxm + 18, by + 7, Ui.WHITE);
        Ui.triangleRight(c, cxm + 26, by, 7, Ui.WHITE);
        c.fill(cxm + 31, by, cxm + 32, by + 7, Ui.WHITE);

        // progress
        int px1 = tx, px2 = x + w - 6, py = y + 36;
        c.fill(px1, py, px2, py + 2, 0x33FFFFFF);
        float progress = (ticks % 2400) / 2400f;
        c.fill(px1, py, px1 + Math.round((px2 - px1) * progress), py + 2, accent);
    }

    private void drawCoords(DrawContext c, TextRenderer tr, MinecraftClient mc, int sw, int y, Theme th) {
        PlayerEntity p = mc.player;
        String[] labels = {"x", "y", "z"};
        String[] values = {
            Integer.toString((int) Math.floor(p.getX())),
            Integer.toString((int) Math.floor(p.getY())),
            Integer.toString((int) Math.floor(p.getZ()))
        };
        int textW = 0;
        for (int i = 0; i < 3; i++) textW += tr.getWidth(labels[i]) + 3 + tr.getWidth(values[i]) + (i < 2 ? 6 : 0);
        int w = textW + 24;
        int x = (sw - w) / 2;
        Ui.roundRect(c, x, y, x + w, y + 13, 6, panel);
        Ui.triangleRight(c, x + 8, y + 4, 5, th.primary());
        int tx = x + 18;
        for (int i = 0; i < 3; i++) {
            c.drawText(tr, labels[i], tx, y + 3, th.primary(), false);
            tx += tr.getWidth(labels[i]) + 3;
            c.drawText(tr, values[i], tx, y + 3, Ui.WHITE, false);
            tx += tr.getWidth(values[i]) + 6;
        }
    }

    // ------------------------------------------------------------------ info panel

    /** Draws the Info Panel and returns its rectangle as {x, y, w, h}. */
    private int[] drawInfoPanel(DrawContext c, TextRenderer tr, MinecraftClient mc, int sw, int sh, Theme th) {
        PlayerEntity p = mc.player;
        List<String> lines = new ArrayList<>();
        if (cfg.isOn("fps")) lines.add("FPS " + mc.getCurrentFps());
        if (cfg.isOn("direction")) {
            String[] directions = {"South", "West", "North", "East"};
            int index = Math.floorMod((int) Math.floor(p.getYaw() / 90.0 + 0.5), 4);
            lines.add("Facing " + directions[index]);
        }
        if (cfg.isOn("biome")) {
            String biome = mc.world.getBiome(p.getBlockPos()).getKey()
                    .map(key -> key.getValue().getPath()).orElse("unknown");
            lines.add("Biome " + biome);
        }
        if (cfg.isOn("ping") && mc.getNetworkHandler() != null) {
            var entry = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
            if (entry != null) lines.add("Ping " + entry.getLatency() + " ms");
        }
        if (cfg.isOn("local_clock")) lines.add("Time " + java.time.LocalTime.now().withSecond(0).withNano(0));

        int w = tr.getWidth("BAROX VS") + 16;
        for (String line : lines) w = Math.max(w, tr.getWidth(line) + 16);
        int h = 16 + lines.size() * 11;
        int pos = cfg.hudPosition();
        int x = (pos == 1 || pos == 3) ? sw - w - 4 : 4;
        int y = (pos == 2 || pos == 3) ? sh - h - 4 : 4;
        Ui.roundRect(c, x, y, x + w, y + h, 4, panel);
        c.fill(x + 5, y + 5, x + 7, y + 12, th.primary());
        c.drawText(tr, "BAROX", x + 10, y + 4, Ui.WHITE, false);
        c.drawText(tr, "VS", x + 10 + tr.getWidth("BAROX "), y + 4, th.primary(), false);
        int ly = y + 16;
        for (String line : lines) {
            c.drawText(tr, line, x + 8, ly, Ui.MUTED, false);
            ly += 11;
        }
        return new int[]{x, y, w, h};
    }

    // ------------------------------------------------------------------ right column

    private int drawPotions(DrawContext c, TextRenderer tr, MinecraftClient mc, int sw, int y, int limit, Theme th) {
        List<StatusEffectInstance> effects = new ArrayList<>(mc.player.getStatusEffects());
        if (effects.isEmpty()) return y;
        int rows = Math.min(6, (limit - y - 20) / 10); // 17 px header + 3 px padding, 10 px per row
        if (rows < 1) return y;
        effects.sort((a, b) -> Integer.compare(remaining(b), remaining(a)));
        if (effects.size() > rows) effects = effects.subList(0, rows);

        int n = effects.size();
        String[] names = new String[n];
        String[] times = new String[n];
        int[] colors = new int[n];
        int w = tr.getWidth("PotionsList") + 24;
        for (int i = 0; i < n; i++) {
            StatusEffectInstance e = effects.get(i);
            String name = e.getEffectType().value().getName().getString();
            names[i] = e.getAmplifier() > 0 ? name + " " + (e.getAmplifier() + 1) : name;
            times[i] = e.isInfinite() ? "inf" : String.format(Locale.ROOT, "%d:%02d", e.getDuration() / 1200, (e.getDuration() / 20) % 60);
            colors[i] = 0xFF000000 | e.getEffectType().value().getColor();
            w = Math.max(w, 14 + tr.getWidth(names[i]) + 10 + tr.getWidth(times[i]) + 6);
        }
        int h = 17 + n * 10 + 3;
        int x = sw - w - 4;
        rightW = Math.max(rightW, w + 4);
        Ui.roundRect(c, x, y, x + w, y + h, 4, panel);
        c.fill(x + 5, y + 5, x + 7, y + 12, th.primary());
        c.drawText(tr, "PotionsList", x + 10, y + 4, Ui.WHITE, false);
        int ly = y + 17;
        for (int i = 0; i < n; i++) {
            c.fill(x + 5, ly + 2, x + 9, ly + 6, colors[i]);
            c.drawText(tr, names[i], x + 12, ly, 0xFFE6E8EC, false);
            boolean low = !effects.get(i).isInfinite() && effects.get(i).getDuration() < 200;
            Ui.textRight(c, tr, times[i], x + w - 5, ly, low ? 0xFFFF6B6B : th.primary(), 1f, false);
            ly += 10;
        }
        return y + h + 4;
    }

    private static int remaining(StatusEffectInstance e) {
        return e.isInfinite() ? Integer.MAX_VALUE : e.getDuration();
    }

    /** Size of the KeyBinds panel as {w, h}, or null when there is nothing to list. */
    private int[] keybindsSize(TextRenderer tr) {
        List<BaroxVsClient.KeyEntry> entries = BaroxVsClient.keyEntries();
        if (entries.isEmpty()) return null;
        int w = tr.getWidth("KeyBinds") + 24;
        for (BaroxVsClient.KeyEntry e : entries) {
            String key = e.key().getBoundKeyLocalizedText().getString();
            w = Math.max(w, 10 + tr.getWidth(e.label()) + 12 + tr.getWidth(key) + 10);
        }
        return new int[]{w, 17 + entries.size() * 11 + 3};
    }

    private void drawKeybinds(DrawContext c, TextRenderer tr, int x, int y, int w, int h, Theme th) {
        List<BaroxVsClient.KeyEntry> entries = BaroxVsClient.keyEntries();
        Ui.roundRect(c, x, y, x + w, y + h, 4, panel);
        c.fill(x + 5, y + 5, x + 7, y + 12, th.primary());
        c.drawText(tr, "KeyBinds", x + 10, y + 4, Ui.WHITE, false);
        int ly = y + 17;
        for (BaroxVsClient.KeyEntry e : entries) {
            String key = e.key().getBoundKeyLocalizedText().getString();
            boolean active = e.moduleId() != null && cfg.isOn(e.moduleId());
            c.drawText(tr, e.label(), x + 7, ly + 1, active ? th.primary() : 0xFFD4D7DD, false);
            int kw = tr.getWidth(key) + 6;
            int kx = x + w - kw - 4;
            Ui.roundRect(c, kx, ly - 1, kx + kw, ly + 9, 3, Ui.alpha(th.primary(), 0x44));
            c.drawText(tr, key, kx + 3, ly + 1, Ui.WHITE, false);
            ly += 11;
        }
    }

    // ------------------------------------------------------------------ side widgets

    private void drawSpeed(DrawContext c, TextRenderer tr, int x, int y, Theme th) {
        int w = history.length * 2 + 10;
        int h = 34;
        Ui.roundRect(c, x, y, x + w, y + h, 4, panel);
        c.fill(x + 5, y + 5, x + 7, y + 12, th.primary());
        c.drawText(tr, "Speed", x + 10, y + 4, Ui.WHITE, false);
        c.drawText(tr, Ui.num(bps, 2) + " bps", x + 6, y + 15, Ui.MUTED, false);

        float max = 6f;
        for (float v : history) max = Math.max(max, v);
        int base = y + h - 4;
        for (int i = 0; i < history.length; i++) {
            int bh = Math.round(Math.min(1f, history[i] / max) * 8f);
            int gx = x + 5 + i * 2;
            c.fill(gx, base - bh, gx + 2, base, Ui.alpha(th.primary(), 0x40 + (int) (0xA0 * i / (float) history.length)));
        }
        c.fill(x + 5, base, x + w - 5, base + 1, 0x33FFFFFF);
    }

    private static final int ARMOR_H = 28;

    /** Top edge of the Armor HUD; {@code floor} is the lowest y it may reach, so it can sit above an Info Panel. */
    private static int armorY(int sw, int sh, int floor) {
        return Math.min(sw < 430 ? sh - 70 : sh - ARMOR_H - 4, floor - ARMOR_H - 4);
    }

    /** @param floor the lowest y the widget may reach, so it can sit above an Info Panel in the corner */
    private void drawArmor(DrawContext c, TextRenderer tr, MinecraftClient mc, int sw, int sh, int floor) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        int slotW = 22;
        int w = slotW * 4 + 6;
        int h = ARMOR_H;
        int x = sw - w - 4;
        int y = armorY(sw, sh, floor);
        Ui.roundRect(c, x, y, x + w, y + h, 4, panel);
        for (int i = 0; i < slots.length; i++) {
            ItemStack stack = mc.player.getEquippedStack(slots[i]);
            int sx = x + 3 + i * slotW;
            if (stack.isEmpty()) {
                c.fill(sx + 3, y + 5, sx + 19, y + 21, 0x14FFFFFF);
                continue;
            }
            c.drawItem(stack, sx + 3, y + 3);
            if (stack.isDamageable() && stack.getMaxDamage() > 0) {
                int pct = Math.round(100f * (stack.getMaxDamage() - stack.getDamage()) / stack.getMaxDamage());
                int color = pct > 60 ? Ui.WHITE : pct > 25 ? 0xFFFFE04A : 0xFFFF6B6B;
                Ui.textCentered(c, tr, pct + "%", sx + 11, y + 20, color, 0.7f, false);
            }
        }
    }

    // ------------------------------------------------------------------ crosshair

    private void drawCrosshairRing(DrawContext c, MinecraftClient mc, int sw, int sh, Theme th) {
        int cx = sw / 2, cy = sh / 2;
        int radius = (int) cfg.num("crosshair_ring", "radius");
        int accent = accent("crosshair_ring", "color");
        float progress = mc.player.getAttackCooldownProgress(0f);
        Ui.ring(c, cx, cy, radius, 0x30FFFFFF, 1f);
        if (progress < 1f) Ui.ring(c, cx, cy, radius, accent, progress);
        else Ui.ring(c, cx, cy, radius, Ui.alpha(accent, 0x90), 1f);
    }

    private void drawTarget(DrawContext c, TextRenderer tr, int sw, int sh, Theme th) {
        long age = System.currentTimeMillis() - targetSeenMs;
        if (targetSeenMs == 0 || age > 1600) return;
        float fade = age < 1200 ? 1f : 1f - (age - 1200) / 400f;
        int w = 132, h = 28;
        int x = (sw - w) / 2;
        int y = sh / 2 + 12;
        Ui.roundRect(c, x, y, x + w, y + h, 4, Ui.fade(panel, fade));

        // letter badge (the card never reads skins or inventories)
        c.fillGradient(x + 4, y + 4, x + 24, y + 24, Ui.fade(th.primary(), fade), Ui.fade(th.secondary(), fade));
        String initial = targetName.isEmpty() ? "?" : targetName.substring(0, 1).toUpperCase(Locale.ROOT);
        Ui.textCentered(c, tr, initial, x + 14, y + 8, Ui.fade(Ui.WHITE, fade), 1f, true);

        Ui.text(c, tr, Ui.fit(tr, targetName, w - 34, 1f), x + 29, y + 4, Ui.fade(Ui.WHITE, fade), 1f, false);
        Ui.text(c, tr, "Distance: " + Ui.num(targetDist, 1), x + 29, y + 14, Ui.fade(Ui.MUTED, fade), 0.8f, false);

        float ratio = Math.max(0f, Math.min(1f, targetHealth / targetMax));
        int bx1 = x + 29, bx2 = x + w - 6, by = y + 22;
        c.fill(bx1, by, bx2, by + 3, Ui.fade(0x44FFFFFF, fade));
        int healthColor = ratio > 0.5f ? 0xFF55FF7A : ratio > 0.25f ? 0xFFFFE04A : 0xFFFF5B5B;
        c.fill(bx1, by, bx1 + Math.round((bx2 - bx1) * ratio), by + 3, Ui.fade(healthColor, fade));
    }

    private void drawPopups(DrawContext c, TextRenderer tr, int sw, int sh) {
        long now = System.currentTimeMillis();
        popups.removeIf(p -> now - p.born() > 900);
        for (Popup p : popups) {
            float t = (now - p.born()) / 900f;
            float a = t < 0.6f ? 1f : 1f - (t - 0.6f) / 0.4f;
            int y = sh / 2 - 14 - Math.round(t * 24f);
            Ui.textCentered(c, tr, p.text(), sw / 2 + p.dx(), y, Ui.fade(p.color(), a), cfg.f("hit_numbers", "size"), true);
        }
    }

    // ------------------------------------------------------------------ toasts

    private void drawToasts(DrawContext c, TextRenderer tr, int sw, int sh, Theme th) {
        toasts.removeIf(t -> ticks - t.born() > 50);
        int i = 0;
        int baseY = sh - 62;
        List<Toast> list = new ArrayList<>(toasts);
        for (int k = list.size() - 1; k >= 0; k--) {
            Toast t = list.get(k);
            int age = ticks - t.born();
            float a = age < 38 ? 1f : 1f - (age - 38) / 12f;
            String verb = t.enabled() ? "Enabled" : "Disabled";
            int w = 22 + tr.getWidth(verb) + 4 + tr.getWidth(t.name());
            int x = (sw - w) / 2;
            int y = baseY - i * 16;
            Ui.roundRect(c, x, y, x + w, y + 13, 5, Ui.fade(panel, a));
            Ui.triangleRight(c, x + 8, y + 4, 5, Ui.fade(t.enabled() ? th.primary() : 0xFFFF6B6B, a));
            int tx = x + 18;
            Ui.text(c, tr, verb, tx, y + 3, Ui.fade(0xFFE6E8EC, a), 1f, false);
            tx += tr.getWidth(verb) + 4;
            Ui.text(c, tr, t.name(), tx, y + 3, Ui.fade(t.enabled() ? th.primary() : 0xFFFF6B6B, a), 1f, false);
            i++;
        }
    }
}
