package com.baroxvs.client;

import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;

import java.util.Arrays;

/**
 * Sends a {@link Mesh} to the GPU through the ordinary entity vertex consumers, so it is drawn like any other
 * part of the player (same lighting, fog and render order). Everything uses one tiny white texture and vertex colours.
 *
 * <p>Layers: SOLID and GLOW go to the alpha blended entity layer (GLOW is fullbright and ignores shading),
 * HALO goes to the additive "eyes" layer. SOLID and GLOW are sorted far to near because alpha blending needs it.
 */
final class MeshRenderer {
    static final Identifier WHITE = Identifier.of("baroxvs", "textures/misc/white.png");

    private long[] keys = new long[1024];

    /**
     * Draws the mesh in the matrix frame that is currently on top of the stack. That frame is a Minecraft model
     * space where +Y points down, so the design space of the mesh (+Y up) is mirrored on Y while the vertices are
     * emitted. Mirroring reverses the winding, so the vertex order is reversed as well.
     */
    void draw(Mesh mesh, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, boolean fullbright) {
        if (mesh.count == 0) return;
        MatrixStack.Entry entry = matrices.peek();
        Matrix4f pm = entry.getPositionMatrix();
        if (keys.length < mesh.count) keys = new long[Math.max(mesh.count, keys.length * 2)];

        int n = 0;
        for (int q = 0; q < mesh.count; q++) {
            if (mesh.layer[q] == Mesh.HALO || mesh.back[q]) continue;
            float cx = 0f, cy = 0f, cz = 0f;
            for (int v = 0; v < 4; v++) {
                cx += mesh.pos[q * 12 + v * 3];
                cy += mesh.pos[q * 12 + v * 3 + 1];
                cz += mesh.pos[q * 12 + v * 3 + 2];
            }
            cx *= 0.25f;
            cy *= -0.25f; // mirrored Y
            cz *= 0.25f;
            float x = pm.m00() * cx + pm.m10() * cy + pm.m20() * cz + pm.m30();
            float y = pm.m01() * cx + pm.m11() * cy + pm.m21() * cz + pm.m31();
            float z = pm.m02() * cx + pm.m12() * cy + pm.m22() * cz + pm.m32();
            float distanceSquared = x * x + y * y + z * z; // the matrices are camera relative, so this is the distance to the camera
            keys[n++] = ((long) Float.floatToIntBits(distanceSquared) << 32) | q;
        }
        Arrays.sort(keys, 0, n);
        if (n > 0) {
            VertexConsumer consumer = vertexConsumers.getBuffer(RenderLayer.getEntityTranslucent(WHITE));
            for (int i = n - 1; i >= 0; i--) {
                emit(mesh, (int) (keys[i] & 0xFFFFFFFFL), consumer, entry, light, fullbright);
            }
        }

        VertexConsumer halo = null;
        for (int q = 0; q < mesh.count; q++) {
            if (mesh.layer[q] != Mesh.HALO) continue;
            if (halo == null) halo = vertexConsumers.getBuffer(RenderLayer.getEyes(WHITE));
            emit(mesh, q, halo, entry, light, true);
        }
    }

    private static void emit(Mesh m, int q, VertexConsumer consumer, MatrixStack.Entry entry, int light, boolean fullbright) {
        int layer = m.layer[q];
        int packedLight = (fullbright || layer != Mesh.SOLID) ? LightmapTextureManager.MAX_LIGHT_COORDINATE : light;
        float nx = m.nrm[q * 3], ny = m.nrm[q * 3 + 1], nz = m.nrm[q * 3 + 2];
        if (layer != Mesh.SOLID) { // glowing parts are not shaded: a normal that points up gets the full light
            nx = 0f;
            ny = 1f;
            nz = 0f;
        }
        ny = -ny; // mirrored Y
        for (int k = 0; k < 4; k++) {
            int v = (4 - k) & 3; // 0, 3, 2, 1
            int c = m.col[q * 4 + v];
            consumer.vertex(entry, m.pos[q * 12 + v * 3], -m.pos[q * 12 + v * 3 + 1], m.pos[q * 12 + v * 3 + 2])
                    .color(Colors.r(c), Colors.g(c), Colors.b(c), Colors.a(c))
                    .texture(0.5f, 0.5f)
                    .overlay(OverlayTexture.DEFAULT_UV)
                    .light(packedLight)
                    .normal(entry, nx, ny, nz);
        }
    }
}
