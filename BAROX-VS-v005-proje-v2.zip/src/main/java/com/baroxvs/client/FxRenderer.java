package com.baroxvs.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.registry.Registries;
import net.minecraft.util.Arm;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.joml.Matrix4f;

/**
 * Connects the effect engine to the game: once per frame (after the translucent terrain, so depth testing against the
 * world works) it tells {@link FxEngine} where the player and the camera are and draws the resulting geometry with plain
 * coloured quads. No vanilla particle is ever created.
 */
final class FxRenderer {
    private final BaroxConfig config;
    private final FxEngine engine;
    private final FxEngine.Body body = new FxEngine.Body();
    private final Matrix4f vertexMatrix = new Matrix4f();
    private long lastNanos;
    private float lastSwing;

    FxRenderer(BaroxConfig config) {
        this.config = config;
        this.engine = new FxEngine(config);
    }

    void register() {
        WorldRenderEvents.AFTER_TRANSLUCENT.register(this::render);
    }

    private void render(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        if (player == null || world == null || !player.isAlive() || player.isSpectator()) {
            engine.clear();
            lastNanos = 0L;
            lastSwing = 0f;
            return;
        }
        long now = System.nanoTime();
        float dt = lastNanos == 0L ? 0f : (now - lastNanos) / 1.0e9f;
        lastNanos = now;

        float tickDelta = context.tickCounter().getTickDelta(false);
        Camera camera = context.camera();
        Vec3d pos = player.getLerpedPos(tickDelta);
        Vec3d vel = player.getVelocity();
        Vec3d cam = camera.getPos();

        FxEngine.Body b = body;
        b.x = pos.x;
        b.y = pos.y;
        b.z = pos.z;
        b.yaw = player.getBodyYaw();
        b.headYaw = player.getYaw(tickDelta);
        b.headPitch = player.getPitch(tickDelta);
        b.vx = vel.x * 20.0;
        b.vy = vel.y * 20.0;
        b.vz = vel.z * 20.0;
        b.onGround = player.isOnGround();
        b.sneaking = player.isSneaking();
        b.inWater = player.isTouchingWater();
        b.firstPerson = !camera.isThirdPerson();
        b.rightHanded = player.getMainArm() == Arm.RIGHT;
        b.holdingSword = Registries.ITEM.getId(player.getMainHandStack().getItem()).getPath().endsWith("_sword");
        b.camX = cam.x;
        b.camY = cam.y;
        b.camZ = cam.z;
        b.camYaw = camera.getYaw();
        b.camPitch = camera.getPitch();
        b.timeOfDay = (float) (world.getTimeOfDay() % 24000L);

        // a swing starts when the progress leaves zero; the crosshair target tells whether it hit the air
        float swing = player.getHandSwingProgress(tickDelta);
        b.swing = swing;
        b.swingEvent = 0;
        if (swing > 0f && lastSwing <= 0f) {
            HitResult hit = client.crosshairTarget;
            if (hit == null || hit.getType() == HitResult.Type.MISS) b.swingEvent = 1;
            else if (hit.getType() == HitResult.Type.BLOCK) b.swingEvent = 2;
            else b.swingEvent = 3;
        }
        lastSwing = swing;

        // the sky dome sits between the farthest terrain and the far plane
        b.radius = Math.max(48f, client.options.getClampedViewDistance() * 16f * 2.6f);
        b.skyLift = 0f;
        boolean overworldOnly = config.idx("sky_aura", "dimension") == 0;
        b.skyVisible = (!overworldOnly || World.OVERWORLD.equals(world.getRegistryKey())) && !player.isSubmergedInWater();

        engine.frame(dt, b);
        draw(engine.mesh, vertexMatrix(RenderSystem.getModelViewMatrix(), context.positionMatrix(), vertexMatrix));
    }

    /**
     * The matrix every effect vertex is multiplied by on the CPU. The graphics card multiplies it by the global model-view
     * matrix afterwards, and what that matrix holds while the world is drawn depends on the render setup (the camera
     * rotation, or nothing at all). So the global matrix is cancelled out here: global * (inverse(global) * view) = view,
     * which is where the vertices of the world itself end up. Falls back to the plain view matrix if the inverse is broken.
     */
    static Matrix4f vertexMatrix(Matrix4f global, Matrix4f view, Matrix4f out) {
        out.set(global).invert().mul(view);
        if (!Float.isFinite(out.m00() + out.m01() + out.m02() + out.m03() + out.m10() + out.m11() + out.m12() + out.m13()
            + out.m20() + out.m21() + out.m22() + out.m23() + out.m30() + out.m31() + out.m32() + out.m33())) out.set(view);
        return out;
    }

    /** Draws the geometry of the engine: alpha blended faces first, then the additive glow layer. */
    private void draw(Mesh m, Matrix4f matrix) {
        if (m.count == 0) return;
        Tessellator tessellator = Tessellator.getInstance();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        flush(tessellator, m, matrix, false);
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        flush(tessellator, m, matrix, true);
        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
    }

    private static void flush(Tessellator tessellator, Mesh m, Matrix4f matrix, boolean additive) {
        boolean any = false;
        for (int q = 0; q < m.count && !any; q++) any = !m.back[q] && (m.layer[q] == Mesh.HALO) == additive;
        if (!any) return; // ending an empty buffer would throw
        BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (int q = 0; q < m.count; q++) {
            if (m.back[q] || (m.layer[q] == Mesh.HALO) != additive) continue;
            float shade = 1f;
            if (m.layer[q] == Mesh.SOLID) {
                float d = Math.abs(m.nrm[q * 3] * 0.25f + m.nrm[q * 3 + 1] * 0.85f + m.nrm[q * 3 + 2] * 0.45f);
                shade = 0.58f + 0.42f * Math.min(1f, d / 1.02f);
            }
            put(buffer, matrix, m, q, false, shade);
            put(buffer, matrix, m, q, true, shade); // the other winding: every face is visible from both sides
        }
        BufferRenderer.drawWithGlobalProgram(buffer.end());
    }

    private static void put(VertexConsumer consumer, Matrix4f matrix, Mesh m, int q, boolean reverse, float shade) {
        for (int k = 0; k < 4; k++) {
            int v = reverse ? 3 - k : k;
            int o = q * 12 + v * 3;
            int c = m.col[q * 4 + v];
            if (shade != 1f) {
                int r = Math.round(((c >> 16) & 255) * shade), g = Math.round(((c >> 8) & 255) * shade), bl = Math.round((c & 255) * shade);
                c = (c & 0xFF000000) | (r << 16) | (g << 8) | bl;
            }
            consumer.vertex(matrix, m.pos[o], m.pos[o + 1], m.pos[o + 2]).color(c);
        }
    }
}
