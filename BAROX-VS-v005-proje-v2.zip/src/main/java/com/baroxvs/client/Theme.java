package com.baroxvs.client;

/** A colour theme: a bright primary accent and a deeper secondary used for gradients. */
public record Theme(String name, int primary, int secondary) {}
