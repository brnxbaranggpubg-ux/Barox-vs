package com.baroxvs.client;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.glfw.GLFW;

/**
 * The settings window of one module: a live 3D preview (for the 3D cosmetics) and a control for every option of
 * the module (switch, slider, design picker, full color picker, text field). It only reads and writes the
 * {@link BaroxConfig}, so everything shown here is exactly what the renderers use.
 */
final class SettingsWindow {
    private static final int HEADER_H = 26;
    private static final int PREVIEW_W = 150;
    private static final int GAP = 3;
    private static final int SV_H = 46;
    private static final int NO_REGION = -1;
    /** Scroll region of the option list (see BaroxMenuScreen). */
    static final int LIST_REGION = 6;
    private static final int PREVIEW_REGION = 7;

    final ModuleCatalog.Module module;
    private final BaroxMenuScreen screen;
    private final BaroxConfig cfg;
    private final long openedAt = System.currentTimeMillis();

    // window rectangle in menu pixels, valid after render()
    private int wx, wy, ww, wh;
    private int listX1, listX2, listTop, listBottom;
    private boolean hasPreview;

    // per frame drawing state
    private DrawContext ctx;
    private TextRenderer tr;
    private Theme th;
    private float mx, my;
    private int y;

    // editing state
    private String focus;           // null, "t:<setting id>" or "hex"
    private String hexBuf = "";
    private String expanded;        // setting id of the open color picker
    private float pickH, pickS = 1f, pickV = 1f;

    // 3D preview
    private final Mesh mesh = new Mesh();
    private final MeshProjector projector = new MeshProjector();
    private final CosmeticModels.Anim anim = new CosmeticModels.Anim();
    private float yaw;
    private float zoom = 1f;
    private boolean spinStopped;
    private long lastFrame;
    private double dragX = Double.NaN;
    private boolean previewFailed;
    private int pvx1, pvy1, pvx2, pvy2;

    // live effect preview: the real effect engine runs for a pretend player in the preview box
    private FxEngine fxEngine;
    private final FxEngine.Body fxBody = new FxEngine.Body();
    private float frameDt, fxClock, fxNextSwing = 0.5f, fxNextJump = 0.6f, fxSwingLeft, fxJumpT;
    private boolean fxJumping, fxActionNow;

    SettingsWindow(BaroxMenuScreen screen, BaroxConfig cfg, ModuleCatalog.Module module) {
        this.screen = screen;
        this.cfg = cfg;
        this.module = module;
        this.yaw = module.id().equals("visor") ? 2.7f : 0.45f;
        this.lastFrame = openedAt;
    }

    boolean contains(double x, double y) {
        return x >= wx && x < wx + ww && y >= wy && y < wy + wh;
    }

    boolean overPreview(double x, double y) {
        return hasPreview && x >= pvx1 && x < pvx2 && y >= pvy1 && y < pvy2;
    }

    boolean overList(double x, double y) {
        return x >= listX1 - 2 && x < listX2 + 8 && y >= listTop && y < listBottom;
    }

    private void changed() {
        screen.markDirty();
    }

    private double time() {
        return System.currentTimeMillis() / 1000.0;
    }

    private boolean over(int x1, int y1, int x2, int y2) {
        return mx >= x1 && mx < x2 && my >= y1 && my < y2 && my >= listTop - 1 && my < listBottom;
    }

    // ------------------------------------------------------------------ input

    boolean hasFocus() {
        return focus != null;
    }

    void blur() {
        focus = null;
    }

    void endDrag() {
        dragX = Double.NaN;
    }

    boolean typed(char c) {
        if (focus == null || c < 32 || c == 127) return false;
        if (focus.equals("hex")) {
            if (Character.digit(c, 16) >= 0 && hexBuf.length() < 6) {
                hexBuf += Character.toUpperCase(c);
                if (hexBuf.length() == 6) applyHex();
            }
            return true;
        }
        if (focus.startsWith("t:")) {
            String id = focus.substring(2);
            String text = cfg.text(module.id(), id);
            if (text.length() < 64) {
                cfg.setText(module.id(), id, text + c);
                changed();
            }
            return true;
        }
        return false;
    }

    /** Returns true when the key was used by a focused field (every key is swallowed while typing). */
    boolean key(int keyCode) {
        if (focus == null) return false;
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER || keyCode == GLFW.GLFW_KEY_ESCAPE) {
            focus = null;
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
            if (focus.equals("hex")) {
                if (!hexBuf.isEmpty()) hexBuf = hexBuf.substring(0, hexBuf.length() - 1);
            } else if (focus.startsWith("t:")) {
                String id = focus.substring(2);
                String text = cfg.text(module.id(), id);
                if (!text.isEmpty()) {
                    cfg.setText(module.id(), id, text.substring(0, text.length() - 1));
                    changed();
                }
            }
        }
        return true;
    }

    /** Mouse wheel: zooms the preview or scrolls the option list. Returns true when the event was used. */
    boolean scrolled(double x, double y, double amount) {
        if (overPreview(x, y)) {
            zoom = Math.max(0.5f, Math.min(2.5f, zoom * (amount > 0 ? 1.1f : 1f / 1.1f)));
            return true;
        }
        if (overList(x, y)) {
            screen.scroll[LIST_REGION] = Math.max(0f, Math.min(screen.maxScroll[LIST_REGION], screen.scroll[LIST_REGION] - (float) amount * 20f));
            return true;
        }
        return contains(x, y);
    }

    // ------------------------------------------------------------------ frame

    void render(DrawContext ctx, TextRenderer tr, Theme th, float mx, float my) {
        this.ctx = ctx;
        this.tr = tr;
        this.th = th;
        this.mx = mx;
        this.my = my;

        int vw = (int) screen.vw, vh = (int) screen.vh;
        hasPreview = (module.model3d() || module.fxPreview()) && vw - 24 >= 380;
        ww = Math.min(vw - 24, hasPreview ? 520 : 340);
        wh = Math.min(vh - 24, 340);
        wx = (vw - ww) / 2;
        wy = Math.max(8, (vh - wh) / 2 - 4);
        listX1 = hasPreview ? wx + 8 + PREVIEW_W + 10 : wx + 8;
        listX2 = wx + ww - 12;
        listTop = wy + HEADER_H + 4;
        listBottom = wy + wh - 16;

        boolean animate = cfg.flag("gui_style", "animations");
        float t = animate ? Math.min(1f, (System.currentTimeMillis() - openedAt) / 150f) : 1f;
        float k = 0.94f + 0.06f * (1f - (1f - t) * (1f - t));
        float cx = wx + ww / 2f, cy = wy + wh / 2f;
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(cx, cy, 0f);
        m.scale(k, k, 1f);
        m.translate(-cx, -cy, 0f);

        Ui.panel(ctx, wx, wy, wx + ww, wy + wh, th.primary(), 0xF40A0C14, 5, 0x90);
        Ui.brackets(ctx, wx, wy, wx + ww, wy + wh, 9, th.primary());
        ctx.fill(wx + 6, wy + HEADER_H - 1, wx + ww - 6, wy + HEADER_H, Ui.alpha(th.primary(), 0x50));
        drawHeader();
        if (hasPreview) drawPreview();
        drawList();
        Ui.text(ctx, tr, "Sağ tık: ayarı sıfırla  •  Sürükle: kaydır  •  Esc: kapat", wx + 8, wy + wh - 11, Ui.DIM, 0.75f, false);

        m.pop();
    }

    // ------------------------------------------------------------------ header

    private GuiHit headerHit(int x1, int y1, int x2, int y2) {
        return screen.hit(x1, y1, x2, y2, NO_REGION);
    }

    private void drawHeader() {
        int primary = th.primary();
        Ui.icon(ctx, BaroxMenuScreen.iconFor(module.category()), wx + 9, wy + 10, primary);
        Ui.text(ctx, tr, module.name(), wx + 22, wy + 9, Ui.WHITE, 1f, true);
        Ui.text(ctx, tr, module.category(), wx + 22 + tr.getWidth(module.name()) + 6, wy + 10, Ui.DIM, 0.8f, false);

        int right = wx + ww - 8;
        // close
        int x1 = right - 13, y1 = wy + 6;
        boolean hover = mx >= x1 && mx < x1 + 13 && my >= y1 && my < y1 + 13;
        Ui.roundRect(ctx, x1, y1, x1 + 13, y1 + 13, 3, hover ? 0x60FF5B5B : 0x22FFFFFF);
        Ui.cross(ctx, x1 + 4, y1 + 4, 5, hover ? 0xFFFFA0A0 : Ui.MUTED);
        headerHit(x1, y1, x1 + 13, y1 + 13).click(screen::closeWindow).tip("Close");
        right = x1 - 5;

        // reset
        String label = "Reset";
        int rw = tr.getWidth(label) + 10;
        int rx = right - rw;
        boolean modified = cfg.isModified(module.id());
        hover = modified && mx >= rx && mx < rx + rw && my >= wy + 7 && my < wy + 19;
        Ui.roundRect(ctx, rx, wy + 7, rx + rw, wy + 19, 3, hover ? Ui.alpha(primary, 0x60) : modified ? Ui.alpha(primary, 0x30) : 0x14FFFFFF);
        Ui.text(ctx, tr, label, rx + 5, wy + 9, modified ? Ui.WHITE : Ui.DIM, 1f, false);
        if (modified) {
            headerHit(rx, wy + 7, rx + rw, wy + 19).click(() -> {
                cfg.reset(module.id());
                expanded = null;
                focus = null;
                changed();
            }).tip("Restore every option of this module to its default");
        }
        right = rx - 5;

        // on / off switch
        if (module.kind() == ModuleCatalog.Kind.TOGGLE) {
            boolean on = cfg.isOn(module.id());
            String text = on ? "ON" : "OFF";
            int sw = tr.getWidth("OFF") + 12;
            int sx = right - sw;
            hover = mx >= sx && mx < sx + sw && my >= wy + 7 && my < wy + 19;
            Ui.roundRect(ctx, sx, wy + 7, sx + sw, wy + 19, 3, on ? primary : hover ? 0x40FFFFFF : 0x24FFFFFF);
            Ui.textCentered(ctx, tr, text, sx + sw / 2, wy + 9, on ? 0xFF0B0B10 : Ui.MUTED, 1f, false);
            headerHit(sx, wy + 7, sx + sw, wy + 19).click(() -> BaroxVsClient.toggleModule(module.id())).tip("Module on / off");
        }
    }

    // ------------------------------------------------------------------ 3D preview

    /** {pitch in degrees, pixels per block for a 230 px box, centre height, centre depth} */
    private static float[] view(String id) {
        switch (id) {
            case "halo": case "crown": case "horns": case "ears":
                return new float[]{16f, 230f, 1.85f, 0.1f};
            case "visor":
                return new float[]{8f, 230f, 1.85f, 0.1f};
            case "tail":
                return new float[]{8f, 150f, 0.95f, 0.1f};
            case "cape": case "jetpack":
                return new float[]{8f, 125f, 1.05f, 0.1f};
            case "rune":
                return new float[]{38f, 105f, 0.3f, 0.1f};
            case "drone":
                return new float[]{14f, 105f, 1.3f, 0.1f};
            default:
                return new float[]{20f, 105f, 1.0f, 0.1f};
        }
    }

    private void drawPreview() {
        int primary = th.primary();
        int x1 = wx + 8, y1 = listTop, x2 = x1 + PREVIEW_W;
        boolean fxMode = module.fxPreview();
        String action = fxMode ? fxAction() : null;
        int y2 = Math.min(listBottom - (action != null ? 42 : 30), y1 + (action != null ? 198 : 210));
        pvx1 = x1;
        pvy1 = y1;
        pvx2 = x2;
        pvy2 = y2;
        Ui.panel(ctx, x1, y1, x2, y2, primary, 0xFF0A0D15, 4, 0x80);
        int bottom = Ui.lerp(0xFF0B0F19, 0xFF000000 | th.secondary(), 0.3f);
        ctx.fillGradient(x1 + 1, y1 + 1, x2 - 1, y2 - 1, 0xFF0B0F19, bottom);
        screen.hit(x1, y1, x2, y2, PREVIEW_REGION).tip("Drag to rotate, mouse wheel to zoom").drag((x, yy) -> {
            if (!Double.isNaN(dragX)) yaw += (float) ((x - dragX) * 0.03);
            dragX = x;
            spinStopped = true;
        });

        long now = System.currentTimeMillis();
        float dt = Math.min(0.1f, (now - lastFrame) / 1000f);
        lastFrame = now;
        frameDt = dt;
        if (cfg.flag("gui_style", "preview_spin") && !spinStopped) yaw += dt * 0.8f;

        ctx.enableScissor(x1 + 1, y1 + 1, x2 - 1, y2 - 1);
        try {
            if (!previewFailed) drawModel(x1, y1, x2, y2);
        } catch (RuntimeException exception) {
            previewFailed = true;
            System.err.println("[BAROX VS] Preview failed: " + exception);
        } finally {
            ctx.disableScissor();
        }
        Ui.text(ctx, tr, fxMode ? "LIVE PREVIEW" : "3D PREVIEW", x1 + 6, y1 + 5, Ui.alpha(primary, 0xB0), 0.7f, false);

        // quick views
        String[] names = {"Back", "Side", "Front", "Spin"};
        int cx = x1;
        for (int i = 0; i < names.length; i++) {
            int w = tr.getWidth(names[i]) + 8;
            int by = y2 + 5;
            boolean hover = mx >= cx && mx < cx + w && my >= by && my < by + 12;
            boolean active = i == 3 && !spinStopped && cfg.flag("gui_style", "preview_spin");
            Ui.roundRect(ctx, cx, by, cx + w, by + 12, 3, active ? primary : hover ? 0x40FFFFFF : 0x22FFFFFF);
            Ui.text(ctx, tr, names[i], cx + 4, by + 2, active ? 0xFF0B0B10 : Ui.MUTED, 1f, false);
            final int index = i;
            screen.hit(cx, by, cx + w, by + 12, NO_REGION).click(() -> {
                if (index == 3) {
                    spinStopped = false;
                } else {
                    spinStopped = true;
                    yaw = index == 0 ? 0f : index == 1 ? 1.5708f : 3.1416f;
                }
            });
            cx += w + 3;
        }
        if (action != null) {
            int w = tr.getWidth(action) + 14;
            int by = y2 + 20;
            boolean hover = mx >= x1 && mx < x1 + w && my >= by && my < by + 12;
            Ui.roundRect(ctx, x1, by, x1 + w, by + 12, 3, hover ? Ui.alpha(primary, 0x90) : Ui.alpha(primary, 0x50));
            Ui.text(ctx, tr, action, x1 + 7, by + 2, Ui.WHITE, 1f, false);
            screen.hit(x1, by, x1 + w, by + 12, NO_REGION).click(() -> fxActionNow = true).tip("Try it now");
        }
        Ui.text(ctx, tr, "Drag: rotate  Wheel: zoom", x1, y2 + (action != null ? 35 : 21), Ui.DIM, 0.7f, false);
    }

    /** Label of the extra "try it" button of an effect preview (null = none). */
    private String fxAction() {
        String id = module.id();
        if (id.equals("jump_crystal") || id.equals("landing_burst")) return "Jump";
        if (id.equals("orbit_shapes")) return cfg.idx(id, "trigger") == 3 ? "Jump" : "Swing";
        if (id.equals("sword_trail") || id.equals("fx")) return "Swing";
        return null;
    }

    private void drawModel(int x1, int y1, int x2, int y2) {
        if (module.fxPreview()) {
            drawFx(x1, y1, x2, y2);
            return;
        }
        String id = module.id();
        float[] v = view(id);
        float unit = Math.min(x2 - x1, y2 - y1) / 230f;
        float baseScale = v[1] * unit;
        anim.time = (System.currentTimeMillis() % 1_000_000L) / 1000f;
        anim.activity = 0.6f;
        anim.airborne = false;
        anim.sneaking = false;

        mesh.clear();
        PreviewFigure.build(mesh);
        int figureQuads = mesh.count;
        mesh.push();
        if (CosmeticModels.frameOf(id) != CosmeticModels.FEET) mesh.translate(0f, CosmeticModels.NECK, 0f);
        CosmeticModels.build(id, mesh, cfg, anim);
        mesh.pop();

        // Auto fit: measure the cosmetic itself (not the mannequin) in a rotation independent way and zoom out until it fits.
        float pitch = (float) Math.toRadians(v[0]);
        float reach = 0f, lo = Float.MAX_VALUE, hi = -Float.MAX_VALUE;
        for (int q = figureQuads; q < mesh.count; q++) {
            for (int k = 0; k < 4; k++) {
                float px = mesh.pos[q * 12 + k * 3], py = mesh.pos[q * 12 + k * 3 + 1], pz = mesh.pos[q * 12 + k * 3 + 2];
                reach = Math.max(reach, (float) Math.sqrt(px * px + pz * pz));
                lo = Math.min(lo, py);
                hi = Math.max(hi, py);
            }
        }
        float fit = 1f, centerY = v[2], centerZ = v[3];
        if (hi > lo) {
            float spanW = 2f * reach * baseScale + 1f;
            float spanH = ((hi - lo) * (float) Math.cos(pitch) + 2f * reach * (float) Math.sin(Math.abs(pitch))) * baseScale + 1f;
            fit = Math.min(1f, Math.min((x2 - x1 - 14) / spanW, (y2 - y1 - 14) / spanH));
            if (fit < 1f) {
                centerY = (lo + hi) / 2f;
                centerZ = 0f;
            }
        }
        float ox = (x1 + x2) / 2f, oy = (y1 + y2) / 2f + (fit < 1f ? 0f : 4f);
        projector.project(mesh, yaw, pitch, baseScale * fit * zoom, ox, oy, 0f, centerY, centerZ);

        if (!id.equals("rune")) { // floor rings
            int ring = Ui.alpha(th.primary(), 0x40);
            float[] p = new float[2];
            for (int r = 0; r < 2; r++) {
                float radius = r == 0 ? 0.55f : 0.95f;
                for (int i = 0; i < 72; i++) {
                    double a = Math.PI * 2.0 * i / 72.0;
                    projector.point((float) Math.cos(a) * radius, 0f, (float) Math.sin(a) * radius, p);
                    ctx.fill(Math.round(p[0]), Math.round(p[1]), Math.round(p[0]) + 1, Math.round(p[1]) + 1, ring);
                }
            }
        }
        Ui.drawProjected(ctx, projector);
    }

    /** {span in blocks that fits the box, height of the view centre, camera pitch in degrees} */
    private float[] fxView(String id) {
        switch (id) {
            case "orbit_shapes":
                return new float[]{Math.max(3.4f, 2f * cfg.f(id, "radius") * Math.max(1f, cfg.f(id, "bounce") / 100f) + 1.4f), 1.0f, 18f};
            case "sky_aura":
                return new float[]{6.4f, 2.1f, 8f};
            case "atmosphere":
                return new float[]{6.8f, 1.1f, 14f};
            case "beam":
                return new float[]{Math.max(3.4f, cfg.f(id, "height") + 0.8f), Math.max(1.0f, cfg.f(id, "height") / 2f), 10f};
            case "aura":
                return new float[]{3.8f, 0.8f, 30f};
            case "rain_cloud":
                return new float[]{4.0f, 1.5f, 12f};
            case "jump_crystal": case "landing_burst":
                return new float[]{4.4f, 1.0f, 20f};
            case "fx":
                return new float[]{5.0f, 1.0f, 18f};
            default:
                return module.category().equals(ModuleCatalog.TRAILS) ? new float[]{4.6f, 0.9f, 26f} : new float[]{3.6f, 1.0f, 14f};
        }
    }

    /** Live preview of an effect: the real effect engine runs for a pretend player who stands, walks or jumps in the box. */
    private void drawFx(int x1, int y1, int x2, int y2) {
        String id = module.id();
        FxEngine.Body b = fxBody;
        if (fxEngine == null) {
            fxEngine = new FxEngine(cfg);
            boolean all = id.equals("fx"); // the quality page shows the effects that are switched on (without the sky)
            fxEngine.only(all ? null : id, all ? "sky_aura" : null);
            b.preview = true;
            b.x = 1.15; // where the walk starts, so the first frame does not look like a dash
            b.yaw = 180f;
            b.headYaw = 180f;
            b.headPitch = 6f;
            b.holdingSword = true;
            b.timeOfDay = 18000f;
            b.radius = 3.0f;
            b.skyLift = 0.9f;
        }
        float dt = Math.min(0.05f, frameDt);
        fxClock += dt;

        boolean jumpModule = id.equals("jump_crystal") || id.equals("landing_burst");
        int trigger = id.equals("orbit_shapes") ? cfg.idx(id, "trigger") : 0;
        boolean walk = !jumpModule && module.category().equals(ModuleCatalog.TRAILS);
        b.vx = 0;
        b.vy = 0;
        b.vz = 0;
        if (walk) { // walk in a circle so trails and footsteps have something to follow
            double a = fxClock * 0.8, r = 1.15;
            double nx = Math.cos(a) * r, nz = Math.sin(a) * r;
            if (dt > 1e-4f) {
                b.vx = (nx - b.x) / dt;
                b.vz = (nz - b.z) / dt;
            }
            b.x = nx;
            b.z = nz;
            if (b.vx != 0 || b.vz != 0) b.yaw = (float) Math.toDegrees(Math.atan2(-b.vx, b.vz));
        } else {
            b.x = 0;
            b.z = 0;
            b.yaw = 180f;
        }
        b.headYaw = b.yaw;

        // pretend swings and jumps, automatic every couple of seconds or at once when the button is pressed
        b.swingEvent = 0;
        b.onGround = true;
        b.y = 0;
        if (jumpModule || trigger == 3) {
            if (!fxJumping && (fxActionNow || fxClock >= fxNextJump)) {
                fxJumping = true;
                fxJumpT = 0f;
                fxActionNow = false;
            }
            if (fxJumping) {
                fxJumpT += dt;
                float u = fxJumpT / 0.6f;
                if (u >= 1f) {
                    fxJumping = false;
                    fxNextJump = fxClock + 1.8f;
                } else {
                    b.onGround = false;
                    b.y = 1.1 * 4 * u * (1 - u);
                    b.vy = 1.1 * 4 * (1 - 2 * u) / 0.6;
                }
            }
        } else if (trigger != 4) {
            if (fxSwingLeft <= 0f && (fxActionNow || fxClock >= fxNextSwing)) {
                fxSwingLeft = 0.3f;
                fxActionNow = false;
                fxNextSwing = fxClock + 1.8f;
                b.swingEvent = trigger == 2 ? 3 : 1;
            }
        }
        if (fxSwingLeft > 0f) {
            b.swing = 0.05f + 0.9f * (1f - fxSwingLeft / 0.3f);
            fxSwingLeft = Math.max(0f, fxSwingLeft - dt);
        } else {
            b.swing = 0f;
        }

        float[] v = fxView(id);
        b.camX = 0;
        b.camY = 0;
        b.camZ = 0;
        b.camYaw = 180f + (float) Math.toDegrees(yaw);
        b.camPitch = v[2];
        fxEngine.frame(dt, b);

        // the pretend player (the sky preview puts the horizon at eye height) and the effect geometry
        mesh.clear();
        mesh.push();
        mesh.translate((float) b.x, id.equals("sky_aura") ? b.skyLift - 1.62f : (float) b.y, (float) b.z);
        mesh.rotY((float) (Math.PI - Math.toRadians(b.yaw))); // the figure looks along -Z; yaw 0 of the game looks along +Z
        PreviewFigure.build(mesh);
        mesh.pop();
        mesh.append(fxEngine.mesh);

        float scale = Math.min(x2 - x1 - 6, y2 - y1 - 6) / v[0] * zoom;
        float ox = (x1 + x2) / 2f, oy = (y1 + y2) / 2f;
        projector.project(mesh, yaw, (float) Math.toRadians(v[2]), scale, ox, oy, 0f, v[1], 0f);
        if (!id.equals("sky_aura")) { // floor ring
            int ring = Ui.alpha(th.primary(), 0x40);
            float[] p = new float[2];
            for (int i = 0; i < 72; i++) {
                double a = Math.PI * 2.0 * i / 72.0;
                projector.point((float) Math.cos(a) * 0.95f, 0f, (float) Math.sin(a) * 0.95f, p);
                ctx.fill(Math.round(p[0]), Math.round(p[1]), Math.round(p[0]) + 1, Math.round(p[1]) + 1, ring);
            }
        }
        Ui.drawProjected(ctx, projector);
    }

    // ------------------------------------------------------------------ option list

    /** A hit rectangle inside the option list, clipped to the visible part (an unregistered dummy when fully hidden). */
    private GuiHit listHit(int x1, int y1, int x2, int y2) {
        int a = Math.max(y1, listTop), b = Math.min(y2, listBottom);
        if (a >= b) return new GuiHit(0, 0, 0, 0, NO_REGION);
        return screen.hit(x1, a, x2, b, LIST_REGION);
    }

    private boolean vis(int top, int height) {
        return top + height > listTop && top < listBottom;
    }

    private void drawList() {
        screen.maxScroll[LIST_REGION] = Math.max(0f, screen.maxScroll[LIST_REGION]);
        screen.scroll[LIST_REGION] = Math.max(0f, Math.min(screen.maxScroll[LIST_REGION], screen.scroll[LIST_REGION]));
        screen.hit(listX1 - 2, listTop, listX2 + 8, listBottom, LIST_REGION); // drag scrolling on empty space

        ctx.enableScissor(listX1 - 3, listTop, listX2 + 8, listBottom);
        try {
            y = listTop - Math.round(screen.scroll[LIST_REGION]);
            int start = y;
            if (vis(y, 12)) {
                Ui.text(ctx, tr, Ui.fit(tr, module.description(), listX2 - listX1, 0.8f), listX1 + 2, y + 1, Ui.DIM, 0.8f, false);
            }
            y += 13;
            for (Setting s : module.settings()) {
                int h;
                switch (s.kind) {
                    case TOGGLE -> h = toggleRow(s);
                    case SLIDER -> h = sliderRow(s);
                    case CHOICE -> h = choiceRow(s);
                    case COLOR -> h = colorRow(s);
                    default -> h = textRow(s);
                }
                if (vis(y + h, 2)) ctx.fill(listX1, y + h + 1, listX2, y + h + 2, 0x0EFFFFFF);
                y += h + GAP;
            }
            int content = y - start;
            float viewport = listBottom - listTop;
            screen.maxScroll[LIST_REGION] = Math.max(0f, content - viewport);
            if (screen.maxScroll[LIST_REGION] > 0f) {
                float thumb = Math.max(12f, viewport * viewport / content);
                float ty = listTop + (viewport - thumb) * (screen.scroll[LIST_REGION] / screen.maxScroll[LIST_REGION]);
                ctx.fill(listX2 + 4, Math.round(ty), listX2 + 6, Math.round(ty + thumb), Ui.alpha(th.primary(), 0xC0));
            }
        } finally {
            ctx.disableScissor();
        }
    }

    private void label(Setting s, int ly) {
        boolean modified = cfg.isSettingModified(module.id(), s.id);
        if (modified) ctx.fill(listX1 - 2, ly + 2, listX1, ly + 6, th.primary());
        Ui.text(ctx, tr, s.label, listX1 + 3, ly, modified ? Ui.WHITE : 0xFFC8CCD6, 1f, false);
    }

    private Runnable resetter(Setting s) {
        return () -> {
            cfg.resetSetting(module.id(), s.id);
            changed();
        };
    }

    // -------- toggle

    private int toggleRow(Setting s) {
        int h = 18;
        if (!vis(y, h)) return h;
        boolean on = cfg.flag(module.id(), s.id);
        boolean hover = over(listX1, y, listX2, y + h);
        if (hover) Ui.roundRect(ctx, listX1, y, listX2, y + h, 3, 0x10FFFFFF);
        label(s, y + 5);
        int sx = listX2 - 25;
        Ui.roundRect(ctx, sx, y + 4, sx + 23, y + 14, 5, on ? th.primary() : 0x30FFFFFF);
        int kx = on ? sx + 14 : sx + 2;
        Ui.roundRect(ctx, kx, y + 5, kx + 7, y + 13, 3, on ? 0xFF0B0B10 : 0xFFB8BDC8);
        listHit(listX1, y, listX2, y + h).click(() -> {
            cfg.set(module.id(), s.id, on ? 0 : 1);
            changed();
        }).alt(resetter(s)).tip(s.label);
        return h;
    }

    // -------- slider

    private int sliderRow(Setting s) {
        int h = 28;
        if (!vis(y, h)) return h;
        double v = cfg.num(module.id(), s.id);
        double range = Math.max(1e-9, s.max - s.min);
        float t = (float) Math.max(0.0, Math.min(1.0, (v - s.min) / range));
        label(s, y + 3);
        Ui.textRight(ctx, tr, s.format(v), listX2 - 1, y + 3, th.primary(), 1f, false);

        int tx1 = listX1 + 14, tx2 = listX2 - 14, ty = y + 19;
        ctx.fill(tx1, ty, tx2, ty + 3, 0x30FFFFFF);
        int kx = tx1 + Math.round((tx2 - tx1) * t);
        ctx.fill(tx1, ty, kx, ty + 3, th.primary());
        Ui.roundRect(ctx, kx - 3, ty - 4, kx + 3, ty + 7, 2, Ui.WHITE);
        ctx.fill(kx - 1, ty - 2, kx + 1, ty + 5, th.primary());

        boolean hl = over(listX1, y + 14, listX1 + 12, y + 28), hr = over(listX2 - 12, y + 14, listX2, y + 28);
        Ui.triangleLeft(ctx, listX1 + 3, y + 17, 7, hl ? Ui.WHITE : Ui.DIM);
        Ui.triangleRight(ctx, listX2 - 7, y + 17, 7, hr ? Ui.WHITE : Ui.DIM);

        final double step = s.step;
        listHit(listX1, y + 13, listX1 + 12, y + 28).click(() -> {
            cfg.set(module.id(), s.id, cfg.num(module.id(), s.id) - step);
            changed();
        }).alt(resetter(s));
        listHit(listX2 - 12, y + 13, listX2, y + 28).click(() -> {
            cfg.set(module.id(), s.id, cfg.num(module.id(), s.id) + step);
            changed();
        }).alt(resetter(s));
        listHit(tx1 - 5, y + 12, tx2 + 5, y + 28).drag((x, yy) -> {
            double f = Math.max(0.0, Math.min(1.0, (x - tx1) / (double) (tx2 - tx1)));
            cfg.set(module.id(), s.id, s.min + f * range);
            changed();
        }).alt(resetter(s)).tip(s.label + ": drag, or use the arrows for fine steps");
        listHit(listX1, y, listX2, y + 12).alt(resetter(s));
        return h;
    }

    // -------- choice (chips)

    private record Flow(int[] x, int[] line, int lines) {}

    private static Flow flow(int[] widths, int gap, int avail) {
        int n = widths.length;
        int[] x = new int[n], line = new int[n];
        int cx = 0, ln = 0;
        for (int i = 0; i < n; i++) {
            if (cx > 0 && cx + widths[i] > avail) {
                cx = 0;
                ln++;
            }
            x[i] = cx;
            line[i] = ln;
            cx += widths[i] + gap;
        }
        return new Flow(x, line, n == 0 ? 0 : ln + 1);
    }

    private int[] chipWidths(String[] options) {
        int[] w = new int[options.length];
        for (int i = 0; i < w.length; i++) w[i] = tr.getWidth(options[i]) + 9;
        return w;
    }

    private int choiceRow(Setting s) {
        int[] widths = chipWidths(s.options);
        Flow f = flow(widths, 3, listX2 - listX1 - 2);
        int h = 14 + f.lines() * 15;
        if (!vis(y, h)) return h;
        int current = cfg.idx(module.id(), s.id);
        label(s, y + 2);
        Ui.textRight(ctx, tr, s.options[current], listX2 - 1, y + 2, Ui.alpha(th.primary(), 0xC0), 0.8f, false);
        listHit(listX1, y, listX2, y + 13).alt(resetter(s));
        for (int i = 0; i < widths.length; i++) {
            int cx = listX1 + 1 + f.x()[i], cy = y + 14 + f.line()[i] * 15;
            boolean selected = i == current;
            boolean hover = over(cx, cy, cx + widths[i], cy + 12);
            Ui.roundRect(ctx, cx, cy, cx + widths[i], cy + 12, 3, selected ? th.primary() : hover ? 0x40FFFFFF : 0x1EFFFFFF);
            Ui.text(ctx, tr, s.options[i], cx + 4, cy + 2, selected ? 0xFF0B0B10 : hover ? Ui.WHITE : Ui.MUTED, 1f, false);
            final int index = i;
            listHit(cx, cy, cx + widths[i], cy + 12).click(() -> {
                cfg.set(module.id(), s.id, index);
                changed();
            }).alt(resetter(s)).tip(s.label + ": " + s.options[i]);
        }
        return h;
    }

    // -------- color

    private int presetCount() {
        return 2 + Colors.PRESETS.length;
    }

    private int[] presetWidths() {
        int[] w = new int[presetCount()];
        w[0] = tr.getWidth("Theme") + 9;
        w[1] = tr.getWidth("Rainbow") + 9;
        for (int i = 2; i < w.length; i++) w[i] = 12;
        return w;
    }

    private int pickerHeight() {
        Flow f = flow(presetWidths(), 3, listX2 - listX1 - 8);
        return 4 + f.lines() * 15 + 2 + SV_H + 5 + 10 + 6 + 15 + 5;
    }

    private Setting expandedSetting() {
        return expanded == null ? null : module.setting(expanded);
    }

    private void startPicker(Setting s) {
        int rgb = cfg.rgb(module.id(), s.id, time(), 0);
        float[] hsb = Colors.toHsb(rgb);
        pickH = hsb[0];
        pickS = hsb[1];
        pickV = hsb[2];
        hexBuf = String.format("%06X", rgb & 0xFFFFFF);
    }

    private void applyPick(Setting s) {
        int rgb = Colors.hsb(pickH, pickS, pickV) & 0xFFFFFF;
        cfg.set(module.id(), s.id, rgb);
        hexBuf = String.format("%06X", rgb);
        changed();
    }

    private void applyHex() {
        Setting s = expandedSetting();
        if (s == null || hexBuf.length() != 6) return;
        int rgb = Integer.parseInt(hexBuf, 16);
        cfg.set(module.id(), s.id, rgb);
        float[] hsb = Colors.toHsb(rgb);
        pickH = hsb[0];
        pickS = hsb[1];
        pickV = hsb[2];
        changed();
    }

    private void swatch(int x, int sy, int w, int h, Setting s) {
        double v = cfg.num(module.id(), s.id);
        if (v == Setting.COLOR_RAINBOW) {
            for (int i = 0; i < w; i++) {
                int c = Colors.rainbow((float) (time() * 0.25 + i / (double) w * 0.6));
                ctx.fill(x + i, sy, x + i + 1, sy + h, c);
            }
        } else {
            ctx.fill(x, sy, x + w, sy + h, 0xFF000000 | cfg.rgb(module.id(), s.id, time(), 0));
        }
        ctx.drawBorder(x - 1, sy - 1, w + 2, h + 2, 0x80FFFFFF);
    }

    private int colorRow(Setting s) {
        boolean open = s.id.equals(expanded);
        int h = 18;
        int extra = open ? pickerHeight() : 0;
        if (!vis(y, h + extra)) return h + extra;
        boolean hover = over(listX1, y, listX2, y + h);
        if (hover) Ui.roundRect(ctx, listX1, y, listX2, y + h, 3, 0x10FFFFFF);
        label(s, y + 5);
        int sx2 = listX2 - 4;
        swatch(sx2 - 22, y + 4, 22, 10, s);
        Ui.textRight(ctx, tr, s.format(cfg.num(module.id(), s.id)), sx2 - 28, y + 5, Ui.alpha(th.primary(), 0xC0), 0.8f, false);
        listHit(listX1, y, listX2, y + h).click(() -> {
            focus = null;
            if (open) {
                expanded = null;
            } else {
                expanded = s.id;
                startPicker(s);
            }
        }).alt(resetter(s)).tip(s.label + ": click to open the color picker");
        if (open) paintPicker(s, y + h);
        return h + extra;
    }

    private void paintPicker(Setting s, int py) {
        int x1 = listX1 + 4, x2 = listX2 - 4;
        int total = pickerHeight();
        Ui.roundRect(ctx, listX1, py, listX2, py + total - 2, 4, 0x16FFFFFF);

        // presets: Theme, Rainbow, then swatches
        int[] widths = presetWidths();
        Flow f = flow(widths, 3, x2 - x1);
        double current = cfg.num(module.id(), s.id);
        for (int i = 0; i < widths.length; i++) {
            int cx = x1 + f.x()[i], cy = py + 4 + f.line()[i] * 15;
            boolean hover = over(cx, cy, cx + widths[i], cy + 12);
            double value;
            if (i == 0) {
                value = Setting.COLOR_THEME;
                boolean sel = current == value;
                Ui.roundRect(ctx, cx, cy, cx + widths[i], cy + 12, 3, sel ? th.primary() : hover ? 0x40FFFFFF : 0x1EFFFFFF);
                Ui.text(ctx, tr, "Theme", cx + 4, cy + 2, sel ? 0xFF0B0B10 : Ui.MUTED, 1f, false);
            } else if (i == 1) {
                value = Setting.COLOR_RAINBOW;
                boolean sel = current == value;
                Ui.roundRect(ctx, cx, cy, cx + widths[i], cy + 12, 3, sel ? th.primary() : hover ? 0x40FFFFFF : 0x1EFFFFFF);
                Ui.text(ctx, tr, "Rainbow", cx + 4, cy + 2, sel ? 0xFF0B0B10 : Ui.MUTED, 1f, false);
            } else {
                int rgb = Colors.PRESETS[i - 2];
                value = rgb;
                boolean sel = current == value;
                ctx.fill(cx, cy + 1, cx + 11, cy + 12, 0xFF000000 | rgb);
                if (sel || hover) ctx.drawBorder(cx - 1, cy, 13, 13, sel ? Ui.WHITE : 0x90FFFFFF);
            }
            final double chosen = value;
            listHit(cx, cy, cx + widths[i], cy + 13).click(() -> {
                cfg.set(module.id(), s.id, chosen);
                if (chosen >= 0) {
                    float[] hsb = Colors.toHsb((int) chosen);
                    pickH = hsb[0];
                    pickS = hsb[1];
                    pickV = hsb[2];
                    hexBuf = String.format("%06X", (int) chosen);
                }
                changed();
            }).alt(resetter(s));
        }

        // saturation / brightness square
        int svW = Math.max(40, Math.min(x2 - x1, 220));
        int sy = py + 4 + f.lines() * 15 + 2;
        for (int cx = 0; cx < svW; cx += 2) {
            float sat = cx / (float) (svW - 1);
            ctx.fillGradient(x1 + cx, sy, x1 + Math.min(svW, cx + 2), sy + SV_H, Colors.hsb(pickH, sat, 1f), 0xFF000000);
        }
        int mxp = x1 + Math.round(pickS * (svW - 1)), myp = sy + Math.round((1f - pickV) * (SV_H - 1));
        ctx.drawBorder(mxp - 3, myp - 3, 7, 7, 0xFF000000);
        ctx.drawBorder(mxp - 2, myp - 2, 5, 5, Ui.WHITE);
        final int fsvW = svW, fsy = sy, fx1 = x1;
        listHit(x1 - 2, sy - 2, x1 + svW + 2, sy + SV_H + 2).drag((x, yy) -> {
            pickS = (float) Math.max(0.0, Math.min(1.0, (x - fx1) / (double) (fsvW - 1)));
            pickV = 1f - (float) Math.max(0.0, Math.min(1.0, (yy - fsy) / (double) (SV_H - 1)));
            applyPick(s);
        }).tip("Saturation / brightness");

        // hue bar
        int hy = sy + SV_H + 5;
        for (int cx = 0; cx < svW; cx += 2) {
            ctx.fill(x1 + cx, hy, x1 + Math.min(svW, cx + 2), hy + 10, Colors.hsb(cx / (float) (svW - 1), 1f, 1f));
        }
        int hx = x1 + Math.round(pickH * (svW - 1));
        ctx.fill(hx - 2, hy - 2, hx + 2, hy + 12, 0xFF000000);
        ctx.fill(hx - 1, hy - 1, hx + 1, hy + 11, Ui.WHITE);
        final int fhy = hy;
        listHit(x1 - 2, hy - 3, x1 + svW + 2, hy + 13).drag((x, yy) -> {
            pickH = (float) Math.max(0.0, Math.min(1.0, (x - fx1) / (double) (fsvW - 1)));
            applyPick(s);
        }).tip("Hue");

        // current color + hex field
        int ry = hy + 10 + 6;
        ctx.fill(x1, ry, x1 + 24, ry + 13, 0xFF000000 | cfg.rgb(module.id(), s.id, time(), 0));
        ctx.drawBorder(x1 - 1, ry - 1, 26, 15, 0x80FFFFFF);
        int fx = x1 + 32, fw = tr.getWidth("#FFFFFF") + 12;
        boolean focused = "hex".equals(focus);
        Ui.roundRect(ctx, fx, ry - 1, fx + fw, ry + 14, 3, focused ? Ui.alpha(th.primary(), 0xC0) : 0x30FFFFFF);
        Ui.roundRect(ctx, fx + 1, ry, fx + fw - 1, ry + 13, 2, 0xFF0B0D14);
        boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
        String shown = focused ? hexBuf : String.format("%06X", cfg.rgb(module.id(), s.id, time(), 0) & 0xFFFFFF);
        Ui.text(ctx, tr, "#" + shown + (focused && blink && hexBuf.length() < 6 ? "_" : ""), fx + 6, ry + 3, Ui.WHITE, 1f, false);
        listHit(fx, ry - 1, fx + fw, ry + 14).click(() -> {
            focus = "hex";
            hexBuf = "";
        }).tip("Type a hex color, for example FF3B30");
        Ui.text(ctx, tr, "hex", fx + fw + 6, ry + 3, Ui.DIM, 0.8f, false);
    }

    // -------- text

    private int textRow(Setting s) {
        int h = 31;
        if (!vis(y, h)) return h;
        label(s, y + 2);
        String key = "t:" + s.id;
        boolean focused = key.equals(focus);
        int fy = y + 14;
        Ui.roundRect(ctx, listX1, fy, listX2, fy + 15, 3, focused ? Ui.alpha(th.primary(), 0xC0) : 0x30FFFFFF);
        Ui.roundRect(ctx, listX1 + 1, fy + 1, listX2 - 1, fy + 14, 2, 0xFF0B0D14);
        String text = cfg.text(module.id(), s.id);
        int avail = listX2 - listX1 - 14;
        boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
        String shown = focused ? Ui.tail(tr, text, avail) + (blink ? "_" : "") : Ui.fit(tr, text, avail, 1f);
        Ui.text(ctx, tr, shown, listX1 + 6, fy + 4, Ui.WHITE, 1f, false);
        listHit(listX1, fy, listX2, fy + 15).click(() -> focus = key).alt(resetter(s)).tip("Click and type");
        return h;
    }
}
