package com.baroxvs.client;

/**
 * A clickable, right clickable or draggable rectangle of the menu. The menu rebuilds the list of these every
 * frame while it draws, so what you see is exactly what you can click. Coordinates are menu (virtual) pixels.
 */
final class GuiHit {
    /** Called on press and while the mouse is dragged, with the mouse position in menu pixels. */
    interface Drag {
        void at(double x, double y);
    }

    final int x1, y1, x2, y2;
    /** Scroll region this rectangle belongs to (dragging it scrolls that region), or -1. */
    final int region;
    Runnable click;
    Runnable alt;
    Drag drag;
    String tip;

    GuiHit(int x1, int y1, int x2, int y2, int region) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        this.region = region;
    }

    boolean contains(double x, double y) {
        return x >= x1 && x < x2 && y >= y1 && y < y2;
    }

    GuiHit click(Runnable r) { this.click = r; return this; }

    GuiHit alt(Runnable r) { this.alt = r; return this; }

    GuiHit drag(Drag d) { this.drag = d; return this; }

    GuiHit tip(String t) { this.tip = t; return this; }
}
