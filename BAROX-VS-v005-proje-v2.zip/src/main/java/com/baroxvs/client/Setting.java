package com.baroxvs.client;

import java.util.Locale;

/**
 * Description of one customisable option of a module (a switch, slider, choice, colour or text).
 * The ClickGUI builds its settings panel from these, the config stores the chosen values and the
 * renderers read them back, so every control in the menu is guaranteed to exist in the code.
 */
public final class Setting {
    public enum Kind { TOGGLE, SLIDER, CHOICE, COLOR, TEXT }

    /** Colour value meaning "follow the selected theme". */
    public static final double COLOR_THEME = -1;
    /** Colour value meaning "cycle through the rainbow". */
    public static final double COLOR_RAINBOW = -2;

    public final String id;
    public final String label;
    public final Kind kind;
    /** Default: 0/1 for toggles, the real value for sliders, an index for choices, packed RGB or a COLOR_ constant. */
    public final double def;
    public final double min;
    public final double max;
    public final double step;
    public final String[] options;
    public final String unit;
    /** Colour settings only: which theme colour is used while the value is COLOR_THEME (0 primary, 1 secondary). */
    public final int slot;
    public final String defText;

    private Setting(String id, String label, Kind kind, double def, double min, double max, double step,
                    String[] options, String unit, int slot, String defText) {
        this.id = id;
        this.label = label;
        this.kind = kind;
        this.def = def;
        this.min = min;
        this.max = max;
        this.step = step;
        this.options = options;
        this.unit = unit == null ? "" : unit;
        this.slot = slot;
        this.defText = defText == null ? "" : defText;
    }

    public static Setting toggle(String id, String label, boolean def) {
        return new Setting(id, label, Kind.TOGGLE, def ? 1 : 0, 0, 1, 1, null, "", 0, null);
    }

    public static Setting slider(String id, String label, double min, double max, double step, double def, String unit) {
        return new Setting(id, label, Kind.SLIDER, def, min, max, step, null, unit, 0, null);
    }

    public static Setting choice(String id, String label, int def, String... options) {
        return new Setting(id, label, Kind.CHOICE, def, 0, options.length - 1, 1, options, "", 0, null);
    }

    /** Colour option. def is a packed 0xRRGGBB value, COLOR_THEME or COLOR_RAINBOW. */
    public static Setting color(String id, String label, double def, int slot) {
        return new Setting(id, label, Kind.COLOR, def, 0, 0xFFFFFF, 1, null, "", slot, null);
    }

    public static Setting text(String id, String label, String def) {
        return new Setting(id, label, Kind.TEXT, 0, 0, 0, 1, null, "", 0, def);
    }

    /** Clamps a raw value into the legal range and snaps it to the step. */
    public double clamp(double v) {
        if (Double.isNaN(v) || Double.isInfinite(v)) return def;
        switch (kind) {
            case TOGGLE:
                return v >= 0.5 ? 1 : 0;
            case CHOICE:
                return Math.max(0, Math.min(options.length - 1, Math.round(v)));
            case COLOR:
                if (v == COLOR_THEME || v == COLOR_RAINBOW) return v;
                return Math.max(0, Math.min(0xFFFFFF, Math.round(v)));
            case SLIDER: {
                double snapped = min + Math.round((v - min) / step) * step;
                snapped = Math.max(min, Math.min(max, snapped));
                // remove floating point dust such as 0.30000000000000004
                return Math.round(snapped * 10000.0) / 10000.0;
            }
            default:
                return def;
        }
    }

    public int decimals() {
        if (step >= 1) return 0;
        if (step >= 0.1) return 1;
        return 2;
    }

    /** Human readable value, with a decimal comma like the rest of the HUD. */
    public String format(double v) {
        switch (kind) {
            case TOGGLE:
                return v >= 0.5 ? "On" : "Off";
            case CHOICE:
                return options[(int) Math.max(0, Math.min(options.length - 1, Math.round(v)))];
            case COLOR:
                if (v == COLOR_THEME) return "Theme";
                if (v == COLOR_RAINBOW) return "Rainbow";
                return String.format(Locale.ROOT, "#%06X", (int) v & 0xFFFFFF);
            case SLIDER:
                return String.format(Locale.ROOT, "%." + decimals() + "f", v).replace('.', ',') + unit;
            default:
                return "";
        }
    }
}
