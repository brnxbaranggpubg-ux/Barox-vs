package com.baroxvs.client;

import static com.baroxvs.client.CosmeticModels.al;
import static com.baroxvs.client.CosmeticModels.col;
import static com.baroxvs.client.CosmeticModels.lerp;

/** The cosmetics that float around the player (FEET frame, y = 0 is the ground): gyro rings, orbs, drone, hologram, rune. */
final class FloatModels {
    private FloatModels() {}

    private static final int S = Mesh.SOLID, G = Mesh.GLOW, H = Mesh.HALO;
    private static final float DEG = (float) Math.PI / 180f;
    private static final float TAU = (float) (Math.PI * 2);

    static void build(String id, Mesh m, BaroxConfig c, CosmeticModels.Anim a) {
        switch (id) {
            case "gyro": gyro(m, c, a); break;
            case "orbs": orbs(m, c, a); break;
            case "drone": drone(m, c, a); break;
            case "hologram": hologram(m, c, a); break;
            case "rune": rune(m, c, a); break;
            default: break;
        }
    }

    // ---------------------------------------------------------------- gyro rings

    private static void gyro(Mesh m, BaroxConfig c, CosmeticModels.Anim a) {
        String id = "gyro";
        int n = Math.max(1, Math.min(4, c.idx(id, "rings")));
        int c1 = col(c, id, "color", a, 0f), c2 = col(c, id, "color2", a, 0.3f);
        float radius = c.f(id, "radius"), speed = c.f(id, "speed"), th = c.f(id, "thickness"), tilt = c.f(id, "tilt") * DEG;
        float gl = c.f(id, "glow") / 100f;
        m.push();
        m.translate(0f, 1.0f, 0f);
        for (int k = 0; k < n; k++) {
            float r = 0.72f * radius * (1f + 0.14f * k);
            float dir = k % 2 == 0 ? 1f : -1f;
            int cc = k % 2 == 0 ? c1 : c2;
            int bright = Colors.lighten(cc, 0.45f);
            m.push();
            m.rotY(k * 2.1f + a.time * speed * dir * (1.1f - 0.18f * k));
            m.rotX(tilt * (0.4f + 0.6f * (k + 1f) / n) * dir);
            m.rotZ(k * 0.9f);
            float w = 0.014f * th;
            m.ring(G, r - w, r + w, 0.022f * th, 56, al(cc, 0.95f), al(bright, 0.95f));
            for (int i = 0; i < 12; i++) { // tick marks on the outside
                m.push();
                m.rotY(i * TAU / 12f);
                m.translate(r + w + 0.018f, 0f, 0f);
                m.box(G, 0f, 0f, 0f, 0.034f, 0.012f * th + 0.004f, 0.014f, al(bright, 0.85f));
                m.pop();
            }
            float bead = a.time * speed * 2.4f * dir + k;
            m.push();
            m.translate((float) Math.cos(bead) * r, 0f, (float) Math.sin(bead) * r);
            m.sphere(G, 0.035f * (0.7f + 0.3f * th), 0, al(Colors.lighten(cc, 0.7f), 1f), al(cc, 1f));
            if (gl > 0.02f) m.sphere(H, 0.085f, 0, al(cc, gl * 0.5f), al(cc, gl * 0.5f));
            m.pop();
            if (gl > 0.02f) {
                m.fadeRing(H, r - 0.09f, r - w, 40, al(cc, 0f), al(cc, gl * 0.4f));
                m.fadeRing(H, r + w, r + 0.09f, 40, al(cc, gl * 0.4f), al(cc, 0f));
            }
            m.pop();
        }
        m.pop();
    }

    // ---------------------------------------------------------------- orbit orbs

    private static void orbShape(Mesh m, int shape, int cc, float gl) {
        float s = 0.12f;
        int bright = Colors.lighten(cc, 0.5f), dark = Colors.shade(cc, 0.6f);
        switch (shape) {
            case 1: // cube with glowing edges
                m.box(S, 0f, 0f, 0f, s * 1.7f, s * 1.7f, s * 1.7f, dark);
                for (int i = 0; i < 4; i++) {
                    float x = (i & 1) == 0 ? -s * 0.85f : s * 0.85f, y = (i & 2) == 0 ? -s * 0.85f : s * 0.85f;
                    m.bar(G, x, y, -s * 0.85f, x, y, s * 0.85f, 0.014f, al(bright, 1f));
                    m.bar(G, -s * 0.85f, x, y, s * 0.85f, x, y, 0.014f, al(bright, 1f));
                    m.bar(G, x, -s * 0.85f, y, x, s * 0.85f, y, 0.014f, al(bright, 1f));
                }
                break;
            case 2: // diamond
                m.bipyramid(S, s * 0.85f, s * 1.5f, s * 1.5f, 4, bright, dark, cc);
                break;
            case 3: // star: three crossing spikes
                for (int i = 0; i < 3; i++) {
                    m.push();
                    if (i == 1) m.rotZ(90f * DEG);
                    if (i == 2) m.rotX(90f * DEG);
                    m.bipyramid(S, s * 0.32f, s * 1.8f, s * 1.8f, 4, bright, bright, cc);
                    m.pop();
                }
                m.sphere(S, s * 0.5f, 0, bright, cc);
                break;
            case 4: // crystal
                m.bipyramid(S, s * 0.7f, s * 1.9f, s * 1.1f, 6, bright, dark, cc);
                if (gl > 0.02f) m.bipyramid(G, s * 0.85f, s * 2.15f, s * 1.3f, 6, al(bright, gl * 0.3f), al(cc, gl * 0.2f), al(cc, gl * 0.25f));
                break;
            default: // orb
                m.sphere(S, s, 1, bright, dark);
                break;
        }
        if (gl > 0.02f) m.sphere(H, s * 2.3f, 1, al(cc, gl * 0.32f), al(cc, gl * 0.32f));
    }

    private static void orbs(Mesh m, BaroxConfig c, CosmeticModels.Anim a) {
        String id = "orbs";
        int n = Math.max(1, Math.min(12, c.idx(id, "count")));
        int c1 = col(c, id, "color", a, 0f), c2 = col(c, id, "color2", a, 0.3f);
        float radius = c.f(id, "radius"), speed = c.f(id, "speed"), size = c.f(id, "size"), height = c.f(id, "height");
        float bobAmt = c.f(id, "bob") / 100f, gl = c.f(id, "glow") / 100f;
        int shape = c.idx(id, "shape");
        for (int i = 0; i < n; i++) {
            float ang = a.time * speed * 1.3f + i * TAU / n;
            float bob = (float) Math.sin(a.time * 1.8f + i * 1.7f) * 0.14f * bobAmt;
            m.push();
            m.translate((float) Math.cos(ang) * radius, height + bob, (float) Math.sin(ang) * radius);
            m.rotY(a.time * 1.6f + i);
            m.rotX(a.time * 1.1f + i * 0.7f);
            m.scale(size);
            orbShape(m, shape, i % 2 == 0 ? c1 : c2, gl);
            m.pop();
        }
    }

    // ---------------------------------------------------------------- drone

    private static void drone(Mesh m, BaroxConfig c, CosmeticModels.Anim a) {
        String id = "drone";
        int main = col(c, id, "color", a, 0f), acc = col(c, id, "accent", a, 0.3f);
        float size = c.f(id, "size"), gl = c.f(id, "glow") / 100f;
        int design = c.idx(id, "design");
        float x = c.idx(id, "side") == 0 ? -0.82f : 0.82f; // +X is the player's left
        float bob = (float) Math.sin(a.time * 2.1f) * 0.07f;
        int steel = Colors.lerp(Colors.shade(main, 0.55f), 0xFFAEB7CC, 0.4f);
        int bright = Colors.lighten(acc, 0.55f);
        m.push();
        m.translate(x, 1.85f + bob, 0.05f + (float) Math.sin(a.time * 1.3f) * 0.05f);
        m.rotY((float) Math.sin(a.time * 0.8f) * 0.35f);
        m.rotZ((float) Math.sin(a.time * 1.7f) * 0.08f);
        m.scale(size * 1.45f);
        switch (design) {
            case 1: // orb with an equator ring
                m.sphere(S, 0.1f, 1, Colors.lighten(steel, 0.25f), Colors.shade(steel, 0.6f));
                m.push();
                m.rotY(a.time * 1.2f);
                m.rotX(0.5f);
                m.ring(G, 0.125f, 0.14f, 0.02f, 32, al(acc, 0.95f), al(bright, 0.95f));
                m.pop();
                m.push();
                m.translate(0f, 0.01f, -0.092f);
                m.sphere(G, 0.034f, 0, al(bright, 1f), al(acc, 1f));
                m.pop();
                break;
            case 2: // cube
                m.box(S, 0f, 0f, 0f, 0.17f, 0.17f, 0.17f, Colors.shade(steel, 0.85f));
                for (int i = 0; i < 4; i++) {
                    float sx = (i & 1) == 0 ? -0.085f : 0.085f, sy = (i & 2) == 0 ? -0.085f : 0.085f;
                    m.bar(G, sx, sy, -0.085f, sx, sy, 0.085f, 0.014f, al(acc, 1f));
                    m.bar(G, -0.085f, sx, sy, 0.085f, sx, sy, 0.014f, al(acc, 1f));
                    m.bar(G, sx, -0.085f, sy, sx, 0.085f, sy, 0.014f, al(acc, 1f));
                }
                m.box(G, 0f, 0.01f, -0.092f, 0.1f, 0.03f, 0.012f, al(bright, 1f));
                break;
            case 3: // two crossing rings around a core
                m.sphere(G, 0.05f, 0, al(bright, 1f), al(acc, 1f));
                m.push();
                m.rotY(a.time * 1.4f);
                m.rotX(90f * DEG);
                m.ring(G, 0.1f, 0.112f, 0.02f, 32, al(acc, 0.95f), al(bright, 0.95f));
                m.pop();
                m.push();
                m.rotY(-a.time * 1.1f);
                m.ring(G, 0.125f, 0.137f, 0.02f, 32, al(bright, 0.95f), al(acc, 0.95f));
                m.pop();
                break;
            default: // quad drone
                m.box(S, 0f, 0f, 0f, 0.16f, 0.06f, 0.16f, steel);
                m.sphere(S, 0.055f, 1, Colors.lighten(steel, 0.3f), steel);
                for (int i = 0; i < 4; i++) {
                    float sx = (i & 1) == 0 ? -0.19f : 0.19f, sz = (i & 2) == 0 ? -0.19f : 0.19f;
                    m.bar(S, 0f, 0f, 0f, sx, 0.012f, sz, 0.024f, 0.018f, Colors.shade(steel, 0.8f), Colors.shade(steel, 0.8f));
                    m.box(S, sx, 0.02f, sz, 0.045f, 0.035f, 0.045f, Colors.shade(steel, 0.6f));
                    m.push();
                    m.translate(sx, 0.045f, sz);
                    m.rotY(a.time * 32f * (i % 2 == 0 ? 1f : -1f));
                    m.bar(G, -0.1f, 0f, 0f, 0.1f, 0f, 0f, 0.012f, 0.004f, al(acc, 0.7f), al(acc, 0.7f));
                    m.pop();
                    m.push();
                    m.translate(sx, 0.045f, sz);
                    m.fadeRing(H, 0.02f, 0.11f, 16, al(acc, gl * 0.3f), al(acc, 0f));
                    m.pop();
                }
                m.box(G, 0f, 0.0f, -0.085f, 0.09f, 0.025f, 0.012f, al(bright, 1f));
                m.box(G, 0f, -0.035f, 0f, 0.06f, 0.01f, 0.06f, al(acc, 0.9f));
                break;
        }
        if (gl > 0.02f) m.sphere(H, 0.2f, 1, al(acc, gl * 0.2f), al(acc, gl * 0.2f));
        m.pop();
    }

    // ---------------------------------------------------------------- hologram

    private static void wire(Mesh m, int shape, float r, float th, int cc, float gl) {
        float w = 0.011f * th + 0.004f;
        int line = al(cc, 0.95f), node = al(Colors.lighten(cc, 0.6f), 1f), face = al(cc, 0.05f + 0.12f * gl);
        float[][] v;
        int[][] edges;
        int[][] faces;
        if (shape == 1) { // octahedron
            v = new float[][]{{r, 0, 0}, {-r, 0, 0}, {0, r, 0}, {0, -r, 0}, {0, 0, r}, {0, 0, -r}};
            edges = new int[][]{{0, 2}, {0, 3}, {0, 4}, {0, 5}, {1, 2}, {1, 3}, {1, 4}, {1, 5}, {2, 4}, {2, 5}, {3, 4}, {3, 5}};
            faces = new int[][]{{0, 2, 4}, {4, 2, 1}, {1, 2, 5}, {5, 2, 0}, {0, 4, 3}, {4, 1, 3}, {1, 5, 3}, {5, 0, 3}};
        } else if (shape == 2) { // elongated diamond
            float q = r * 0.78f;
            v = new float[][]{{0, r * 1.3f, 0}, {0, -r * 1.3f, 0}, {q, 0, 0}, {0, 0, q}, {-q, 0, 0}, {0, 0, -q}};
            edges = new int[][]{{0, 2}, {0, 3}, {0, 4}, {0, 5}, {1, 2}, {1, 3}, {1, 4}, {1, 5}, {2, 3}, {3, 4}, {4, 5}, {5, 2}};
            faces = new int[][]{{0, 2, 3}, {0, 3, 4}, {0, 4, 5}, {0, 5, 2}, {1, 3, 2}, {1, 4, 3}, {1, 5, 4}, {1, 2, 5}};
        } else { // cube
            float h = r * 0.62f;
            v = new float[8][];
            for (int i = 0; i < 8; i++) v[i] = new float[]{(i & 1) == 0 ? -h : h, (i & 2) == 0 ? -h : h, (i & 4) == 0 ? -h : h};
            edges = new int[][]{{0, 1}, {2, 3}, {4, 5}, {6, 7}, {0, 2}, {1, 3}, {4, 6}, {5, 7}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
            faces = null;
            if (gl > 0.02f) {
                int[][] quads = {{0, 1, 3, 2}, {4, 5, 7, 6}, {0, 1, 5, 4}, {2, 3, 7, 6}, {0, 2, 6, 4}, {1, 3, 7, 5}};
                for (int[] q : quads) {
                    m.sheet(H, v[q[0]][0], v[q[0]][1], v[q[0]][2], v[q[1]][0], v[q[1]][1], v[q[1]][2],
                            v[q[2]][0], v[q[2]][1], v[q[2]][2], v[q[3]][0], v[q[3]][1], v[q[3]][2], face, face, face, face);
                }
            }
        }
        for (int[] e : edges) m.bar(G, v[e[0]][0], v[e[0]][1], v[e[0]][2], v[e[1]][0], v[e[1]][1], v[e[1]][2], w, line);
        for (float[] p : v) m.box(G, p[0], p[1], p[2], w * 3.2f, w * 3.2f, w * 3.2f, node);
        if (faces != null && gl > 0.02f) {
            for (int[] f : faces) {
                m.sheetTri(H, v[f[0]][0], v[f[0]][1], v[f[0]][2], v[f[1]][0], v[f[1]][1], v[f[1]][2], v[f[2]][0], v[f[2]][1], v[f[2]][2], face, face, face);
            }
        }
    }

    private static void hologram(Mesh m, BaroxConfig c, CosmeticModels.Anim a) {
        String id = "hologram";
        int cc = col(c, id, "color", a, 0f);
        float size = c.f(id, "size"), speed = c.f(id, "speed"), th = c.f(id, "thickness"), gl = c.f(id, "glow") / 100f;
        int shape = c.idx(id, "shape");
        m.push();
        m.translate(0f, 1.0f, 0f);
        m.rotY(a.time * speed * 0.9f);
        m.rotX(0.35f + (float) Math.sin(a.time * 0.7f) * 0.12f);
        wire(m, shape, 0.78f * size, th, cc, gl);
        if (c.flag(id, "inner")) {
            m.push();
            m.rotY(-a.time * speed * 1.8f);
            m.rotZ(a.time * speed * 0.8f);
            wire(m, shape, 0.36f * size, th, Colors.lighten(cc, 0.25f), gl);
            m.pop();
        }
        m.pop();
    }

    // ---------------------------------------------------------------- floor rune

    /** Flat strip on the floor between two points (always visible from above). */
    private static void floorBar(Mesh m, float x0, float z0, float x1, float z1, float width, int c) {
        float dx = x1 - x0, dz = z1 - z0;
        float len = (float) Math.sqrt(dx * dx + dz * dz);
        if (len < 1e-6f) return;
        float nx = -dz / len * width / 2f, nz = dx / len * width / 2f;
        m.sheet(G, x0 - nx, 0f, z0 - nz, x1 - nx, 0f, z1 - nz, x1 + nx, 0f, z1 + nz, x0 + nx, 0f, z0 + nz, c, c, c, c);
    }

    private static void polygonRing(Mesh m, int sides, float r, float rot, float width, int c) {
        for (int i = 0; i < sides; i++) {
            float a0 = rot + i * TAU / sides, a1 = rot + (i + 1) * TAU / sides;
            floorBar(m, (float) Math.cos(a0) * r, (float) Math.sin(a0) * r, (float) Math.cos(a1) * r, (float) Math.sin(a1) * r, width, c);
        }
    }

    private static void rune(Mesh m, BaroxConfig c, CosmeticModels.Anim a) {
        String id = "rune";
        int cc = col(c, id, "color", a, 0f);
        float size = c.f(id, "size"), speed = c.f(id, "speed"), gl = c.f(id, "glow") / 100f;
        float pulse = c.flag(id, "pulse") ? 1f + 0.035f * (float) Math.sin(a.time * 3f) : 1f;
        int design = c.idx(id, "design");
        int line = al(cc, 0.95f), soft = al(cc, 0.6f), bright = al(Colors.lighten(cc, 0.5f), 1f);
        float spin = a.time * speed * 0.6f;
        m.push();
        m.translate(0f, 0.018f, 0f);
        m.scale(size * pulse);
        float R = 1.0f;
        switch (design) {
            case 1: { // ripple rings
                for (int k = 0; k < 3; k++) polygonRing(m, 48, R * (1f - 0.28f * k), 0f, 0.025f - 0.005f * k, k == 0 ? line : soft);
                float rip = (a.time * 0.45f * Math.max(0.2f, speed)) % 1f;
                float rr = 0.2f + rip * 0.8f;
                m.fadeRing(H, rr - 0.14f, rr, 40, al(cc, 0f), al(cc, 0.5f * (1f - rip) * (0.4f + gl)));
                m.fadeRing(H, rr, rr + 0.04f, 40, al(cc, 0.5f * (1f - rip) * (0.4f + gl)), al(cc, 0f));
                break;
            }
            case 2: { // hexagons
                polygonRing(m, 6, R, spin * 0.3f, 0.035f, line);
                polygonRing(m, 6, R * 0.78f, -spin * 0.5f, 0.022f, soft);
                polygonRing(m, 6, R * 0.52f, spin * 0.7f, 0.022f, line);
                for (int i = 0; i < 6; i++) {
                    float ang = spin * 0.3f + i * TAU / 6f;
                    m.box(G, (float) Math.cos(ang) * R, 0f, (float) Math.sin(ang) * R, 0.07f, 0.004f, 0.07f, bright);
                }
                break;
            }
            case 3: { // radar sweep
                polygonRing(m, 48, R, 0f, 0.03f, line);
                polygonRing(m, 48, R * 0.66f, 0f, 0.016f, soft);
                polygonRing(m, 48, R * 0.33f, 0f, 0.016f, soft);
                floorBar(m, -R, 0f, R, 0f, 0.012f, soft);
                floorBar(m, 0f, -R, 0f, R, 0.012f, soft);
                float sweep = a.time * speed * 2.2f;
                int steps = 14;
                for (int i = 0; i < steps; i++) {
                    float a0 = sweep - i * 0.07f, a1 = sweep - (i + 1) * 0.07f;
                    int ca = al(cc, 0.55f * (1f - i / (float) steps)), cb = al(cc, 0.55f * (1f - (i + 1f) / steps));
                    m.sheetTri(G, 0f, 0f, 0f, (float) Math.cos(a0) * R, 0f, (float) Math.sin(a0) * R, (float) Math.cos(a1) * R, 0f, (float) Math.sin(a1) * R, ca, ca, cb);
                }
                floorBar(m, 0f, 0f, (float) Math.cos(sweep) * R, (float) Math.sin(sweep) * R, 0.02f, bright);
                break;
            }
            default: { // magic circle
                polygonRing(m, 56, R, 0f, 0.035f, line);
                polygonRing(m, 56, R * 0.84f, 0f, 0.02f, soft);
                for (int i = 0; i < 16; i++) { // glyph ticks between the rings
                    float ang = i * TAU / 16f + spin * 0.15f;
                    float r0 = R * 0.87f, r1 = R * (i % 2 == 0 ? 0.97f : 0.93f);
                    floorBar(m, (float) Math.cos(ang) * r0, (float) Math.sin(ang) * r0, (float) Math.cos(ang) * r1, (float) Math.sin(ang) * r1, 0.028f, bright);
                }
                float rot = spin;
                polygonRing(m, 3, R * 0.8f, rot, 0.022f, line);
                polygonRing(m, 3, R * 0.8f, rot + (float) Math.PI, 0.022f, line);
                polygonRing(m, 5, R * 0.36f, -rot * 1.4f, 0.018f, soft);
                m.sphere(G, 0.03f, 0, bright, al(cc, 1f));
                break;
            }
        }
        if (gl > 0.02f) {
            m.fadeRing(H, R - 0.28f, R, 48, al(cc, 0f), al(cc, 0.3f * gl));
            m.fadeRing(H, R, R + 0.22f, 48, al(cc, 0.3f * gl), al(cc, 0f));
        }
        m.pop();
    }
}
