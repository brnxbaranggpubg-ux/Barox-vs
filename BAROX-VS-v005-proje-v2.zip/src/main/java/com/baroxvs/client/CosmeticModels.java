package com.baroxvs.client;

/**
 * Builds the 3D cosmetics. Every module reads its look from the config (colour, size, design, speed, glow ...)
 * and writes quads into a {@link Mesh}. Pure Java, so the game, the menu preview and the offline tests share it.
 *
 * <p>Each cosmetic lives in one of three frames, see {@link #frameOf}:
 * FEET (origin on the ground below the player, turning with the body), BODY (origin at the neck, follows the
 * body including sneaking) and HEAD (origin at the neck, follows the head). In all of them +Y is up and
 * +Z points to the player's back.
 */
final class CosmeticModels {
    private CosmeticModels() {}

    static final int FEET = 0, BODY = 1, HEAD = 2;

    /** Height of the neck above the ground, the origin of the BODY and HEAD frames. */
    static final float NECK = 1.501f;

    private static final int S = Mesh.SOLID, G = Mesh.GLOW, H = Mesh.HALO;
    static final float DEG = (float) Math.PI / 180f;

    /** Animation inputs of one frame. */
    static final class Anim {
        /** Seconds, drives every animation. */
        float time;
        /** 0 = standing still, 1 = running or flying, smoothed by the renderer. */
        float activity;
        boolean airborne;
        boolean sneaking;
    }

    static int frameOf(String id) {
        switch (id) {
            case "wings": case "tail": case "cape": case "jetpack":
                return BODY;
            case "halo": case "crown": case "horns": case "ears": case "visor":
                return HEAD;
            default:
                return FEET;
        }
    }

    /** Builds the module's mesh in its own frame (the caller has already set up the frame transform). */
    static void build(String id, Mesh m, BaroxConfig c, Anim a) {
        switch (id) {
            case "wings": wings(m, c, a); break;
            case "halo": halo(m, c, a); break;
            case "crown": crown(m, c, a); break;
            case "horns": horns(m, c, a); break;
            case "ears": ears(m, c, a); break;
            case "tail": tail(m, c, a); break;
            case "visor": visor(m, c, a); break;
            case "cape": cape(m, c, a); break;
            case "jetpack": jetpack(m, c, a); break;
            default: FloatModels.build(id, m, c, a); break;
        }
    }

    // ---------------------------------------------------------------- helpers

    /** Opaque ARGB of a colour setting; phase offsets the rainbow. */
    static int col(BaroxConfig c, String id, String setting, Anim a, float phase) {
        return 0xFF000000 | c.rgb(id, setting, a.time, phase);
    }

    static int al(int rgb, float alpha) {
        return Colors.withAlpha(rgb, Math.round(255f * Math.max(0f, Math.min(1f, alpha))));
    }

    static float lerp(float x, float y, float t) { return x + (y - x) * t; }

    private static float glow(BaroxConfig c, String id) { return c.f(id, "glow") / 100f; }

    // ---------------------------------------------------------------- wings

    private static void wings(Mesh m, BaroxConfig c, Anim a) {
        String id = "wings";
        WingModels.P p = new WingModels.P();
        p.design = c.idx(id, "design");
        p.c1 = col(c, id, "color", a, 0f);
        p.c2 = col(c, id, "color2", a, 0.12f);
        p.accent = col(c, id, "accent", a, 0.3f);
        p.size = c.f(id, "size");
        p.spread = c.f(id, "spread") / 100f;
        p.flapSpeed = c.f(id, "flap_speed");
        p.flapAmount = c.f(id, "flap_amount") / 100f;
        p.thick = c.f(id, "thickness");
        p.opacity = c.f(id, "opacity") / 100f;
        p.glow = glow(c, id);
        p.n = c.idx(id, "feathers");
        p.height = c.f(id, "height");
        p.back = c.f(id, "back");
        p.time = a.time;
        switch (c.idx(id, "animation")) {
            case 1: p.activity = a.activity; break;                 // when moving
            case 2: p.activity = a.airborne ? 1f : 0.05f; break;    // in air only
            case 3: p.activity = 0f; p.flapAmount = 0f; p.time = 0f; break; // static
            default: p.activity = 1f; break;
        }
        WingModels.build(m, p);
    }

    // ---------------------------------------------------------------- halo

    private static void halo(Mesh m, BaroxConfig c, Anim a) {
        String id = "halo";
        int col = col(c, id, "color", a, 0f);
        float size = c.f(id, "size"), th = c.f(id, "thickness"), gl = glow(c, id);
        float bob = c.flag(id, "bob") ? (float) Math.sin(a.time * 2.0f) * 0.025f : 0f;
        m.push();
        m.translate(0f, 0.56f + c.f(id, "height") + bob, 0f);
        m.rotX(c.f(id, "tilt") * DEG);
        m.rotY(a.time * c.f(id, "spin") * 1.6f);
        m.scale(size);
        float h = 0.03f * th;
        int bright = Colors.lighten(col, 0.45f);
        switch (c.idx(id, "design")) {
            case 1: // two rings
                m.ring(G, 0.265f, 0.31f, h, 40, col, bright);
                m.push();
                m.translate(0f, -0.05f, 0f);
                m.ring(G, 0.17f, 0.205f, h * 0.9f, 32, bright, col);
                m.pop();
                break;
            case 2: // ring with spikes
                m.ring(G, 0.27f, 0.305f, h, 40, col, bright);
                for (int i = 0; i < 12; i++) {
                    m.push();
                    m.rotY(i * 30f * DEG);
                    m.translate(0.305f, 0f, 0f);
                    m.rotZ(-90f * DEG);
                    m.pyramid(G, 0.026f * (0.6f + 0.4f * th), 0.11f, 4, col, bright);
                    m.pop();
                }
                break;
            case 3: // hexagon
                m.ring(G, 0.265f, 0.32f, h * 1.2f, 6, col, bright);
                m.push();
                m.rotY(30f * DEG);
                m.ring(G, 0.145f, 0.17f, h * 0.8f, 6, bright, col);
                m.pop();
                break;
            default:
                m.ring(G, 0.265f, 0.31f, h, 48, col, bright);
                break;
        }
        if (gl > 0.02f) m.fadeRing(H, 0.18f, 0.46f, 40, al(col, gl * 0.5f), al(col, 0f));
        m.pop();
    }

    // ---------------------------------------------------------------- crown

    private static void crown(Mesh m, BaroxConfig c, Anim a) {
        String id = "crown";
        int gold = col(c, id, "color", a, 0f), gem = col(c, id, "gem", a, 0.3f);
        float gl = glow(c, id);
        int bright = Colors.lighten(gold, 0.4f), dark = Colors.shade(gold, 0.7f);
        m.push();
        m.translate(0f, 0.52f + c.f(id, "height"), 0f);
        m.scale(c.f(id, "size"));
        float w = 0.27f, bh = 0.07f, t = 0.04f;
        int design = c.idx(id, "design");
        int bandColor = design == 3 ? Colors.shade(gold, 0.45f) : gold;
        m.box(S, 0f, bh / 2, -w, 2 * w + t, bh, t, bandColor);
        m.box(S, 0f, bh / 2, w, 2 * w + t, bh, t, bandColor);
        m.box(S, -w, bh / 2, 0f, t, bh, 2 * w, bandColor);
        m.box(S, w, bh / 2, 0f, t, bh, 2 * w, bandColor);
        if (design == 3) { // neon trim
            m.box(G, 0f, bh * 0.85f, -w - 0.022f, 2 * w, 0.012f, 0.006f, al(gem, 0.5f + gl * 0.5f));
            m.box(G, 0f, bh * 0.85f, w + 0.022f, 2 * w, 0.012f, 0.006f, al(gem, 0.5f + gl * 0.5f));
            m.box(G, -w - 0.022f, bh * 0.85f, 0f, 0.006f, 0.012f, 2 * w, al(gem, 0.5f + gl * 0.5f));
            m.box(G, w + 0.022f, bh * 0.85f, 0f, 0.006f, 0.012f, 2 * w, al(gem, 0.5f + gl * 0.5f));
            for (int i = 0; i < 5; i++) {
                float ang = a.time * 0.9f + i * (float) (Math.PI * 2 / 5);
                float hover = 0.20f + 0.03f * (float) Math.sin(a.time * 2f + i);
                m.push();
                m.translate((float) Math.cos(ang) * 0.27f, bh + hover, (float) Math.sin(ang) * 0.27f);
                m.rotY(a.time * 1.5f + i);
                m.bipyramid(G, 0.035f, 0.075f, 0.045f, 4, al(Colors.lighten(gem, 0.5f), 0.95f), al(gem, 0.8f), al(gem, 0.9f));
                m.pop();
            }
        } else if (design == 1) { // tall spikes
            float[][] spots = {{0f, -w}, {-w, -w * 0.3f}, {w, -w * 0.3f}, {-w * 0.7f, w}, {w * 0.7f, w}, {0f, w}};
            for (int i = 0; i < spots.length; i++) {
                m.push();
                m.translate(spots[i][0], bh - 0.005f, spots[i][1]);
                m.pyramid(S, 0.04f, i == 0 ? 0.26f : 0.2f, 4, gold, bright);
                m.pop();
            }
        } else if (design == 2) { // flames
            for (int i = 0; i < 9; i++) {
                float ang = i * (float) (Math.PI * 2 / 9);
                float sway = (float) Math.sin(a.time * 4f + i * 1.7f) * 0.012f;
                m.push();
                m.translate((float) Math.cos(ang) * (w - 0.01f) + sway, bh - 0.005f, (float) Math.sin(ang) * (w - 0.01f));
                m.pyramid(G, 0.036f, 0.14f + 0.05f * (float) Math.sin(a.time * 6f + i * 2.3f), 3, al(gold, 0.95f), al(gem, 0.9f));
                m.pop();
            }
        } else { // royal
            float[][] spots = {{-w, -w}, {0f, -w}, {w, -w}, {-w, 0f}, {w, 0f}, {-w, w}, {0f, w}, {w, w}};
            for (int i = 0; i < spots.length; i++) {
                boolean corner = (i == 0 || i == 2 || i == 5 || i == 7);
                m.push();
                m.translate(spots[i][0], bh - 0.005f, spots[i][1]);
                m.pyramid(S, 0.045f, corner ? 0.17f : 0.12f, 4, gold, bright);
                m.translate(0f, corner ? 0.17f : 0.12f, 0f);
                m.sphere(S, 0.022f, 0, bright, dark);
                m.pop();
            }
        }
        // gem on the front
        m.push();
        m.translate(0f, bh * 0.55f, -w - 0.03f);
        m.bipyramid(S, 0.035f, 0.05f, 0.05f, 6, Colors.lighten(gem, 0.5f), Colors.shade(gem, 0.6f), gem);
        if (gl > 0.02f) m.bipyramid(G, 0.045f, 0.065f, 0.065f, 6, al(Colors.lighten(gem, 0.3f), gl * 0.55f), al(gem, gl * 0.35f), al(gem, gl * 0.45f));
        m.pop();
        m.pop();
    }

    // ---------------------------------------------------------------- horns

    /** Curved horn along a parametric path (x grows outwards, z backwards). */
    private static void curvedHorn(Mesh m, int lyr, float len, float w0, float w1, float bendX, float bendZ, int segs, int cBase, int cTip) {
        float px = 0, py = 0, pz = 0;
        for (int i = 1; i <= segs; i++) {
            float t = i / (float) segs;
            float nx = bendX * t * t, ny = len * t, nz = bendZ * t * t;
            float w = lerp(w0, w1, (i - 0.5f) / segs);
            m.bar(lyr, px, py, pz, nx, ny, nz, w, w, Colors.lerp(cBase, cTip, (i - 1f) / segs), Colors.lerp(cBase, cTip, (float) i / segs));
            px = nx; py = ny; pz = nz;
        }
    }

    private static void horns(Mesh m, BaroxConfig c, Anim a) {
        String id = "horns";
        int base = col(c, id, "color", a, 0f), tip = col(c, id, "tip", a, 0.2f);
        float size = c.f(id, "size"), spread = c.f(id, "spread") / 100f, gl = glow(c, id);
        int design = c.idx(id, "design");
        m.push();
        m.translate(0f, 0.5f, 0f);
        m.scale(size);
        if (design == 1) { // unicorn: one spiral horn in the middle
            m.push();
            m.translate(0f, 0.02f, -0.15f);
            m.rotX(-18f * DEG);
            int segs = 9;
            for (int i = 0; i < segs; i++) {
                float t0 = i / (float) segs, t1 = (i + 1f) / segs;
                float w0 = lerp(0.09f, 0.012f, t0), w1 = lerp(0.09f, 0.012f, t1);
                int ca = i % 2 == 0 ? Colors.lerp(base, tip, t0) : Colors.lighten(Colors.lerp(base, tip, t0), 0.45f);
                m.bar(S, 0f, t0 * 0.5f, 0f, 0f, t1 * 0.5f, 0f, (w0 + w1) / 2f, (w0 + w1) / 2f, ca, ca);
            }
            if (gl > 0.02f) m.sphere(H, 0.06f, 0, al(tip, gl * 0.6f), al(tip, 0f));
            m.pop();
        } else if (design == 3) { // spikes along the top of the head
            for (int i = 0; i < 5; i++) {
                float u = i / 4f;
                m.push();
                m.translate(lerp(-0.2f, 0.2f, u), 0f, lerp(0.02f, 0.14f, 1f - Math.abs(u - 0.5f) * 2f));
                m.rotX(12f * DEG);
                m.rotZ(lerp(-18f, 18f, u) * DEG);
                m.pyramid(S, 0.045f, 0.12f + 0.08f * (1f - Math.abs(u - 0.5f) * 2f), 5, base, tip);
                m.pop();
            }
        } else {
            for (int side = 0; side < 2; side++) {
                m.push();
                if (side == 1) m.scale(-1f, 1f, 1f);
                m.translate(0.1f + 0.12f * spread, 0f, -0.07f);
                if (design == 2) { // ram: planar spiral that curls up, out, down and back in
                    int segs = 16;
                    float r0 = 0.15f;
                    float lx = 0f, ly = 0f;
                    for (int i = 1; i <= segs; i++) {
                        float t = i / (float) segs;
                        float ang = (float) Math.toRadians(180f - 320f * t);
                        float r = r0 * (1f - 0.5f * t);
                        float x = r0 + (float) Math.cos(ang) * r, y = (float) Math.sin(ang) * r;
                        float w = lerp(0.1f, 0.03f, t);
                        int c0 = Colors.lerp(base, tip, (i - 1f) / segs), c1 = Colors.lerp(base, tip, (float) i / segs);
                        m.bar(S, lx, ly, 0f, x, y, 0f, w, w, c0, c1);
                        lx = x;
                        ly = y;
                    }
                } else { // devil
                    m.rotZ(-spread * 22f * DEG);
                    curvedHorn(m, S, 0.34f, 0.095f, 0.016f, 0.11f, 0.07f, 7, base, tip);
                    if (gl > 0.02f) {
                        m.push();
                        m.translate(0.11f, 0.34f, 0.07f);
                        m.sphere(H, 0.05f, 0, al(tip, gl * 0.55f), al(tip, 0f));
                        m.pop();
                    }
                }
                m.pop();
            }
        }
        m.pop();
    }

    // ---------------------------------------------------------------- ears

    /** Rounded ear outline as a convex polygon, base centred on the origin. */
    private static float[] oval(float rx, float ry, int n) {
        float[] out = new float[n * 2];
        for (int i = 0; i < n; i++) {
            float ang = (float) (Math.PI * 2 * i / n);
            out[i * 2] = (float) Math.cos(ang) * rx;
            out[i * 2 + 1] = ry + (float) Math.sin(ang) * ry;
        }
        return out;
    }

    private static void ears(Mesh m, BaroxConfig c, Anim a) {
        String id = "ears";
        int main = col(c, id, "color", a, 0f);
        int inner = col(c, id, "inner", a, 0.4f);
        float size = c.f(id, "size"), tilt = c.f(id, "tilt") * DEG;
        int design = c.idx(id, "design");
        m.push();
        m.translate(0f, 0.5f, 0f);
        m.scale(size);
        for (int side = 0; side < 2; side++) {
            m.push();
            if (side == 1) m.scale(-1f, 1f, 1f);
            m.translate(0.15f, 0f, -0.04f);
            m.rotZ(-tilt);
            if (design == 2) { // bunny: long, leaning back
                m.rotX(10f * DEG);
                float[] outline = oval(0.07f, 0.22f, 14);
                m.prism(S, outline, 14, 0.04f, main, Colors.lighten(main, 0.2f));
                m.push();
                m.translate(0f, 0.035f, -0.022f);
                m.prism(S, oval(0.035f, 0.17f, 12), 12, 0.012f, inner, Colors.lighten(inner, 0.2f));
                m.pop();
            } else {
                float w = design == 1 ? 0.17f : 0.2f, h = design == 1 ? 0.31f : design == 3 ? 0.27f : 0.25f;
                int tipColor = design == 1 ? Colors.shade(main, 0.25f) : main;
                float[] tri = {-w / 2f, 0f, w / 2f, 0f, design == 3 ? 0.01f : 0f, h};
                m.prism(S, tri, 3, 0.04f, main, main);
                if (design == 1) { // fox: dark tip
                    m.push();
                    m.translate(0f, h * 0.7f, 0f);
                    float[] top = {-w * 0.15f, 0f, w * 0.15f, 0f, 0f, h * 0.3f};
                    m.prism(S, top, 3, 0.045f, tipColor, tipColor);
                    m.pop();
                }
                m.push();
                m.translate(0f, 0.015f, -0.022f);
                float[] in = {-w * 0.3f, 0f, w * 0.3f, 0f, 0f, h * 0.68f};
                m.prism(S, in, 3, 0.012f, inner, Colors.lighten(inner, 0.25f));
                m.pop();
            }
            m.pop();
        }
        m.pop();
    }

    // ---------------------------------------------------------------- tail

    private static void tail(Mesh m, BaroxConfig c, Anim a) {
        String id = "tail";
        int base = col(c, id, "color", a, 0f), tip = col(c, id, "tip", a, 0.2f);
        float size = c.f(id, "size"), length = c.f(id, "length"), gl = glow(c, id);
        float ws = c.f(id, "wave_speed") * 3.2f, wa = c.f(id, "wave_amount") / 100f;
        int design = c.idx(id, "design");
        int segs = 11;
        float segLen = 0.10f * length;
        m.push();
        m.translate(0f, -0.72f, 0.12f);
        m.scale(size);
        m.rotX((design == 1 ? 40f : design == 2 ? 55f : design == 3 ? 60f : 50f) * DEG); // starts pointing backwards and down
        for (int i = 0; i < segs; i++) {
            float t = i / (float) (segs - 1);
            float sway = (float) Math.sin(a.time * ws - i * 0.6f) * wa * 0.16f * (0.35f + t);
            float lift = (float) Math.sin(a.time * ws * 0.5f - i * 0.4f) * wa * 0.04f;
            float curl = -(design == 0 ? 0.07f : design == 1 ? 0.035f : design == 2 ? 0.08f : 0.10f);
            m.rotY(sway);
            m.rotX(curl + lift);
            int c0 = Colors.lerp(base, tip, Math.max(0f, (t - 0.55f) / 0.45f)), c1 = Colors.lerp(base, tip, Math.max(0f, (t + 1f / segs - 0.55f) / 0.45f));
            switch (design) {
                case 1: { // dragon: thick, tapering, with spikes
                    float w = lerp(0.14f, 0.025f, t);
                    m.bar(S, 0f, 0f, 0f, 0f, 0f, segLen, w, w * 0.9f, c0, c1);
                    if (i % 2 == 0 && i < segs - 1) {
                        m.push();
                        m.translate(0f, w * 0.45f, segLen * 0.5f);
                        m.rotX(-90f * DEG);
                        m.pyramid(S, w * 0.28f, 0.07f * (1f - t * 0.5f), 4, tip, Colors.lighten(tip, 0.4f));
                        m.pop();
                    }
                    if (i == segs - 1) {
                        m.push();
                        m.translate(0f, 0f, segLen);
                        m.rotX(-90f * DEG);
                        m.bipyramid(S, 0.05f, 0.07f, 0.03f, 4, Colors.lighten(tip, 0.3f), tip, tip);
                        m.pop();
                    }
                    break;
                }
                case 2: { // cyber: metal segments with glowing joints
                    float w = lerp(0.08f, 0.035f, t);
                    int metal = Colors.lerp(0xFF4A5368, base, 0.35f);
                    m.bar(S, 0f, 0f, 0.012f, 0f, 0f, segLen - 0.012f, w, w, metal, Colors.shade(metal, 0.8f));
                    m.push();
                    m.translate(0f, 0f, segLen);
                    m.sphere(G, w * 0.62f, 0, al(Colors.lighten(tip, 0.3f), 0.55f + gl * 0.45f), al(tip, 0.45f + gl * 0.4f));
                    m.pop();
                    if (i == segs - 1) {
                        m.push();
                        m.translate(0f, 0f, segLen + 0.02f);
                        m.rotX(-90f * DEG);
                        m.bipyramid(G, 0.045f, 0.1f, 0.03f, 4, al(Colors.lighten(tip, 0.5f), 0.95f), al(tip, 0.7f), al(tip, 0.85f));
                        m.pop();
                    }
                    break;
                }
                case 3: { // devil: thin tail with an arrow head
                    float w = 0.032f;
                    m.bar(S, 0f, 0f, 0f, 0f, 0f, segLen, w, w, c0, c1);
                    if (i == segs - 1) {
                        m.push();
                        m.translate(0f, 0f, segLen);
                        m.rotX(-90f * DEG);
                        m.scale(1f, 1f, 0.35f);
                        m.bipyramid(S, 0.1f, 0.14f, 0.02f, 4, tip, Colors.shade(tip, 0.6f), Colors.lighten(tip, 0.1f));
                        m.pop();
                    }
                    break;
                }
                default: { // fox: bushy
                    float w = 0.07f + 0.15f * (float) Math.sin(Math.PI * (0.12f + 0.78f * t));
                    m.bar(S, 0f, 0f, 0f, 0f, 0f, segLen, w, w * 0.92f, c0, c1);
                    break;
                }
            }
            m.translate(0f, 0f, segLen);
        }
        m.pop();
    }

    // ---------------------------------------------------------------- visor

    private static void visor(Mesh m, BaroxConfig c, Anim a) {
        String id = "visor";
        int col = col(c, id, "color", a, 0f);
        float gl = glow(c, id), op = c.f(id, "opacity") / 100f;
        int design = c.idx(id, "design");
        float z = -0.262f;
        m.push();
        m.translate(0f, 0.255f, 0f);
        int frame = 0xFF14161E;
        switch (design) {
            case 1: // shades
                for (int side = 0; side < 2; side++) {
                    float x = side == 0 ? -0.115f : 0.115f;
                    m.box(S, x, 0f, z, 0.19f, 0.1f, 0.03f, frame);
                    m.box(G, x, 0f, z - 0.017f, 0.16f, 0.072f, 0.006f, al(col, op * (0.55f + gl * 0.45f)));
                }
                m.box(S, 0f, 0.02f, z, 0.06f, 0.02f, 0.03f, frame);
                m.box(S, -0.255f, 0.01f, -0.1f, 0.012f, 0.03f, 0.3f, frame);
                m.box(S, 0.255f, 0.01f, -0.1f, 0.012f, 0.03f, 0.3f, frame);
                break;
            case 2: // face plate with glowing slits
                m.box(S, 0f, -0.04f, z, 0.54f, 0.26f, 0.03f, Colors.lerp(frame, col, 0.12f));
                m.box(G, -0.115f, 0.015f, z - 0.017f, 0.15f, 0.028f, 0.006f, al(col, op));
                m.box(G, 0.115f, 0.015f, z - 0.017f, 0.15f, 0.028f, 0.006f, al(col, op));
                m.box(G, 0f, -0.1f, z - 0.017f, 0.2f, 0.012f, 0.006f, al(col, op * 0.7f));
                break;
            case 3: // monocle on the left eye
                m.push();
                m.translate(0.115f, 0f, z - 0.012f);
                m.rotX(90f * DEG);
                m.ring(S, 0.085f, 0.105f, 0.02f, 24, frame, frame);
                m.ring(G, 0.082f, 0.096f, 0.012f, 24, al(col, op), al(Colors.lighten(col, 0.4f), op));
                m.fadeRing(G, 0f, 0.082f, 20, al(col, op * 0.35f), al(col, op * 0.18f));
                m.pop();
                m.bar(S, 0.2f, -0.06f, z, 0.26f, -0.3f, z + 0.1f, 0.012f, 0.012f, al(Colors.lighten(col, 0.3f), 1f), al(Colors.lighten(col, 0.3f), 1f));
                break;
            default: { // cyber: wide scanning bar
                m.box(S, 0f, 0f, z, 0.56f, 0.12f, 0.03f, frame);
                m.box(G, 0f, 0f, z - 0.017f, 0.5f, 0.07f, 0.006f, al(col, op * (0.5f + gl * 0.5f)));
                if (c.flag(id, "scan")) {
                    float sx = (float) Math.sin(a.time * 2.4f) * 0.22f;
                    m.box(G, sx, 0f, z - 0.021f, 0.035f, 0.085f, 0.006f, al(Colors.lighten(col, 0.7f), Math.min(1f, op + 0.1f)));
                }
                m.box(S, -0.285f, 0f, -0.12f, 0.02f, 0.1f, 0.28f, frame);
                m.box(S, 0.285f, 0f, -0.12f, 0.02f, 0.1f, 0.28f, frame);
                break;
            }
        }
        if (gl > 0.02f) {
            m.push();
            m.translate(0f, 0f, z - 0.03f);
            m.rotX(90f * DEG);
            m.fadeRing(H, 0.02f, 0.3f * (0.6f + gl * 0.5f), 20, al(col, gl * 0.22f), al(col, 0f));
            m.pop();
        }
        m.pop();
    }

    // ---------------------------------------------------------------- cape

    private static void cape(Mesh m, BaroxConfig c, Anim a) {
        String id = "cape";
        int top = col(c, id, "color", a, 0f), edge = col(c, id, "color2", a, 0.25f);
        float length = c.f(id, "length"), width = c.f(id, "width"), sway = c.f(id, "sway") / 100f;
        float op = c.f(id, "opacity") / 100f, gl = glow(c, id);
        int design = c.idx(id, "design");
        float len = (design == 1 ? 0.62f : design == 2 ? 0.95f : 1.12f) * length;
        float topHalf = 0.235f * width, bottomHalf = (design == 1 ? 0.27f : 0.34f) * width;
        int cols = 7, rows = 9;
        int lyr = design == 2 ? G : S;
        float lift = 0.04f + 0.22f * a.activity;
        float[][][] pts = new float[rows + 1][cols + 1][3];
        for (int j = 0; j <= rows; j++) {
            float v = j / (float) rows;
            float half = lerp(topHalf, bottomHalf, v);
            for (int i = 0; i <= cols; i++) {
                float u = i / (float) cols * 2f - 1f;
                float wave = (float) Math.sin(a.time * 2.3f + v * 3.2f + u * 1.4f) * 0.045f * sway * v;
                float flutter = (float) Math.sin(a.time * 5.1f + v * 5f - u * 2f) * 0.012f * sway * a.activity * v;
                pts[j][i][0] = u * half + (float) Math.sin(a.time * 1.7f + v * 2f) * 0.02f * sway * v;
                pts[j][i][1] = -len * v;
                pts[j][i][2] = 0.145f + lift * v * v * 1.4f + 0.05f * v + wave + flutter;
            }
        }
        for (int j = 0; j < rows; j++) {
            float v0 = j / (float) rows, v1 = (j + 1f) / rows;
            int c0 = Colors.lerp(top, edge, v0 * 0.85f), c1 = Colors.lerp(top, edge, v1 * 0.85f);
            float alpha = design == 2 ? op * 0.55f : op;
            for (int i = 0; i < cols; i++) {
                float stripe = design == 2 ? (((j + (int) (a.time * 3f)) % 3 == 0) ? 1.0f : 0.6f) : 1f;
                int q0 = al(c0, alpha * stripe), q1 = al(c1, alpha * stripe);
                m.sheet(lyr, pts[j][i][0], pts[j][i][1], pts[j][i][2], pts[j][i + 1][0], pts[j][i + 1][1], pts[j][i + 1][2],
                        pts[j + 1][i + 1][0], pts[j + 1][i + 1][1], pts[j + 1][i + 1][2], pts[j + 1][i][0], pts[j + 1][i][1], pts[j + 1][i][2], q0, q0, q1, q1);
            }
        }
        // glowing border
        int bc = al(Colors.lighten(edge, 0.25f), Math.min(1f, 0.35f + gl * 0.65f));
        for (int i = 0; i < cols; i++) {
            m.bar(G, pts[rows][i][0], pts[rows][i][1], pts[rows][i][2] + 0.004f, pts[rows][i + 1][0], pts[rows][i + 1][1], pts[rows][i + 1][2] + 0.004f, 0.014f, 0.01f, bc, bc);
        }
        for (int j = 0; j < rows; j++) {
            m.bar(G, pts[j][0][0], pts[j][0][1], pts[j][0][2] + 0.004f, pts[j + 1][0][0], pts[j + 1][0][1], pts[j + 1][0][2] + 0.004f, 0.012f, 0.01f, bc, bc);
            m.bar(G, pts[j][cols][0], pts[j][cols][1], pts[j][cols][2] + 0.004f, pts[j + 1][cols][0], pts[j + 1][cols][1], pts[j + 1][cols][2] + 0.004f, 0.012f, 0.01f, bc, bc);
        }
        // clasp
        m.box(S, 0f, 0.0f, 0.15f, 0.34f * width, 0.05f, 0.035f, Colors.shade(edge, 0.6f));
        m.box(G, 0f, 0.0f, 0.172f, 0.05f, 0.04f, 0.01f, al(Colors.lighten(edge, 0.5f), 0.55f + gl * 0.45f));
    }

    // ---------------------------------------------------------------- jetpack

    private static void jetpack(Mesh m, BaroxConfig c, Anim a) {
        String id = "jetpack";
        int main = col(c, id, "color", a, 0f), acc = col(c, id, "accent", a, 0.25f);
        float size = c.f(id, "size"), gl = glow(c, id);
        int design = c.idx(id, "design");
        float power = a.airborne ? 1f : 0.3f + 0.25f * a.activity;
        int steel = Colors.lerp(Colors.shade(main, 0.55f), 0xFF9AA3B8, 0.4f);
        m.push();
        m.translate(0f, -0.38f, 0.125f);
        m.scale(size);
        // back plate
        m.box(S, 0f, 0.02f, 0.03f, 0.36f, 0.44f, 0.06f, Colors.shade(steel, 0.7f));
        m.box(G, 0f, 0.10f, 0.064f, 0.12f, 0.02f, 0.01f, al(acc, 0.5f + gl * 0.5f));
        if (design == 2) { // cube pack
            m.box(S, 0f, -0.03f, 0.16f, 0.3f, 0.34f, 0.16f, steel);
            m.box(G, 0f, -0.03f, 0.245f, 0.18f, 0.18f, 0.01f, al(acc, 0.45f + gl * 0.55f));
            m.box(G, 0f, -0.03f, 0.252f, 0.07f, 0.07f, 0.01f, al(Colors.lighten(acc, 0.6f), 1f));
            for (int side = 0; side < 2; side++) {
                float x = side == 0 ? -0.1f : 0.1f;
                nozzle(m, x, -0.2f, 0.16f, 0.05f, steel, acc, gl, power, a, side);
            }
        } else if (design == 1) { // single big tank
            tank(m, 0f, -0.32f, 0.2f, 0.1f, 0.52f, steel, acc, gl);
            nozzle(m, 0f, -0.32f, 0.2f, 0.075f, steel, acc, gl, power * 1.2f, a, 0);
        } else { // twin
            for (int side = 0; side < 2; side++) {
                float x = side == 0 ? -0.1f : 0.1f;
                tank(m, x, -0.28f, 0.2f, 0.07f, 0.46f, steel, acc, gl);
                nozzle(m, x, -0.28f, 0.2f, 0.06f, steel, acc, gl, power, a, side);
            }
        }
        m.pop();
    }

    private static void tank(Mesh m, float x, float y, float z, float r, float h, int steel, int acc, float gl) {
        m.push();
        m.translate(x, y, z);
        m.cylinder(S, r, r, h, 12, Colors.shade(steel, 0.85f), steel);
        m.push();
        m.translate(0f, h, 0f);
        m.cylinder(S, r, r * 0.45f, r * 0.7f, 12, steel, Colors.lighten(steel, 0.2f));
        m.pop();
        for (int k = 0; k < 2; k++) {
            m.push();
            m.translate(0f, h * (0.3f + 0.35f * k), 0f);
            m.ring(G, r + 0.001f, r + 0.014f, 0.022f, 14, al(acc, 0.55f + gl * 0.45f), al(Colors.lighten(acc, 0.4f), 0.55f + gl * 0.45f));
            m.pop();
        }
        m.pop();
    }

    private static void nozzle(Mesh m, float x, float yTank, float z, float r, int steel, int acc, float gl, float power, Anim a, int seed) {
        m.push();
        m.translate(x, yTank, z);
        m.push();
        m.translate(0f, -0.06f, 0f);
        m.cylinder(S, r * 0.8f, r * 1.0f, 0.06f, 10, Colors.shade(steel, 0.55f), Colors.shade(steel, 0.75f));
        m.pop();
        float flick = 0.88f + 0.12f * (float) Math.sin(a.time * 38f + seed * 2.1f);
        float len = (0.1f + 0.34f * power) * flick;
        m.push();
        m.translate(0f, -0.06f, 0f);
        m.scale(1f, -1f, 1f);
        m.pyramid(G, r * 0.72f, len, 8, al(Colors.lighten(acc, 0.65f), 0.95f), al(acc, 0f));
        if (gl > 0.02f) m.pyramid(H, r * 1.5f, len * 1.35f, 8, al(acc, 0.35f * gl + 0.1f), al(acc, 0f));
        m.pop();
        m.pop();
    }
}
