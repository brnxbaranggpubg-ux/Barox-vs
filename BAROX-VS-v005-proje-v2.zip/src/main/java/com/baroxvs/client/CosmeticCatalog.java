package com.baroxvs.client;

/**
 * Intentionally empty. The old v002/v003 cosmetic list lived in this file; it was replaced by {@link ModuleCatalog}
 * in v004. The (empty) file is kept so that copying this project over an older checkout can never leave a stale
 * copy of the old class behind, which would no longer compile.
 */
final class CosmeticCatalog {
    private CosmeticCatalog() {}
}
