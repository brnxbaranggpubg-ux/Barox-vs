package com.baroxvs.client;

/**
 * A plain mannequin (feet at y = 0, front towards -Z) that the menu draws behind a cosmetic in the 3D preview,
 * so you can judge size and position of wings, crowns and tails against a body. Pure Java.
 */
final class PreviewFigure {
    private PreviewFigure() {}

    static void build(Mesh m) {
        int legs = 0xFF343B4D, torso = 0xFF3E475C, arms = 0xFF4A546C, head = 0xFF59647F, face = 0xFFD9E4F2;
        m.box(Mesh.SOLID, -0.125f, 0.375f, 0f, 0.25f, 0.75f, 0.25f, legs);
        m.box(Mesh.SOLID, 0.125f, 0.375f, 0f, 0.25f, 0.75f, 0.25f, legs);
        m.box(Mesh.SOLID, 0f, 1.125f, 0f, 0.5f, 0.75f, 0.25f, torso);
        m.box(Mesh.SOLID, -0.375f, 1.125f, 0f, 0.25f, 0.75f, 0.25f, arms);
        m.box(Mesh.SOLID, 0.375f, 1.125f, 0f, 0.25f, 0.75f, 0.25f, arms);
        m.box(Mesh.SOLID, 0f, 1.75f, 0f, 0.5f, 0.5f, 0.5f, head);
        // two small eyes on the front so the viewing direction is obvious
        m.box(Mesh.SOLID, -0.12f, 1.78f, -0.255f, 0.1f, 0.05f, 0.01f, face);
        m.box(Mesh.SOLID, 0.12f, 1.78f, -0.255f, 0.1f, 0.05f, 0.01f, face);
    }
}
