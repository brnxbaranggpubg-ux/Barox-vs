package com.baroxvs.client;

/**
 * The ten 3D wing designs. Pure geometry: every design is built in the wing's own frame
 * (+X outwards from the shoulder, +Y up, thickness along Z) and mounted on the back by {@link #build}.
 * Left and right wings come from the same code, mirrored.
 */
final class WingModels {
    private WingModels() {}

    /** All wing options, already read from the config. Colours are opaque 0xFFRRGGBB. */
    static final class P {
        int design;
        int c1 = 0xFFB44CFF, c2 = 0xFF6A1FD0, accent = 0xFFE0B0FF;
        float size = 1f, spread = 0.55f, flapSpeed = 1f, flapAmount = 0.45f, thick = 1f, opacity = 0.9f, glow = 0.7f;
        int n = 6;
        float height, back;
        /** Seconds, drives the animation. */
        float time;
        /** 0 = hanging still, 1 = flying or sprinting. */
        float activity = 1f;
    }

    private static final int S = Mesh.SOLID, G = Mesh.GLOW;
    private static final float DEG = (float) Math.PI / 180f;

    // ---------------------------------------------------------------- mounting + animation

    static void build(Mesh m, P p) {
        boolean fairy = p.design == 7;
        float omega = p.flapSpeed * (2.2f + 3.0f * p.activity) * (fairy ? 2.6f : 1f);
        float amp = p.flapAmount * 0.95f * (0.2f + 0.8f * p.activity);
        float flap = (float) Math.sin(p.time * omega) * amp * (fairy ? 0.7f : 1f);
        float idle = (float) Math.sin(p.time * 1.3f) * 0.025f; // slow breathing even when still
        float yaw = (5f + 55f * p.spread) * DEG;
        float tilt = 14f * DEG;

        // small mounting plate on the back
        m.box(S, 0, p.height - 0.13f, 0.135f + p.back, 0.15f, 0.17f, 0.035f * p.thick + 0.01f, Colors.withAlpha(Colors.shade(p.c1, 0.4f), 255));
        m.box(G, 0, p.height - 0.13f, 0.158f + p.back, 0.045f, 0.10f, 0.006f, Colors.withAlpha(p.accent, Math.round(255 * Math.min(1f, p.glow + 0.15f))));

        for (int side = 0; side < 2; side++) {
            m.push();
            if (side == 1) m.scale(-1f, 1f, 1f);
            m.translate(0.075f, p.height - 0.12f, 0.15f + p.back);
            m.rotY(-yaw);
            m.rotZ(tilt + flap + idle);
            m.scale(p.size);
            switch (p.design) {
                case 1 -> angel(m, p);
                case 2 -> membrane(m, p, 4, 1.0f, false);
                case 3 -> butterfly(m, p);
                case 4 -> membrane(m, p, 3, 0.78f, true);
                case 5 -> crystal(m, p);
                case 6 -> mech(m, p);
                case 7 -> fairy(m, p);
                case 8 -> phoenix(m, p);
                case 9 -> pixel(m, p);
                default -> cyber(m, p);
            }
            m.pop();
        }
    }

    // ---------------------------------------------------------------- helpers

    private static int a(int rgb, float alpha) { return Colors.withAlpha(rgb, Math.round(255f * Math.max(0f, Math.min(1f, alpha)))); }

    private static float lerp(float x, float y, float t) { return x + (y - x) * t; }

    /** Smooth leaf outline along +X: rounded near the base, pointed at the tip. Returns x/y pairs, counter clockwise. */
    private static float[] leaf(float len, float width, int perSide) {
        int n = perSide * 2 + 2;
        float[] out = new float[n * 2];
        int k = 0;
        out[k++] = 0;
        out[k++] = 0;
        for (int i = 1; i <= perSide; i++) { // lower edge, base to tip
            float s = i / (float) (perSide + 1);
            out[k++] = len * s;
            out[k++] = -profile(s) * width / 2f;
        }
        out[k++] = len;
        out[k++] = 0;
        for (int i = perSide; i >= 1; i--) { // upper edge, tip back to base
            float s = i / (float) (perSide + 1);
            out[k++] = len * s;
            out[k++] = profile(s) * width / 2f;
        }
        return out;
    }

    private static float profile(float s) {
        // peaks around 35% of the length, 1.0 at its maximum
        return (float) (Math.pow(s, 0.55) * Math.pow(1 - s, 0.75) / 0.5);
    }

    /** One feather radiating from (x, y) at an angle; thickness along Z, gradient base to tip. */
    private static void feather(Mesh m, float x, float y, float z, float ang, float len, float width, float curl,
                                float thick, int base, int tip, float glow, int accent) {
        m.push();
        m.translate(x, y, z);
        m.rotZ(ang);
        m.rotY(-curl);
        float[] poly = leaf(len, width, 5);
        m.prism(S, poly, poly.length / 2, thick, base, tip);
        if (glow > 0.02f) { // soft vein along the feather
            m.bar(G, len * 0.1f, 0, thick / 2 + 0.002f, len * 0.9f, 0, thick / 2 + 0.002f, 0.006f, 0.003f, a(accent, 0.0f), a(accent, glow * 0.7f));
        }
        m.pop();
    }

    private static float[] along(float x, float y, float ang, float d) {
        return new float[]{x + (float) Math.cos(ang) * d, y + (float) Math.sin(ang) * d};
    }

    // ---------------------------------------------------------------- 0: Cyber

    private static void cyber(Mesh m, P p) {
        float t = 0.016f * p.thick;
        int base = a(p.c1, p.opacity), tip = a(p.c2, p.opacity);
        int dark = a(Colors.shade(p.c1, 0.35f), 1f);
        float[] elbow = {0.22f, 0.27f}, wrist = {0.47f, 0.52f};

        // spar with a glowing core and two joints
        m.bar(S, 0, 0, 0, elbow[0], elbow[1], 0, 0.05f * p.thick + 0.012f, 0.04f * p.thick + 0.012f, dark, dark);
        m.bar(S, elbow[0], elbow[1], 0, wrist[0], wrist[1], 0, 0.045f * p.thick + 0.01f, 0.036f * p.thick + 0.01f, dark, dark);
        m.bar(G, 0, 0, 0.026f, elbow[0], elbow[1], 0.026f, 0.010f, 0.006f, a(p.accent, 0.5f * p.glow + 0.2f), a(p.accent, p.glow));
        m.bar(G, elbow[0], elbow[1], 0.026f, wrist[0], wrist[1], 0.026f, 0.010f, 0.006f, a(p.accent, p.glow), a(p.accent, p.glow));
        m.box(S, elbow[0], elbow[1], 0, 0.06f, 0.06f, 0.05f, dark);
        m.box(G, elbow[0], elbow[1], 0.03f, 0.03f, 0.03f, 0.012f, a(p.accent, p.glow));
        m.box(S, wrist[0], wrist[1], 0, 0.065f, 0.065f, 0.055f, dark);
        m.box(G, wrist[0], wrist[1], 0.032f, 0.035f, 0.035f, 0.012f, a(p.accent, p.glow));

        int n = Math.max(2, p.n);
        float[] prevTip = null, prevAttach = null;
        for (int i = 0; i < n; i++) {
            float u = i / (float) (n - 1);
            float st = 0.10f + 0.90f * u;
            float ax, ay;
            if (st < 0.5f) { ax = lerp(0, elbow[0], st / 0.5f); ay = lerp(0, elbow[1], st / 0.5f); }
            else { ax = lerp(elbow[0], wrist[0], (st - 0.5f) / 0.5f); ay = lerp(elbow[1], wrist[1], (st - 0.5f) / 0.5f); }
            float ang = lerp(-72f, 8f, u) * DEG;
            float len = 0.40f + 0.64f * (float) Math.pow(u, 0.85);
            float w = 0.145f - 0.035f * u;
            float z = 0.006f * i;

            m.push();
            m.translate(ax, ay, z);
            m.rotZ(ang);
            m.rotY(-0.10f * u);
            float hw = w / 2f;
            float[] poly = {
                0, -hw * 0.55f, 0.14f * len, -hw, 0.55f * len, -hw * 0.72f, 0.93f * len, -hw * 0.30f, len, 0,
                0.88f * len, hw * 0.45f, 0.50f * len, hw * 0.80f, 0.14f * len, hw, 0, hw * 0.55f
            };
            m.prism(S, poly, 9, t, base, tip);
            // neon edges and tip bead
            float zz = t / 2f + 0.002f;
            int edge = a(p.accent, p.glow);
            int edge0 = a(p.accent, p.glow * 0.4f);
            for (int e = 0; e < 4; e++) { // lower edge segments then the upper ones
                m.bar(G, poly[(e + 1) * 2], poly[(e + 1) * 2 + 1], zz, poly[(e + 2) * 2], poly[(e + 2) * 2 + 1], zz, 0.013f, 0.005f, e == 0 ? edge0 : edge, edge);
            }
            for (int e = 5; e < 8; e++) {
                m.bar(G, poly[e * 2], poly[e * 2 + 1], zz, poly[(e + 1) * 2], poly[(e + 1) * 2 + 1], zz, 0.013f, 0.005f, edge, e == 7 ? edge0 : edge);
            }
            m.box(G, len, 0, 0, 0.03f, 0.03f, 0.02f, a(Colors.lighten(p.accent, 0.5f), Math.min(1f, p.glow + 0.2f)));
            // data ticks along the blade
            for (int k = 1; k <= 3; k++) {
                m.box(G, len * (0.25f + 0.2f * k), 0, zz, 0.018f, hw * 0.55f, 0.004f, a(p.accent, p.glow * 0.7f));
            }
            m.pop();

            // energy sail between this blade and the previous one
            float[] tipPos = along(ax, ay, ang, len);
            if (prevTip != null && p.glow > 0.02f) {
                m.sheet(G, prevAttach[0], prevAttach[1], 0.002f, prevTip[0], prevTip[1], 0.002f, tipPos[0], tipPos[1], 0.002f, ax, ay, 0.002f,
                        a(p.c1, 0.06f * p.glow + 0.02f), a(p.c2, 0.22f * p.glow), a(p.c2, 0.22f * p.glow), a(p.c1, 0.06f * p.glow + 0.02f));
            }
            prevTip = tipPos;
            prevAttach = new float[]{ax, ay};
        }
    }

    // ---------------------------------------------------------------- 1: Angel

    private static void angel(Mesh m, P p) {
        float th = 0.010f * p.thick;
        int base = a(p.c1, p.opacity), tip = a(p.c2, p.opacity);
        float[] elbow = {0.22f, 0.26f}, wrist = {0.50f, 0.46f};
        int bone = a(Colors.lighten(p.c1, 0.35f), 1f);
        m.bar(S, 0, 0, 0, elbow[0], elbow[1], 0, 0.034f * p.thick + 0.008f, bone);
        m.bar(S, elbow[0], elbow[1], 0, wrist[0], wrist[1], 0, 0.030f * p.thick + 0.008f, bone);
        m.sphere(S, 0.03f, 0, bone, Colors.shade(bone, 0.7f));
        int n = Math.max(3, p.n);

        // secondaries hang from the forearm
        for (int i = 0; i < n; i++) {
            float u = i / (float) (n - 1);
            float px = lerp(0.04f, wrist[0] - 0.04f, u), py = lerp(0.03f, wrist[1] - 0.04f, u);
            feather(m, px, py, 0.004f + 0.001f * i, lerp(-1.42f, -1.05f, u), lerp(0.58f, 0.70f, u), 0.17f, 0.10f, th, base, tip, p.glow, p.accent);
        }
        // primaries fan out from the wrist
        for (int i = 0; i < n; i++) {
            float u = i / (float) (n - 1);
            feather(m, wrist[0], wrist[1], 0.016f + 0.001f * i, lerp(0.12f, -0.98f, u), lerp(1.0f, 0.66f, (float) Math.pow(u, 1.3)), 0.18f - 0.02f * u, 0.14f, th, base, tip, p.glow, p.accent);
        }
        // coverts: a short top row
        for (int i = 0; i < n + 1; i++) {
            float u = i / (float) n;
            float px = lerp(0.06f, wrist[0] + 0.02f, u), py = lerp(0.05f, wrist[1] + 0.01f, u);
            feather(m, px, py, 0.030f + 0.001f * i, lerp(-1.1f, -0.55f, u), 0.30f, 0.12f, 0.12f, th, Colors.lighten(base, 0.2f), Colors.lighten(tip, 0.25f), p.glow * 0.5f, p.accent);
        }
    }

    // ---------------------------------------------------------------- 2 + 4: Dragon and Bat (bone + membrane)

    private static void membrane(Mesh m, P p, int fingers, float scale, boolean bat) {
        float th = 0.012f * p.thick;
        int skin = a(Colors.shade(p.c1, bat ? 0.45f : 0.6f), p.opacity);
        int skinEdge = a(p.c1, p.opacity);
        int boneC = a(p.c2, 1f);
        float[] elbow = {0.20f * scale, 0.28f * scale}, wrist = {0.52f * scale, 0.66f * scale};
        float[] rootB = {0.02f, -0.26f * scale};

        m.bar(S, 0, 0, 0, elbow[0], elbow[1], 0, 0.045f * p.thick + 0.012f, boneC, Colors.shade(boneC, 0.85f));
        m.bar(S, elbow[0], elbow[1], 0, wrist[0], wrist[1], 0, 0.038f * p.thick + 0.010f, Colors.shade(boneC, 0.85f), boneC);
        m.sphere(S, 0.04f * (bat ? 0.8f : 1f), 0, boneC, Colors.shade(boneC, 0.6f));

        float[][] tips = new float[fingers + 1][];
        float first = bat ? 28f : 18f, last = bat ? -78f : -74f;
        for (int i = 0; i < fingers; i++) {
            float u = fingers == 1 ? 0 : i / (float) (fingers - 1);
            float ang = lerp(first, last, u) * DEG;
            float len = (bat ? 0.82f : 1.0f) * lerp(1.0f, 0.62f, (float) Math.pow(u, 1.1f)) * (i == 0 ? 1.0f : 1.0f);
            tips[i] = along(wrist[0], wrist[1], ang, len);
            m.bar(S, wrist[0], wrist[1], 0.004f, tips[i][0], tips[i][1], 0.004f, 0.026f * p.thick + 0.007f, 0.022f * p.thick + 0.006f, boneC, Colors.shade(boneC, 0.7f));
            // glowing claw at the tip
            m.push();
            m.translate(tips[i][0], tips[i][1], 0.004f);
            m.rotZ(ang - (float) Math.PI / 2f);
            m.pyramid(G, 0.022f, 0.07f, 4, a(p.accent, p.glow), a(Colors.lighten(p.accent, 0.5f), p.glow));
            m.pop();
        }
        tips[fingers] = rootB;

        // scalloped skin between the finger bones, fanning out from the wrist
        for (int i = 0; i < fingers; i++) {
            float[] t0 = tips[i], t1 = tips[i + 1];
            float mx = (t0[0] + t1[0]) / 2f, my = (t0[1] + t1[1]) / 2f;
            mx = lerp(mx, wrist[0], 0.16f);
            my = lerp(my, wrist[1], 0.16f);
            int c0 = Colors.lerp(skin, skinEdge, 0.0f), c1 = Colors.lerp(skin, skinEdge, 0.9f);
            m.sheetTri(S, wrist[0], wrist[1], 0, t0[0], t0[1], 0, mx, my, 0, c0, c1, c1);
            m.sheetTri(S, wrist[0], wrist[1], 0, mx, my, 0, t1[0], t1[1], 0, c0, c1, c1);
            // edge glow along the scallop
            if (p.glow > 0.02f) {
                m.bar(G, t0[0], t0[1], 0.003f, mx, my, 0.003f, 0.007f, 0.004f, a(p.accent, p.glow * 0.8f), a(p.accent, p.glow * 0.3f));
                m.bar(G, mx, my, 0.003f, t1[0], t1[1], 0.003f, 0.007f, 0.004f, a(p.accent, p.glow * 0.3f), a(p.accent, p.glow * 0.8f));
            }
        }
        // skin between the last finger / body and the arm
        m.sheetTri(S, wrist[0], wrist[1], 0, rootB[0], rootB[1], 0, elbow[0], elbow[1], 0, skin, skinEdge, skin);
        m.sheetTri(S, elbow[0], elbow[1], 0, rootB[0], rootB[1], 0, 0, 0, 0, skin, skinEdge, skin);
        // thin the volume a little so the bones read as raised
        if (th > 0) m.bar(S, 0, 0, 0, elbow[0], elbow[1], 0.0f, 0.01f, th, skinEdge, skinEdge);
    }

    // ---------------------------------------------------------------- 3: Butterfly

    private static void blob(Mesh m, float cx, float cy, float rx, float ry, float rot, float z, int center, int rim, int seg) {
        blob(m, S, cx, cy, rx, ry, rot, z, center, rim, seg);
    }

    private static void blob(Mesh m, int layer, float cx, float cy, float rx, float ry, float rot, float z, int center, int rim, int seg) {
        float cr = (float) Math.cos(rot), sr = (float) Math.sin(rot);
        for (int i = 0; i < seg; i++) {
            float a0 = (float) (Math.PI * 2 * i / seg), a1 = (float) (Math.PI * 2 * (i + 1) / seg);
            float[] p0 = blobPoint(cx, cy, rx, ry, cr, sr, a0), p1 = blobPoint(cx, cy, rx, ry, cr, sr, a1);
            m.sheetTri(layer, cx, cy, z, p0[0], p0[1], z, p1[0], p1[1], z, center, rim, rim);
        }
    }

    private static float[] blobPoint(float cx, float cy, float rx, float ry, float cr, float sr, float ang) {
        float wobble = 1f + 0.06f * (float) Math.sin(ang * 3f);
        float lx = (float) Math.cos(ang) * rx * wobble, ly = (float) Math.sin(ang) * ry * wobble;
        return new float[]{cx + lx * cr - ly * sr, cy + lx * sr + ly * cr};
    }

    private static void butterfly(Mesh m, P p) {
        int rim = a(Colors.shade(p.c2, 0.85f), 1f);
        int mid = a(Colors.lighten(p.c2, 0.12f), p.opacity * 0.9f);
        int inner = a(Colors.lighten(p.c1, 0.35f), p.opacity * 0.95f);
        // upper and lower wing, built from nested blobs so the pattern has rings; the inner rings glow
        blob(m, S, 0.46f, 0.38f, 0.52f, 0.43f, 24f * DEG, 0.000f, rim, rim, 28);
        blob(m, G, 0.46f, 0.38f, 0.45f, 0.36f, 24f * DEG, 0.004f, mid, mid, 28);
        blob(m, G, 0.44f, 0.37f, 0.33f, 0.26f, 24f * DEG, 0.008f, inner, mid, 28);
        blob(m, S, 0.34f, -0.22f, 0.34f, 0.30f, -28f * DEG, 0.000f, rim, rim, 24);
        blob(m, G, 0.34f, -0.22f, 0.28f, 0.24f, -28f * DEG, 0.004f, mid, mid, 24);
        blob(m, G, 0.33f, -0.22f, 0.18f, 0.15f, -28f * DEG, 0.008f, inner, mid, 24);
        // eye spots and body-side veins that glow
        if (p.glow > 0.02f) {
            int g = a(p.accent, p.glow);
            blob(m, 0.62f, 0.50f, 0.075f, 0.075f, 0, 0.012f, g, a(p.accent, p.glow * 0.3f), 12);
            blob(m, 0.42f, -0.24f, 0.055f, 0.055f, 0, 0.012f, g, a(p.accent, p.glow * 0.3f), 12);
            for (int i = 0; i < 4; i++) {
                float ang = lerp(75f, 5f, i / 3f) * DEG;
                float[] e = along(0.03f, 0.03f, ang, 0.62f + 0.05f * i);
                m.bar(G, 0.03f, 0.03f, 0.011f, e[0], e[1], 0.011f, 0.008f, 0.004f, a(p.accent, p.glow * 0.2f), a(p.accent, p.glow * 0.9f));
            }
            float[] low = along(0.03f, 0.0f, -35f * DEG, 0.52f);
            m.bar(G, 0.03f, 0.0f, 0.011f, low[0], low[1], 0.011f, 0.008f, 0.004f, a(p.accent, p.glow * 0.2f), a(p.accent, p.glow * 0.9f));
        }
        // thorax joint
        m.sphere(S, 0.035f, 0, a(Colors.shade(p.c2, 0.4f), 1f), a(Colors.shade(p.c2, 0.25f), 1f));
    }

    // ---------------------------------------------------------------- 5: Crystal

    private static void crystal(Mesh m, P p) {
        int n = Math.max(3, p.n);
        int core = a(Colors.lighten(p.c1, 0.6f), 1f);
        m.bipyramid(S, 0.055f, 0.09f, 0.09f, 5, a(Colors.lighten(p.c1, 0.4f), 1f), a(Colors.shade(p.c1, 0.5f), 1f), a(p.c1, 1f));
        for (int i = 0; i < n; i++) {
            float u = i / (float) (n - 1);
            float ang = lerp(78f, -44f, u) * DEG;
            float len = lerp(1.25f, 0.55f, (float) Math.pow(u, 0.9));
            float w = lerp(0.22f, 0.13f, u) * (0.75f + 0.25f * p.thick);
            m.push();
            m.translate(0.02f * i, 0.03f, 0.012f * (i % 3));
            m.rotZ(ang - (float) Math.PI / 2f);
            m.rotY(0.25f * (i % 2 == 0 ? 1 : -1));
            // body of the shard
            m.push();
            m.translate(0, len * 0.22f, 0);
            m.bipyramid(S, w / 2f, len * 0.78f, len * 0.22f, 5, a(Colors.lighten(p.c2, 0.25f), p.opacity), a(p.c1, p.opacity), a(Colors.lighten(Colors.lerp(p.c1, p.c2, 0.35f), 0.15f), p.opacity));
            if (p.glow > 0.02f) {
                m.bipyramid(G, w / 5f, len * 0.5f, len * 0.12f, 4, a(p.accent, p.glow * 0.9f), a(p.accent, p.glow * 0.3f), a(core, p.glow * 0.55f));
            }
            m.pop();
            // small companion shard beside the big one
            m.push();
            m.translate(0.05f, 0, 0.02f);
            m.rotZ(-0.35f);
            m.translate(0, len * 0.1f, 0);
            m.bipyramid(S, w * 0.28f, len * 0.42f, len * 0.1f, 4, a(Colors.lighten(p.c2, 0.4f), p.opacity), a(p.c1, p.opacity), a(Colors.lighten(p.c1, 0.2f), p.opacity));
            m.pop();
            m.pop();
        }
    }

    // ---------------------------------------------------------------- 6: Mech

    private static void mech(Mesh m, P p) {
        float t = 0.034f * p.thick + 0.006f;
        int steel = a(Colors.lerp(Colors.shade(p.c1, 0.55f), 0xFFC4CCDC, 0.45f), p.opacity);
        int steel2 = a(Colors.lerp(Colors.shade(p.c2, 0.55f), 0xFFC4CCDC, 0.40f), p.opacity);
        int n = Math.max(2, Math.min(6, p.n - 2));
        for (int i = 0; i < n; i++) {
            float u = n == 1 ? 0 : i / (float) (n - 1);
            float y0 = lerp(0.30f, -0.20f, u);
            float len = lerp(1.18f, 0.72f, u);
            float drop = lerp(0.30f, 0.22f, u);
            float[] poly = {
                0.02f, y0 - 0.02f,
                0.20f * len, y0 - drop * 0.30f,
                len, y0 - drop * 0.55f,
                len + 0.08f, y0 - drop * 0.15f,
                len * 0.82f, y0 + 0.07f,
                0.10f, y0 + 0.10f
            };
            m.push();
            m.translate(0, 0, 0.014f * i);
            m.prism(S, poly, 6, t, steel, steel2);
            // neon trim on the top edge and a thruster at the tip
            float zz = t / 2f + 0.003f;
            m.bar(G, poly[10], poly[11], zz, poly[8], poly[9], zz, 0.018f, 0.006f, a(p.accent, p.glow * 0.5f), a(p.accent, p.glow));
            m.bar(G, poly[8], poly[9], zz, poly[6], poly[7], zz, 0.018f, 0.006f, a(p.accent, p.glow), a(p.accent, p.glow));
            m.bar(G, poly[0], poly[1], zz, poly[2], poly[3], zz, 0.008f, 0.004f, a(p.accent, p.glow * 0.3f), a(p.accent, p.glow * 0.6f));
            m.box(S, len + 0.045f, y0 - drop * 0.2f, 0, 0.07f, 0.055f, t + 0.02f, a(Colors.shade(p.c1, 0.2f), 1f));
            m.box(G, len + 0.085f, y0 - drop * 0.2f, 0, 0.03f, 0.04f, t * 0.8f, a(Colors.lighten(p.accent, 0.4f), Math.min(1f, p.glow + 0.15f)));
            // rivets
            for (int r = 0; r < 3; r++) m.box(G, 0.22f + r * 0.2f * len, y0, zz, 0.012f, 0.012f, 0.004f, a(p.accent, p.glow * 0.8f));
            m.pop();
        }
        m.box(S, 0.04f, 0.05f, 0, 0.12f, 0.46f, t + 0.02f, a(Colors.shade(p.c1, 0.22f), 1f));
    }

    // ---------------------------------------------------------------- 7: Fairy

    private static void wingMembrane(Mesh m, P p, float len, float width, float ang, float z, float alpha) {
        m.push();
        m.translate(0.03f, 0.03f, z);
        m.rotZ(ang);
        float[] poly = leaf(len, width, 7);
        int n = poly.length / 2;
        int c0 = a(p.c1, alpha * p.opacity), c1 = a(p.c2, alpha * p.opacity * 0.8f);
        m.prism(S, poly, n, 0.003f, c0, c1);
        // outline and veins glow
        if (p.glow > 0.02f) {
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                m.bar(G, poly[i * 2], poly[i * 2 + 1], 0.003f, poly[j * 2], poly[j * 2 + 1], 0.003f, 0.006f, 0.003f, a(p.accent, p.glow * 0.8f), a(p.accent, p.glow * 0.8f));
            }
            for (int v = -1; v <= 1; v++) {
                m.bar(G, 0.02f, 0, 0.003f, len * 0.86f, v * width * 0.22f, 0.003f, 0.004f, 0.003f, a(p.accent, p.glow * 0.5f), a(p.accent, p.glow * 0.1f));
            }
        }
        m.pop();
    }

    private static void fairy(Mesh m, P p) {
        float shimmer = 0.75f + 0.25f * (float) Math.sin(p.time * 7f);
        wingMembrane(m, p, 0.95f, 0.46f, 52f * DEG, 0.000f, 0.55f * shimmer);
        wingMembrane(m, p, 0.62f, 0.32f, -34f * DEG, 0.006f, 0.50f * shimmer);
        wingMembrane(m, p, 0.55f, 0.26f, 12f * DEG, 0.010f, 0.28f * shimmer);
    }

    // ---------------------------------------------------------------- 8: Phoenix

    private static void flameFeather(Mesh m, float x, float y, float z, float ang, float len, float width, float bend, P p, float heat) {
        int cBase = a(p.c1, p.opacity), cMid = a(Colors.lerp(p.c1, p.c2, 0.5f), p.opacity), cTip = a(p.c2, p.opacity * 0.55f);
        m.push();
        m.translate(x, y, z);
        m.rotZ(ang);
        float seg = len * 0.55f;
        float[] a1 = leaf(seg, width, 4);
        m.prism(S, a1, a1.length / 2, 0.008f * p.thick, cBase, cMid);
        m.push();
        m.translate(seg * 0.92f, 0, 0.004f);
        m.rotZ(bend);
        float[] a2 = leaf(len - seg * 0.92f, width * 0.8f, 4);
        m.prism(S, a2, a2.length / 2, 0.008f * p.thick, cMid, cTip);
        if (p.glow > 0.02f) {
            m.bar(G, 0, 0, 0.006f, (len - seg) * 0.95f, 0, 0.006f, 0.012f, 0.004f, a(Colors.lighten(p.accent, 0.3f), p.glow * heat), a(p.accent, 0.0f));
        }
        m.pop();
        if (p.glow > 0.02f) {
            m.bar(G, seg * 0.08f, 0, 0.006f, seg * 0.95f, 0, 0.006f, 0.014f, 0.004f, a(p.accent, p.glow * 0.3f), a(Colors.lighten(p.accent, 0.3f), p.glow * heat));
        }
        m.pop();
    }

    private static void phoenix(Mesh m, P p) {
        int n = Math.max(3, p.n);
        float sway = (float) Math.sin(p.time * 3.2f) * 0.10f;
        for (int i = 0; i < n; i++) {
            float u = i / (float) (n - 1);
            float ang = lerp(64f, -58f, u) * DEG;
            float len = lerp(0.85f, 1.42f, (float) Math.sin(u * Math.PI * 0.85)) ;
            float bend = (-0.30f - 0.25f * u) + sway * (0.5f + u);
            flameFeather(m, 0.04f + 0.02f * i, 0.04f, 0.006f * i, ang, len, 0.15f, bend, p, 1.0f);
        }
        // shorter flame tongues in between
        for (int i = 0; i < n - 1; i++) {
            float u = (i + 0.5f) / (n - 1);
            float ang = lerp(64f, -58f, u) * DEG;
            flameFeather(m, 0.05f + 0.02f * i, 0.04f, -0.01f - 0.004f * i, ang, 0.72f, 0.12f, -0.2f + sway, p, 0.7f);
        }
    }

    // ---------------------------------------------------------------- 9: Pixel

    private static final String[] PIXEL = {
        "..........XX",
        ".......XXXXX",
        "....XXXXXXXX",
        "..XXXXXXXXX.",
        ".XXXXXXXXXXX",
        "XXXXXXXXXXX.",
        "XXXXXXXXX.XX",
        ".XXXXXX.X.X.",
        "..XXX...X...",
        "...X.....X.."
    };

    private static float hash(int x, int y, int z) {
        int h = x * 374761393 + y * 668265263 + z * 1274126177;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= h >>> 16;
        return (h & 0xFFFF) / 65535f;
    }

    private static void pixel(Mesh m, P p) {
        float cell = 0.085f;
        float depth = 0.05f * p.thick + 0.012f;
        int glitchTick = (int) (p.time * 7f);
        int rows = PIXEL.length;
        for (int r = 0; r < rows; r++) {
            String row = PIXEL[r];
            for (int c = 0; c < row.length(); c++) {
                if (row.charAt(c) != 'X') continue;
                boolean edge = c == 0 || r == 0 || r == rows - 1 || c == row.length() - 1
                        || row.charAt(c - 1) != 'X' || (c + 1 < row.length() && row.charAt(c + 1) != 'X')
                        || (r > 0 && c < PIXEL[r - 1].length() && PIXEL[r - 1].charAt(c) != 'X')
                        || (r + 1 < rows && c < PIXEL[r + 1].length() && PIXEL[r + 1].charAt(c) != 'X');
                float u = c / (float) (row.length() - 1);
                float variation = 0.82f + 0.30f * hash(c, r, 1);
                int col = Colors.shade(a(Colors.lerp(p.c1, p.c2, u), p.opacity), variation);
                float x = 0.03f + c * cell, y = 0.30f - r * cell;
                // occasional glitch: a cell jumps backwards for a moment
                float gl = hash(c, r, glitchTick);
                float dz = gl > 0.965f ? 0.06f : 0f;
                float dx = gl > 0.985f ? 0.04f : 0f;
                m.box(S, x + dx, y, dz, cell * 0.94f, cell * 0.94f, depth, col);
                if (edge && p.glow > 0.02f) {
                    m.box(G, x + dx, y, dz + depth / 2f + 0.002f, cell * 0.62f, cell * 0.62f, 0.004f, a(p.accent, p.glow * (0.5f + 0.4f * hash(c, r, 2))));
                }
            }
        }
    }
}
