package com.baroxvs.client;

/** Built-in colour themes plus the editable Custom theme. The selected theme tints the ClickGUI, the HUD and every "Theme" colour. */
public final class Themes {
    private Themes() {}

    public static final int DEFAULT_INDEX = 2; // Violet Void

    public static final Theme[] ALL = {
        new Theme("Cyber Blue", 0xFF4FC3F7, 0xFF1976D2),
        new Theme("Olive", 0xFFC9BC4B, 0xFF8F842F),
        new Theme("Violet Void", 0xFFB44CFF, 0xFF6A1FD0),
        new Theme("Sunset", 0xFFFF8A3D, 0xFFE8541E),
        new Theme("Neon Green", 0xFF5BFF6B, 0xFF1DB954),
        new Theme("Abyss Blue", 0xFF3D7BFF, 0xFF1B3FBF),
        new Theme("Sakura", 0xFFFF9EC4, 0xFFE0658F),
        new Theme("Cyber Dragon", 0xFFFF9A3C, 0xFFFF3D5A),
        new Theme("Aurora", 0xFF5CD6FF, 0xFFB066FF),
        new Theme("Matrix", 0xFF2BFF66, 0xFF0B9E34),
        new Theme("Hellfire", 0xFFFF5A36, 0xFFD11A1A),
        new Theme("Mint Pulse", 0xFF4DF0B0, 0xFF1FBF8A),
    };

    /** Index of the editable theme, right after the built-in ones. */
    public static final int CUSTOM_INDEX = ALL.length;

    public static int count() { return ALL.length + 1; }

    public static String name(int index) { return index >= CUSTOM_INDEX ? "Custom" : ALL[Math.max(0, index)].name(); }

    /** The theme a theme row shows as swatch (the Custom one reads the colours chosen in its settings). */
    public static Theme at(BaroxConfig config, int index) {
        if (index >= CUSTOM_INDEX) return custom(config);
        return ALL[Math.max(0, Math.min(ALL.length - 1, index))];
    }

    public static Theme current(BaroxConfig config) {
        return at(config, Math.max(0, Math.min(CUSTOM_INDEX, config.theme)));
    }

    private static Theme custom(BaroxConfig config) {
        return new Theme("Custom", 0xFF000000 | rawColor(config, "primary"), 0xFF000000 | rawColor(config, "secondary"));
    }

    /** Colours of the Custom theme can not follow the theme itself, so "Theme" falls back to the default pair. */
    private static int rawColor(BaroxConfig config, String id) {
        Setting s = ModuleCatalog.byId("theme_custom").setting(id);
        double v = config.num("theme_custom", id);
        if (v == Setting.COLOR_RAINBOW) {
            float hue = (System.currentTimeMillis() % 8000L) / 8000f;
            return Colors.rainbow(hue + ("secondary".equals(id) ? 0.12f : 0f)) & 0xFFFFFF;
        }
        if (v == Setting.COLOR_THEME) return (int) s.def & 0xFFFFFF;
        return (int) v & 0xFFFFFF;
    }
}
