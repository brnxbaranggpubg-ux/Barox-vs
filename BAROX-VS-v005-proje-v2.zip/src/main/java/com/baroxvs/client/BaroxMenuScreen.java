package com.baroxvs.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * BAROX VS ClickGUI: six glass columns (Cosmetics, Effects, Trails, HUD, Misc, Themes) with a search bar
 * underneath. Left click toggles a module, the small sliders icon or a right click opens the settings window of
 * the module (colors, sizes, designs, live 3D preview). Dragging or the mouse wheel scrolls a column.
 * Every switch is a local cosmetic, HUD or interface option.
 */
public final class BaroxMenuScreen extends Screen {
    private static final String[] TITLES = {
        ModuleCatalog.COSMETICS, ModuleCatalog.EFFECTS, ModuleCatalog.TRAILS,
        ModuleCatalog.HUD, ModuleCatalog.MISC, ModuleCatalog.THEMES
    };
    private static final int COLUMNS = 6;
    private static final int THEMES_COLUMN = 5;
    private static final int ROW_H = 19;
    private static final int HEADER_H = 24;
    private static final int GAP = 6;
    private static final int MIN_COL = 96;
    private static final int MAX_COL = 132;

    private final BaroxConfig cfg;
    /** Rebuilt on every frame while drawing; package private so the tests and the settings window can use it. */
    final List<GuiHit> hits = new ArrayList<>();
    /** Scroll offsets and limits: 0..5 columns, 6 option list of the settings window, 7 preview (never scrolls). */
    final float[] scroll = new float[8];
    final float[] maxScroll = new float[8];
    private final int[] colX = new int[COLUMNS];
    private final long openedAt = System.currentTimeMillis();
    private String query = "";
    float s = 1f;
    float vw, vh;
    private int colY, colW, colH;

    private SettingsWindow window;
    private boolean dirty;

    private GuiHit pressed;
    private GuiHit dragHit;
    private int pressRegion = -1;
    private double pressX, pressY;
    private boolean dragged;

    public BaroxMenuScreen(BaroxConfig cfg) {
        super(Text.literal("BAROX VS"));
        this.cfg = cfg;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // ------------------------------------------------------------------ shared with the settings window

    GuiHit hit(int x1, int y1, int x2, int y2, int region) {
        GuiHit hit = new GuiHit(x1, y1, x2, y2, region);
        hits.add(hit);
        return hit;
    }

    void markDirty() {
        dirty = true;
    }

    private void saveIfDirty() {
        if (dirty) {
            dirty = false;
            cfg.save();
        }
    }

    static int iconFor(String category) {
        return switch (category) {
            case ModuleCatalog.COSMETICS -> 0;
            case ModuleCatalog.TRAILS -> 1;
            case ModuleCatalog.EFFECTS -> 2;
            case ModuleCatalog.HUD -> 3;
            case ModuleCatalog.MISC -> 4;
            default -> 5;
        };
    }

    void openWindow(ModuleCatalog.Module module) {
        if (module == null || !module.hasSettings()) return;
        window = new SettingsWindow(this, cfg, module);
        scroll[SettingsWindow.LIST_REGION] = 0f;
        maxScroll[SettingsWindow.LIST_REGION] = 0f;
    }

    void closeWindow() {
        if (window != null) window.blur();
        window = null;
        saveIfDirty();
    }

    // ------------------------------------------------------------------ layout

    private void layout() {
        int minTotal = COLUMNS * MIN_COL + (COLUMNS - 1) * GAP + 16;
        s = Math.max(0.5f, Math.min(1f, width / (float) minTotal));
        vw = width / s;
        vh = height / s;
        colW = (int) Math.min(MAX_COL, (vw - 16 - (COLUMNS - 1) * GAP) / (float) COLUMNS);
        int total = COLUMNS * colW + (COLUMNS - 1) * GAP;
        int x0 = (int) ((vw - total) / 2f);
        for (int i = 0; i < COLUMNS; i++) colX[i] = x0 + i * (colW + GAP);
        colY = 22;
        colH = (int) Math.max(120, Math.min(330, vh - colY - 52));
    }

    private List<ModuleCatalog.Module> visibleModules(int column) {
        List<ModuleCatalog.Module> out = new ArrayList<>();
        if (column == THEMES_COLUMN) return out;
        String q = query.trim().toLowerCase(Locale.ROOT);
        for (ModuleCatalog.Module m : ModuleCatalog.inCategory(TITLES[column])) {
            if (q.isEmpty() || m.name().toLowerCase(Locale.ROOT).contains(q)
                    || m.id().toLowerCase(Locale.ROOT).contains(q)
                    || m.description().toLowerCase(Locale.ROOT).contains(q)) out.add(m);
        }
        return out;
    }

    private List<Integer> visibleThemes() {
        List<Integer> out = new ArrayList<>();
        String q = query.trim().toLowerCase(Locale.ROOT);
        for (int i = 0; i < Themes.count(); i++) {
            if (q.isEmpty() || Themes.name(i).toLowerCase(Locale.ROOT).contains(q)) out.add(i);
        }
        return out;
    }

    private int panelBackground() {
        return Ui.alpha(0x0A0C14, Math.round(2.45f * cfg.f("gui_style", "opacity")));
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        hits.clear();
        layout();
        Theme th = Themes.current(cfg);
        float mx = mouseX / s;
        float my = mouseY / s;

        MatrixStack m = ctx.getMatrices();
        m.push();
        m.scale(s, s, 1f);

        drawBackdrop(ctx, th);
        Ui.text(ctx, textRenderer, "BAROX", 8, 7, Ui.WHITE, 1f, true);
        Ui.text(ctx, textRenderer, "VS", 8 + textRenderer.getWidth("BAROX "), 7, th.primary(), 1f, true);
        Ui.text(ctx, textRenderer, "visuals only", 8 + textRenderer.getWidth("BAROX VS "), 8, Ui.DIM, 0.8f, false);
        Ui.textRight(ctx, textRenderer, Themes.name(cfg.theme), (int) vw - 8, 8, Ui.alpha(th.primary(), 0xC0), 0.8f, false);

        boolean live = window == null;
        for (int i = 0; i < COLUMNS; i++) drawColumn(ctx, i, th, mx, my, live);
        drawSearch(ctx, th);

        if (window != null) {
            ctx.fill(0, 0, (int) vw + 1, (int) vh + 1, 0x99000000);
            window.render(ctx, textRenderer, th, mx, my);
        }
        drawTooltip(ctx, mx, my);

        m.pop();
    }

    private void drawBackdrop(DrawContext ctx, Theme th) {
        int w = (int) vw + 1, h = (int) vh + 1;
        ctx.fillGradient(0, 0, w, h, Ui.alpha(th.secondary(), 0x38), Ui.alpha(th.primary(), 0x0C));
        if (!cfg.flag("gui_style", "grid")) return;
        int line = Ui.alpha(th.primary(), 0x0E);
        for (int x = 0; x < w; x += 18) ctx.fill(x, 0, x + 1, h, line);
        for (int y = 0; y < h; y += 18) ctx.fill(0, y, w, y + 1, line);
        if (cfg.flag("gui_style", "animations")) {
            int sy = (int) ((System.currentTimeMillis() / 25L) % (h + 20));
            int top = Math.max(0, sy - 14), bottom = Math.min(h, sy);
            if (bottom > top) ctx.fillGradient(0, top, w, bottom, Ui.alpha(th.primary(), 0x00), Ui.alpha(th.primary(), 0x16));
            if (sy < h) ctx.fill(0, sy, w, sy + 1, Ui.alpha(th.primary(), 0x30));
        }
    }

    /** Columns slide in one after the other when the menu opens. */
    private int slideOffset(int col) {
        if (!cfg.flag("gui_style", "animations")) return 0;
        float t = Math.max(0f, Math.min(1f, (System.currentTimeMillis() - openedAt - col * 35L) / 260f));
        float e = 1f - (1f - t) * (1f - t) * (1f - t);
        return Math.round((1f - e) * -14f);
    }

    private void drawColumn(DrawContext ctx, int col, Theme th, float mx, float my, boolean live) {
        int x = colX[col];
        int y = colY + slideOffset(col);
        Ui.panel(ctx, x, y, x + colW, y + colH, th.primary(), panelBackground(), 5, 0x70);
        ctx.fill(x + 8, y, x + colW - 8, y + 1, th.primary());

        // header
        Ui.icon(ctx, iconFor(TITLES[col]), x + 8, y + 8, th.primary());
        Ui.text(ctx, textRenderer, TITLES[col], x + 20, y + 8, Ui.WHITE, 1f, true);
        String count;
        if (col == THEMES_COLUMN) {
            count = Integer.toString(Themes.count());
        } else {
            int on = 0, total = 0;
            for (ModuleCatalog.Module mod : ModuleCatalog.inCategory(TITLES[col])) {
                if (mod.kind() != ModuleCatalog.Kind.TOGGLE) continue;
                total++;
                if (cfg.isOn(mod.id())) on++;
            }
            count = total == 0 ? "" : on + "/" + total;
        }
        Ui.textRight(ctx, textRenderer, count, x + colW - 8, y + 9, Ui.alpha(th.primary(), 0xE0), 0.8f, false);
        ctx.fill(x + 6, y + HEADER_H - 1, x + colW - 6, y + HEADER_H, 0x22FFFFFF);

        int listTop = y + HEADER_H + 2;
        int listBottom = y + colH - 4;
        List<ModuleCatalog.Module> modules = visibleModules(col);
        List<Integer> themes = col == THEMES_COLUMN ? visibleThemes() : null;
        int n = themes != null ? themes.size() : modules.size();

        float content = n * ROW_H;
        float viewport = listBottom - listTop;
        maxScroll[col] = Math.max(0f, content - viewport);
        scroll[col] = Math.max(0f, Math.min(maxScroll[col], scroll[col]));

        for (int r = 0; r < n; r++) {
            int ry = Math.round(listTop + r * ROW_H - scroll[col]);
            if (ry < listTop || ry + ROW_H > listBottom) continue;
            if (themes != null) drawThemeRow(ctx, col, themes.get(r), x, ry, th, mx, my, live);
            else drawModuleRow(ctx, col, modules.get(r), x, ry, th, mx, my, live);
        }
        if (n == 0) Ui.textCentered(ctx, textRenderer, "-", x + colW / 2, listTop + 6, Ui.DIM, 1f, false);

        if (maxScroll[col] > 0f) {
            float thumbH = Math.max(10f, viewport * viewport / content);
            float thumbY = listTop + (viewport - thumbH) * (scroll[col] / maxScroll[col]);
            ctx.fill(x + colW - 4, Math.round(thumbY), x + colW - 3, Math.round(thumbY + thumbH), Ui.alpha(th.primary(), 0xB0));
        }
    }

    private void drawModuleRow(DrawContext ctx, int col, ModuleCatalog.Module mod, int x, int ry, Theme th, float mx, float my, boolean live) {
        int left = x + 4, right = x + colW - 5;
        boolean toggle = mod.kind() == ModuleCatalog.Kind.TOGGLE;
        boolean on = toggle && cfg.isOn(mod.id());
        boolean hover = live && mx >= left && mx < right && my >= ry && my < ry + ROW_H - 1;

        if (on) Ui.roundRect(ctx, left, ry, right, ry + ROW_H - 2, 3, Ui.alpha(th.primary(), 0x26));
        else if (hover) Ui.roundRect(ctx, left, ry, right, ry + ROW_H - 2, 3, 0x14FFFFFF);
        if (on) ctx.fill(left, ry + 3, left + 2, ry + ROW_H - 5, th.primary());

        boolean settings = mod.hasSettings();
        Setting color = toggle ? mod.mainColor() : null;
        int reserved = (settings ? 14 : 0) + (color != null ? 9 : 0);
        int nameMax = right - 4 - reserved - (x + 11);
        String name = Ui.fit(textRenderer, mod.name(), nameMax, 1f);
        Ui.text(ctx, textRenderer, name, x + 11, ry + 5, on || !toggle ? Ui.WHITE : 0xFF9AA0AD, 1f, false);
        if (color != null) {
            int rgb = cfg.rgb(mod.id(), color.id, System.currentTimeMillis() / 1000.0, 0);
            Ui.circle(ctx, right - 4 - (settings ? 14 : 0) - 3, ry + 8, 3, 0xFF000000 | rgb);
        }
        if (settings) Ui.slidersIcon(ctx, right - 11, ry + 6, hover ? Ui.WHITE : on ? th.primary() : Ui.DIM);

        if (!live) return;
        String tip = mod.description() + (settings && toggle ? "   [Right click: settings]" : "");
        GuiHit row = hit(left, ry, right, ry + ROW_H - 1, col).tip(tip);
        if (toggle) row.click(() -> BaroxVsClient.toggleModule(mod.id()));
        else row.click(() -> openWindow(mod));
        if (settings) {
            row.alt(() -> openWindow(mod));
            hit(right - 16, ry, right, ry + ROW_H - 1, col).click(() -> openWindow(mod)).alt(() -> openWindow(mod)).tip("Settings: " + mod.name());
        }
    }

    private void drawThemeRow(DrawContext ctx, int col, int index, int x, int ry, Theme current, float mx, float my, boolean live) {
        Theme t = Themes.at(cfg, index);
        boolean custom = index == Themes.CUSTOM_INDEX;
        int left = x + 4, right = x + colW - 5;
        boolean selected = cfg.theme == index;
        boolean hover = live && mx >= left && mx < right && my >= ry && my < ry + ROW_H - 1;

        if (selected) {
            Ui.roundRect(ctx, left, ry, right, ry + ROW_H - 2, 3, current.primary());
            Ui.roundRect(ctx, left + 1, ry + 1, right - 1, ry + ROW_H - 3, 2, 0xFF12101F);
        } else if (hover) {
            Ui.roundRect(ctx, left, ry, right, ry + ROW_H - 2, 3, 0x14FFFFFF);
        }
        Ui.gradientCircle(ctx, x + 14, ry + 8, 4, t.primary(), t.secondary());
        String name = Ui.fit(textRenderer, Themes.name(index), colW - 24 - (custom ? 18 : 8), 1f);
        Ui.text(ctx, textRenderer, name, x + 24, ry + 5, selected ? Ui.WHITE : 0xFFB4AEC2, 1f, false);
        if (custom) Ui.slidersIcon(ctx, right - 11, ry + 6, hover ? Ui.WHITE : selected ? current.primary() : Ui.DIM);

        if (!live) return;
        GuiHit row = hit(left, ry, right, ry + ROW_H - 1, col).tip("Theme: " + Themes.name(index) + (custom ? "   [Right click: edit colors]" : ""));
        row.click(() -> {
            cfg.theme = index;
            cfg.save();
        });
        if (custom) {
            ModuleCatalog.Module editor = ModuleCatalog.byId("theme_custom");
            row.alt(() -> openWindow(editor));
            hit(right - 16, ry, right, ry + ROW_H - 1, col).click(() -> {
                cfg.theme = index;
                cfg.save();
                openWindow(editor);
            }).alt(() -> openWindow(editor)).tip("Edit the Custom theme colors");
        }
    }

    private void drawSearch(DrawContext ctx, Theme th) {
        int w = 150;
        int x = (int) (vw / 2f - w / 2f);
        int y = colY + colH + 8;
        Ui.panel(ctx, x, y, x + w, y + 16, th.primary(), 0xE00A0C14, 5, 0x60);
        boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
        if (query.isEmpty()) {
            Ui.textCentered(ctx, textRenderer, "Ara...", x + w / 2, y + 4, Ui.DIM, 1f, false);
        } else {
            String shown = Ui.fit(textRenderer, query, w - 18, 1f);
            Ui.text(ctx, textRenderer, shown + (blink ? "_" : ""), x + 8, y + 4, Ui.WHITE, 1f, false);
        }
        Ui.textCentered(ctx, textRenderer, "Sol tık: aç/kapat  •  Sağ tık / ayar ikonu: ayarlar  •  Sürükle: kaydır",
                (int) (vw / 2f), y + 21, Ui.DIM, 0.75f, false);
    }

    private void drawTooltip(DrawContext ctx, float mx, float my) {
        GuiHit hit = hitAt(mx, my);
        if (hit == null || hit.tip == null) return;
        String tip = Ui.fit(textRenderer, hit.tip, 240, 1f);
        int w = textRenderer.getWidth(tip) + 10;
        int x = (int) Math.max(2, Math.min(mx + 8, vw - w - 4));
        int y = (int) Math.max(2, Math.min(my + 10, vh - 16));
        Ui.roundRect(ctx, x, y, x + w, y + 14, 4, 0xF0090711);
        Ui.text(ctx, textRenderer, tip, x + 5, y + 3, Ui.WHITE, 1f, false);
    }

    GuiHit hitAt(double vx, double vy) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            if (hits.get(i).contains(vx, vy)) return hits.get(i);
        }
        return null;
    }

    private int columnAt(double vx, double vy) {
        for (int i = 0; i < COLUMNS; i++) {
            if (vx >= colX[i] && vx < colX[i] + colW && vy >= colY && vy < colY + colH) return i;
        }
        return -1;
    }

    private int regionAt(double vx, double vy) {
        if (window != null) return window.overList(vx, vy) ? SettingsWindow.LIST_REGION : -1;
        return columnAt(vx, vy);
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        double vx = mouseX / s, vy = mouseY / s;
        if (window != null) {
            if (!window.contains(vx, vy)) { // a click on the dimmed area closes the window
                closeWindow();
                return true;
            }
            window.blur(); // a text field is focused again by its own click
        }
        GuiHit hit = hitAt(vx, vy);
        if (button == 1) {
            if (hit != null && hit.alt != null) hit.alt.run();
            return true;
        }
        if (button == 0) {
            pressed = hit;
            pressX = mouseX;
            pressY = mouseY;
            dragged = false;
            pressRegion = hit != null ? hit.region : regionAt(vx, vy);
            dragHit = hit != null && hit.drag != null ? hit : null;
            if (dragHit != null) dragHit.drag.at(vx, vy);
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (button != 0) return false;
        double vx = mouseX / s, vy = mouseY / s;
        if (dragHit != null) {
            dragHit.drag.at(vx, vy);
            return true;
        }
        if (!dragged && Math.abs(mouseX - pressX) + Math.abs(mouseY - pressY) > 4) dragged = true;
        if (dragged && pressRegion >= 0 && pressRegion < 7) {
            scroll[pressRegion] = Math.max(0f, Math.min(maxScroll[pressRegion], scroll[pressRegion] - (float) (deltaY / s)));
        }
        return true;
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) {
            GuiHit hit = pressed;
            boolean wasDrag = dragHit != null;
            pressed = null;
            dragHit = null;
            if (window != null) window.endDrag();
            if (!wasDrag && hit != null && !dragged && hit.contains(mouseX / s, mouseY / s) && hit.click != null) {
                hit.click.run();
            }
            dragged = false;
            saveIfDirty();
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        double vx = mouseX / s, vy = mouseY / s;
        if (window != null) {
            window.scrolled(vx, vy, verticalAmount);
            return true;
        }
        int col = columnAt(vx, vy);
        if (col >= 0) {
            scroll[col] = Math.max(0f, Math.min(maxScroll[col], scroll[col] - (float) verticalAmount * 20f));
        }
        return true;
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (window != null) {
            window.typed(chr);
            return true;
        }
        if (chr >= 32 && chr != 127 && query.length() < 24) {
            query += chr;
            for (int i = 0; i < COLUMNS; i++) scroll[i] = 0f;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (window != null && window.key(keyCode)) return true;
        if (keyCode == GLFW.GLFW_KEY_ESCAPE && window != null) {
            closeWindow();
            return true;
        }
        if (window == null && keyCode == GLFW.GLFW_KEY_BACKSPACE) {
            if (!query.isEmpty()) {
                query = query.substring(0, query.length() - 1);
                for (int i = 0; i < COLUMNS; i++) scroll[i] = 0f;
            }
            return true;
        }
        if (BaroxVsClient.openMenuKey() != null && BaroxVsClient.openMenuKey().matchesKey(keyCode, scanCode)) {
            if (window != null) closeWindow();
            // With text in the search bar the key is most likely a Shift press for a capital letter.
            else if (query.isEmpty()) close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        cfg.save();
        super.close();
    }
}
