package com.baroxvs.client;

import java.util.Random;

/**
 * The "Aura Sky": a see-through dome of our own geometry around the camera (aurora curtains, gradient, nebula, neon grid,
 * portal rings and stars). It is drawn on top of the vanilla sky; no skybox, texture or vanilla particle is involved.
 *
 * <p>Pure Java: it only writes camera relative quads into a {@link Mesh}.
 */
final class FxSky {
    private FxSky() {}

    static final int AURORA = 0, GRADIENT = 1, NEBULA = 2, GRID = 3, RINGS = 4;

    private static final int MAX_STARS = 400;
    private static final float[] STAR_AZ = new float[MAX_STARS], STAR_EL = new float[MAX_STARS], STAR_K = new float[MAX_STARS];
    private static final float[] BLOB_AZ = new float[24], BLOB_EL = new float[24], BLOB_R = new float[24];

    static {
        Random r = new Random(20241105L);
        for (int i = 0; i < MAX_STARS; i++) {
            STAR_AZ[i] = r.nextFloat() * (float) (Math.PI * 2);
            STAR_EL[i] = (float) Math.asin(0.04 + 0.96 * r.nextDouble()); // uniform over the upper hemisphere
            STAR_K[i] = r.nextFloat();
        }
        for (int i = 0; i < BLOB_AZ.length; i++) {
            BLOB_AZ[i] = r.nextFloat() * (float) (Math.PI * 2);
            BLOB_EL[i] = (float) Math.toRadians(6 + r.nextDouble() * 66);
            BLOB_R[i] = (float) Math.toRadians(10 + r.nextDouble() * 18);
        }
    }

    /** 0 in daylight, 1 at night, with a soft dusk and dawn (time of day in ticks, 0..24000). */
    static float night(float timeOfDay) {
        float t = ((timeOfDay % 24000f) + 24000f) % 24000f;
        if (t < 12000f) return 0f;
        if (t < 14000f) return smooth((t - 12000f) / 2000f);
        if (t < 22000f) return 1f;
        return 1f - smooth((t - 22000f) / 2000f);
    }

    private static float smooth(float t) {
        t = Math.max(0f, Math.min(1f, t));
        return t * t * (3f - 2f * t);
    }

    private static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }

    // ---------------------------------------------------------------- geometry on the dome

    private static float px, py, pz;

    /** Point of the dome in direction (azimuth, elevation), radius r and lifted by lift (result in px, py, pz). */
    private static void dome(float az, float el, float r, float lift) {
        float c = (float) Math.cos(el);
        px = (float) Math.cos(az) * c * r;
        py = (float) Math.sin(el) * r + lift;
        pz = (float) Math.sin(az) * c * r;
    }

    /** One quad of the dome between two azimuths and two elevations with per-corner colours. */
    private static void patch(Mesh m, int layer, float r, float lift, float az0, float az1, float el0, float el1,
                              int c00, int c10, int c11, int c01) {
        dome(az0, el0, r, lift);
        float x0 = px, y0 = py, z0 = pz;
        dome(az1, el0, r, lift);
        float x1 = px, y1 = py, z1 = pz;
        dome(az1, el1, r, lift);
        float x2 = px, y2 = py, z2 = pz;
        dome(az0, el1, r, lift);
        m.quad(layer, x0, y0, z0, x1, y1, z1, x2, y2, z2, px, py, pz, c00, c10, c11, c01);
    }

    /** Soft glowing disc lying on the dome around direction (az, el) with the given angular radius. */
    private static void blob(Mesh m, float r, float lift, float az, float el, float angRadius, int center, int rim) {
        dome(az, el, r, lift);
        float cx = px, cy = py - lift, cz = pz;
        float len = (float) Math.sqrt(cx * cx + cy * cy + cz * cz);
        float dx = cx / len, dy = cy / len, dz = cz / len;
        // tangent basis
        float ux = 0f, uy = 1f, uz = 0f;
        if (Math.abs(dy) > 0.95f) {
            ux = 1f;
            uy = 0f;
        }
        float t1x = uy * dz - uz * dy, t1y = uz * dx - ux * dz, t1z = ux * dy - uy * dx;
        float tl = (float) Math.sqrt(t1x * t1x + t1y * t1y + t1z * t1z);
        t1x /= tl;
        t1y /= tl;
        t1z /= tl;
        float t2x = dy * t1z - dz * t1y, t2y = dz * t1x - dx * t1z, t2z = dx * t1y - dy * t1x;
        float rad = r * (float) Math.tan(angRadius);
        int seg = 10;
        for (int i = 0; i < seg; i++) {
            double a0 = i * 2 * Math.PI / seg, a1 = (i + 1) * 2 * Math.PI / seg;
            float c0 = (float) Math.cos(a0) * rad, s0 = (float) Math.sin(a0) * rad, c1 = (float) Math.cos(a1) * rad, s1 = (float) Math.sin(a1) * rad;
            m.tri(Mesh.HALO, cx, cy + lift, cz,
                cx + t1x * c0 + t2x * s0, cy + lift + t1y * c0 + t2y * s0, cz + t1z * c0 + t2z * s0,
                cx + t1x * c1 + t2x * s1, cy + lift + t1y * c1 + t2y * s1, cz + t1z * c1 + t2z * s1, center, rim, rim);
        }
    }

    // ---------------------------------------------------------------- the sky

    static void build(Mesh m, BaroxConfig cfg, FxEngine.Body b, float time, float globalOpacity) {
        final String M = "sky_aura";
        float night = night(b.timeOfDay);
        int when = cfg.idx(M, "when");
        float factor = b.preview ? 1f : when == 1 ? night : when == 2 ? 1f - night : 1f;
        float op = cfg.f(M, "opacity") / 100f * factor * globalOpacity;
        if (op < 0.01f) return;
        float r = b.radius, lift = b.skyLift;
        float speed = cfg.f(M, "speed");
        float glow = cfg.f(M, "glow") / 100f;
        int style = cfg.idx(M, "style");
        int c0 = cfg.rgb(M, "color", time, 0.0), c1 = cfg.rgb(M, "color2", time, 0.15), c2 = cfg.rgb(M, "color3", time, 0.3);

        // base tint (every style): vertical gradient from the horizon colour to the zenith colour
        float tint = style == GRADIENT ? 1f : style == AURORA ? 0.28f : style == NEBULA ? 0.34f : 0.16f;
        gradient(m, r, lift, op * tint, c0, c1, c2);
        if (cfg.flag(M, "horizon")) horizon(m, r, lift, op, c1, c2, glow, time);
        switch (style) {
            case AURORA -> aurora(m, r, lift, op * glow * 1.5f, time * speed, c0, c1, c2, cfg.f(M, "height"), (int) cfg.f(M, "ribbons"));
            case NEBULA -> nebula(m, r, lift, op, time * speed, c0, c1, c2);
            case GRID -> grid(m, r, lift, op * glow * 1.4f, time * speed, c0, c1);
            case RINGS -> rings(m, r, lift, op * glow * 1.4f, time * speed, c0, c1, c2);
            default -> { }
        }
        if (cfg.flag(M, "stars")) stars(m, r, lift, op, time, (int) cfg.f(M, "star_count"), FxShapes.light(c2, 0.55f));
    }

    private static void gradient(Mesh m, float r, float lift, float op, int c0, int c1, int c2) {
        int rings = 12, seg = 40;
        for (int j = 0; j < rings; j++) {
            float e0 = elev(j / (float) rings), e1 = elev((j + 1) / (float) rings);
            int a = colorAt(e0, op, c0, c1, c2), b = colorAt(e1, op, c0, c1, c2);
            for (int s = 0; s < seg; s++) {
                float az0 = s * (float) (Math.PI * 2) / seg, az1 = (s + 1) * (float) (Math.PI * 2) / seg;
                patch(m, Mesh.GLOW, r, lift, az0, az1, e0, e1, a, a, b, b);
            }
        }
    }

    /** Elevation of ring boundary u (0..1): from just below the horizon to the zenith, denser near the horizon. */
    private static float elev(float u) {
        return (float) Math.toRadians(-10.0 + 100.0 * Math.pow(u, 1.25));
    }

    private static int colorAt(float el, float op, int c0, int c1, int c2) {
        float deg = (float) Math.toDegrees(el);
        float low = smooth((deg + 10f) / 10f);            // fades out below the horizon
        float up = smooth(deg / 75f);
        int rgb = FxShapes.mix(c1, c2, smooth(deg / 22f) * (1f - up));
        rgb = FxShapes.mix(rgb, c0, up);
        float a = op * low * (0.95f - 0.35f * up);
        return FxShapes.argb(rgb, a);
    }

    private static void horizon(Mesh m, float r, float lift, float op, int c1, int c2, float glow, float time) {
        int seg = 48;
        float pulse = 0.85f + 0.15f * (float) Math.sin(time * 0.7);
        for (int s = 0; s < seg; s++) {
            float az0 = s * (float) (Math.PI * 2) / seg, az1 = (s + 1) * (float) (Math.PI * 2) / seg;
            int hot = FxShapes.argb(FxShapes.mix(c1, c2, 0.5f), op * 0.55f * glow * pulse), none = FxShapes.argb(c1, 0f);
            patch(m, Mesh.HALO, r, lift, az0, az1, (float) Math.toRadians(-3), (float) Math.toRadians(1.5), none, none, hot, hot);
            patch(m, Mesh.HALO, r, lift, az0, az1, (float) Math.toRadians(1.5), (float) Math.toRadians(18), hot, hot, none, none);
        }
    }

    // ---- aurora curtains

    private static void aurora(Mesh m, float r, float lift, float op, float t, int c0, int c1, int c2, float heightDeg, int ribbons) {
        int seg = 96;
        for (int k = 0; k < ribbons; k++) {
            float base = (float) Math.toRadians(16 + k * 9.0);
            for (int s = 0; s < seg; s++) {
                float az0 = k * 1.7f + t * 0.02f + s * (float) (Math.PI * 2) / seg, az1 = k * 1.7f + t * 0.02f + (s + 1) * (float) (Math.PI * 2) / seg;
                float[] bottom = new float[2], top = new float[2], alpha = new float[2], mix = new float[2];
                for (int e = 0; e < 2; e++) {
                    float az = e == 0 ? az0 : az1;
                    float wave = (float) (Math.sin(az * 3 + t * 0.35 + k) * 5.0 + Math.sin(az * 7 - t * 0.5) * 2.0);
                    bottom[e] = base + (float) Math.toRadians(wave);
                    float h = (float) Math.toRadians(heightDeg * (0.6 + 0.4 * Math.sin(az * 2 + k + t * 0.2)));
                    top[e] = bottom[e] + h;
                    float ray = (float) Math.pow(0.5 + 0.5 * Math.sin(az * 11 + t * 0.8 + k * 2.1), 1.5) * (0.6f + 0.4f * (float) Math.sin(az * 3 - k));
                    alpha[e] = op * (0.3f + 0.7f * ray);
                    mix[e] = 0.5f + 0.5f * (float) Math.sin(az * 2 + k);
                }
                int b0 = FxShapes.argb(FxShapes.mix(c0, c1, mix[0]), alpha[0]), b1 = FxShapes.argb(FxShapes.mix(c0, c1, mix[1]), alpha[1]);
                int t0 = FxShapes.argb(c2, alpha[0] * 0.04f), t1 = FxShapes.argb(c2, alpha[1] * 0.04f);
                dome(az0, bottom[0], r, lift);
                float x0 = px, y0 = py, z0 = pz;
                dome(az1, bottom[1], r, lift);
                float x1 = px, y1 = py, z1 = pz;
                dome(az1, top[1], r, lift);
                float x2 = px, y2 = py, z2 = pz;
                dome(az0, top[0], r, lift);
                m.quad(Mesh.HALO, x0, y0, z0, x1, y1, z1, x2, y2, z2, px, py, pz, b0, b1, t1, t0);
            }
        }
    }

    // ---- nebula

    private static void nebula(Mesh m, float r, float lift, float op, float t, int c0, int c1, int c2) {
        for (int i = 0; i < BLOB_AZ.length; i++) {
            int rgb = i % 3 == 0 ? c0 : i % 3 == 1 ? c1 : c2;
            float az = BLOB_AZ[i] + t * 0.01f;
            float pulse = 0.75f + 0.25f * (float) Math.sin(t * 0.3 + i);
            blob(m, r, lift, az, BLOB_EL[i], BLOB_R[i], FxShapes.argb(rgb, op * 0.2f * pulse), FxShapes.argb(rgb, 0f));
        }
        // a band of dust: small blobs along a great circle
        for (int i = 0; i < 28; i++) {
            float az = i * (float) (Math.PI * 2) / 28 + t * 0.012f;
            float el = (float) Math.toRadians(30 + 18 * Math.sin(az * 1.0 + 0.7));
            blob(m, r, lift, az, el, (float) Math.toRadians(7), FxShapes.argb(FxShapes.light(c1, 0.3f), op * 0.12f), FxShapes.argb(c1, 0f));
        }
    }

    // ---- neon grid

    private static void grid(Mesh m, float r, float lift, float op, float t, int c0, int c1) {
        int seg = 96;
        float half = (float) Math.toRadians(0.32);
        // latitude rings
        for (int ring = 1; ring <= 8; ring++) {
            float el = (float) Math.toRadians(ring * 10.0);
            float pulse = 0.25f + 0.75f * (float) Math.pow(Math.max(0.0, Math.sin(ring * 0.9 - t * 1.4)), 2);
            int c = FxShapes.argb(FxShapes.mix(c0, c1, ring / 9f), op * (0.35f + 0.65f * pulse));
            for (int s = 0; s < seg; s++) {
                float az0 = s * (float) (Math.PI * 2) / seg, az1 = (s + 1) * (float) (Math.PI * 2) / seg;
                patch(m, Mesh.HALO, r, lift, az0, az1, el - half, el + half, c, c, c, c);
            }
        }
        // meridians
        float haz = (float) Math.toRadians(0.4);
        for (int line = 0; line < 24; line++) {
            float az = line * (float) (Math.PI * 2) / 24 + t * 0.01f;
            for (int j = 0; j < 12; j++) {
                float e0 = (float) Math.toRadians(j * 7.4), e1 = (float) Math.toRadians((j + 1) * 7.4);
                float a0 = op * (0.8f - 0.55f * j / 12f) * (0.55f + 0.45f * (float) Math.sin(t * 2 - j * 0.6 + line));
                float a1 = op * (0.8f - 0.55f * (j + 1) / 12f) * (0.55f + 0.45f * (float) Math.sin(t * 2 - (j + 1) * 0.6 + line));
                int ca = FxShapes.argb(c0, Math.max(0f, a0)), cb = FxShapes.argb(c1, Math.max(0f, a1));
                patch(m, Mesh.HALO, r, lift, az - haz, az + haz, e0, e1, ca, ca, cb, cb);
            }
        }
    }

    // ---- portal rings

    private static void rings(Mesh m, float r, float lift, float op, float t, int c0, int c1, int c2) {
        int count = 9, seg = 72;
        for (int k = 0; k < count; k++) {
            float u = ((k + t * 0.25f) % count) / count;           // 0 at the zenith, 1 at the horizon
            float el = (float) Math.toRadians(90.0 - u * 84.0);
            float w = (float) Math.toRadians(0.8 + 1.6 * u);
            float a = op * (1f - u * 0.7f) * smooth(u * 8f);
            for (int s = 0; s < seg; s++) {
                float az0 = s * (float) (Math.PI * 2) / seg, az1 = (s + 1) * (float) (Math.PI * 2) / seg;
                float seg01 = 0.4f + 0.6f * (float) Math.max(0.0, Math.sin(az0 * 6 + t * (1 + k * 0.1)));
                int c = FxShapes.argb(FxShapes.mix(c0, c1, u), a * seg01);
                patch(m, Mesh.HALO, r, lift, az0, az1, el - w, el + w, c, c, c, c);
            }
        }
        blob(m, r, lift, 0f, (float) Math.toRadians(89.9), (float) Math.toRadians(16), FxShapes.argb(c2, op * 0.5f), FxShapes.argb(c2, 0f));
    }

    // ---- stars

    private static void stars(Mesh m, float r, float lift, float op, float time, int count, int rgb) {
        count = Math.min(count, MAX_STARS);
        for (int i = 0; i < count; i++) {
            float tw = 0.45f + 0.55f * (float) Math.sin(time * (0.8 + 3.0 * STAR_K[i]) + i * 1.9);
            float a = op * tw * (0.5f + 0.5f * STAR_K[i]);
            if (a < 0.02f) continue;
            float ang = (float) Math.toRadians(i % 9 == 0 ? 0.75 : 0.32);
            blobStar(m, r, lift, STAR_AZ[i] + time * 0.004f, STAR_EL[i], ang, FxShapes.argb(rgb, Math.min(1f, a * 1.4f)));
        }
    }

    /** A small diamond on the dome (cheaper than a blob). */
    private static void blobStar(Mesh m, float r, float lift, float az, float el, float ang, int color) {
        float d = ang;
        dome(az - d / Math.max(0.2f, (float) Math.cos(el)), el, r, lift);
        float x0 = px, y0 = py, z0 = pz;
        dome(az, el - d, r, lift);
        float x1 = px, y1 = py, z1 = pz;
        dome(az + d / Math.max(0.2f, (float) Math.cos(el)), el, r, lift);
        float x2 = px, y2 = py, z2 = pz;
        dome(az, el + d, r, lift);
        m.quad(Mesh.HALO, x0, y0, z0, x1, y1, z1, x2, y2, z2, px, py, pz, color);
    }
}
