package com.baroxvs.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Single source of truth for every BAROX VS module and every option of it.
 * The ClickGUI, the HUD, the 3D cosmetic renderer and the effect engine all read from here,
 * so a control in the menu always maps to something that really exists.
 * Every module is a local cosmetic, HUD or interface option: nothing here touches gameplay.
 */
public final class ModuleCatalog {
    private ModuleCatalog() {}

    public static final String COSMETICS = "Cosmetics";
    public static final String EFFECTS = "Effects";
    public static final String TRAILS = "Trails";
    public static final String HUD = "HUD";
    public static final String MISC = "Misc";
    public static final String THEMES = "Themes";
    public static final String[] CATEGORIES = {COSMETICS, EFFECTS, TRAILS, HUD, MISC};

    /** TOGGLE modules have an on/off switch; OPTIONS modules only open their settings. */
    public enum Kind { TOGGLE, OPTIONS }

    public record Module(String id, String name, String description, String category, Kind kind,
                         boolean defaultOn, boolean model3d, List<Setting> settings) {
        public Setting setting(String settingId) {
            for (Setting s : settings) if (s.id.equals(settingId)) return s;
            return null;
        }

        public boolean hasSettings() { return !settings.isEmpty(); }

        /** Effects, trails and the quality page get a live preview (drawn by the effect engine) in their settings window. */
        public boolean fxPreview() {
            return !model3d && (category.equals(EFFECTS) || category.equals(TRAILS) || id.equals("fx"));
        }

        /** The first colour option, used for the little colour dot on the menu row. */
        public Setting mainColor() {
            for (Setting s : settings) if (s.kind == Setting.Kind.COLOR) return s;
            return null;
        }
    }

    // ------------------------------------------------------------------ option lists

    public static final String[] WING_DESIGNS = {"Cyber", "Angel", "Dragon", "Butterfly", "Bat", "Crystal", "Mech", "Fairy", "Phoenix", "Pixel"};
    public static final String[] HALO_DESIGNS = {"Ring", "Double", "Spiky", "Hex"};
    public static final String[] CROWN_DESIGNS = {"Royal", "Spikes", "Flame", "Cyber"};
    public static final String[] HORN_DESIGNS = {"Devil", "Unicorn", "Ram", "Spikes"};
    public static final String[] EAR_DESIGNS = {"Cat", "Fox", "Bunny", "Wolf"};
    public static final String[] TAIL_DESIGNS = {"Fox", "Dragon", "Cyber", "Devil"};
    public static final String[] VISOR_DESIGNS = {"Cyber", "Shades", "Mask", "Monocle"};
    public static final String[] CAPE_DESIGNS = {"Flowing", "Short", "Hologram"};
    public static final String[] JETPACK_DESIGNS = {"Twin Jet", "Single", "Cube"};
    public static final String[] ORB_SHAPES = {"Orb", "Cube", "Diamond", "Star", "Crystal"};
    public static final String[] DRONE_DESIGNS = {"Drone", "Orb", "Cube", "Ring"};
    public static final String[] HOLO_SHAPES = {"Cube", "Octahedron", "Diamond"};
    public static final String[] RUNE_DESIGNS = {"Magic Circle", "Ring", "Hex", "Radar"};
    public static final String[] ANIMATIONS = {"Always", "When moving", "In air only", "Static"};
    public static final String[] DENSITIES = {"Low", "Medium", "High"};
    public static final String[] HUD_POSITIONS = {"Top left", "Top right", "Bottom left", "Bottom right"};

    public static final String[] ORBIT_TRIGGERS = {"Air swing", "Any swing", "Entity hit", "Jump", "Never"};
    public static final String[] ORBIT_REACTIONS = {"Push out", "Pull in", "Swing direction", "Scatter"};
    public static final String[] AURA_STYLES = {"Ring", "Double ring", "Dashed", "Runes"};
    public static final String[] GLINT_AREAS = {"Whole body", "Head", "Hands", "Feet", "Wings"};
    public static final String[] ATMOSPHERE_MODES = {"Motes", "Snow", "Embers", "Fireflies", "Rain", "Bubbles", "Leaves", "Digital rain"};
    public static final String[] HAND_MODES = {"Main hand", "Right hand", "Left hand", "Both hands"};
    public static final String[] WISP_SIDES = {"Right", "Left", "Both"};
    public static final String[] FLAME_AREAS = {"Feet", "Whole body"};
    public static final String[] TRAIL_WHEN = {"Moving", "Always", "In air"};
    public static final String[] RIBBON_STYLES = {"Flat", "Standing"};
    public static final String[] SKY_STYLES = {"Aurora", "Gradient", "Nebula", "Cyber Grid", "Portal Rings"};
    public static final String[] SKY_WHEN = {"Always", "Night only", "Day only"};
    public static final String[] SKY_DIMENSIONS = {"Overworld only", "All dimensions"};

    // ------------------------------------------------------------------ registry

    private static final List<Module> ALL = new ArrayList<>();
    private static final Map<String, Module> BY_ID = new HashMap<>();

    private static void add(Module m) {
        ALL.add(m);
        BY_ID.put(m.id(), m);
    }

    private static List<Setting> list(Setting... s) { return new ArrayList<>(Arrays.asList(s)); }

    private static void toggle(String id, String name, String desc, String cat, boolean on, Setting... s) {
        add(new Module(id, name, desc, cat, Kind.TOGGLE, on, false, list(s)));
    }

    private static void model(String id, String name, String desc, boolean on, Setting... s) {
        add(new Module(id, name, desc, COSMETICS, Kind.TOGGLE, on, true, list(s)));
    }

    private static void options(String id, String name, String desc, String cat, Setting... s) {
        add(new Module(id, name, desc, cat, Kind.OPTIONS, false, false, list(s)));
    }

    private static Setting theme(String id, String label, int slot) { return Setting.color(id, label, Setting.COLOR_THEME, slot); }

    private static Setting rgb(String id, String label, int rgb) { return Setting.color(id, label, rgb, 0); }

    /** Options of a trail that sheds our own shapes while you move (shape, colours, size, life, rise ...). */
    private static Setting[] shed(int shape, double color, double color2, double life, double rise, Setting... extra) {
        List<Setting> out = list(
            Setting.choice("shape", "Shape", shape, FxShapes.NAMES),
            Setting.color("color", "Color", color, 0),
            Setting.color("color2", "Second color", color2, 1),
            Setting.slider("size", "Size", 0.3, 3.0, 0.05, 1.0, "x"),
            Setting.slider("amount", "Amount", 10, 300, 5, 100, "%"),
            Setting.slider("life", "Life", 0.2, 4.0, 0.1, life, "s"),
            Setting.slider("rise", "Rise / fall", -1.0, 1.0, 0.05, rise, ""),
            Setting.slider("spread", "Spread", 0.2, 2.0, 0.05, 1.0, "x"),
            Setting.slider("spin", "Spin", 0, 3, 0.05, 1.0, "x"),
            glow(60),
            Setting.choice("when", "Shed", 0, TRAIL_WHEN));
        out.addAll(Arrays.asList(extra));
        return out.toArray(new Setting[0]);
    }

    /** Options of the jump / landing effects (a ring on the ground plus shapes flying out). */
    private static Setting[] burst(int shape, int count, double radius) {
        return new Setting[] {
            Setting.choice("shape", "Shape", shape, FxShapes.NAMES),
            theme("color", "Color", 0),
            theme("color2", "Second color", 1),
            size(0.3, 3.0, 1.0),
            Setting.slider("count", "Shapes", 0, 24, 1, count, ""),
            Setting.toggle("ring", "Shockwave ring", true),
            Setting.slider("radius", "Ring radius", 0.5, 4.0, 0.1, radius, ""),
            Setting.slider("life", "Life", 0.3, 3.0, 0.1, 1.0, "s"),
            glow(70)};
    }

    private static Setting[] concat(Setting[] a, Setting... b) {
        Setting[] out = Arrays.copyOf(a, a.length + b.length);
        System.arraycopy(b, 0, out, a.length, b.length);
        return out;
    }

    private static Setting size(double min, double max, double def) { return Setting.slider("size", "Size", min, max, 0.05, def, "x"); }

    private static Setting glow(double def) { return Setting.slider("glow", "Glow", 0, 100, 5, def, "%"); }

    private static Setting speed(String label, double def) { return Setting.slider("speed", label, 0, 3, 0.05, def, "x"); }

    static {
        // ---------------- Cosmetics: real 3D models drawn on your own player
        model("wings", "Wings", "3D wings on your back: 10 designs, any color, size and flap", true,
            Setting.choice("design", "Design", 0, WING_DESIGNS),
            theme("color", "Main color", 0),
            theme("color2", "Tip color", 1),
            theme("accent", "Glow color", 0),
            size(0.4, 3.0, 1.0),
            Setting.slider("spread", "Spread", 0, 100, 1, 55, "%"),
            Setting.slider("flap_speed", "Flap speed", 0, 3, 0.05, 1.0, "x"),
            Setting.slider("flap_amount", "Flap amount", 0, 100, 1, 45, "%"),
            Setting.slider("thickness", "Thickness", 0.2, 3.0, 0.05, 1.0, "x"),
            Setting.slider("opacity", "Opacity", 20, 100, 1, 90, "%"),
            glow(70),
            Setting.slider("feathers", "Feathers", 3, 10, 1, 6, ""),
            Setting.slider("height", "Height", -0.3, 0.3, 0.01, 0, ""),
            Setting.slider("back", "Distance", -0.1, 0.3, 0.01, 0, ""),
            Setting.choice("animation", "Animation", 0, ANIMATIONS),
            Setting.toggle("fullbright", "Fullbright", true),
            Setting.toggle("hide_elytra", "Hide with elytra", true),
            Setting.toggle("sparkles", "Tip sparkles", false));
        model("halo", "Halo", "Floating 3D halo above your head", true,
            Setting.choice("design", "Design", 0, HALO_DESIGNS),
            theme("color", "Color", 0),
            size(0.5, 2.0, 1.0),
            Setting.slider("height", "Height", -0.1, 0.6, 0.01, 0.2, ""),
            Setting.slider("spin", "Spin", 0, 3, 0.05, 1.0, "x"),
            Setting.slider("thickness", "Thickness", 0.3, 3.0, 0.05, 1.0, "x"),
            Setting.slider("tilt", "Tilt", 0, 40, 1, 8, "°"),
            glow(80),
            Setting.toggle("bob", "Bobbing", true));
        model("crown", "Crown", "3D crown with a glowing gem", false,
            Setting.choice("design", "Design", 0, CROWN_DESIGNS),
            rgb("color", "Color", 0xFFC83D),
            theme("gem", "Gem color", 0),
            size(0.5, 2.0, 1.0),
            Setting.slider("height", "Height", -0.1, 0.4, 0.01, 0, ""),
            glow(40),
            Setting.toggle("sparkles", "Sparkles", false));
        model("horns", "Horns", "3D horns on your head", false,
            Setting.choice("design", "Design", 0, HORN_DESIGNS),
            theme("color", "Color", 0),
            theme("tip", "Tip color", 1),
            size(0.5, 2.0, 1.0),
            Setting.slider("spread", "Spread", 0, 100, 1, 50, "%"),
            glow(40));
        model("ears", "Ears", "3D animal ears", false,
            Setting.choice("design", "Design", 0, EAR_DESIGNS),
            theme("color", "Color", 0),
            rgb("inner", "Inner color", 0xFF9EC4),
            size(0.5, 2.0, 1.0),
            Setting.slider("tilt", "Tilt", 0, 40, 1, 12, "°"));
        model("tail", "Tail", "3D tail with a swaying animation", false,
            Setting.choice("design", "Design", 0, TAIL_DESIGNS),
            theme("color", "Color", 0),
            theme("tip", "Tip color", 1),
            size(0.5, 2.0, 1.0),
            Setting.slider("length", "Length", 0.5, 2.0, 0.05, 1.0, "x"),
            Setting.slider("wave_speed", "Wave speed", 0, 3, 0.05, 1.0, "x"),
            Setting.slider("wave_amount", "Wave amount", 0, 100, 1, 50, "%"),
            glow(40));
        model("visor", "Visor", "Glowing cyber visor on your face", false,
            Setting.choice("design", "Design", 0, VISOR_DESIGNS),
            theme("color", "Color", 0),
            glow(80),
            Setting.slider("opacity", "Opacity", 20, 100, 1, 85, "%"),
            Setting.toggle("scan", "Scan line", true));
        model("cape", "Cape", "3D flowing cape with a glowing border", false,
            Setting.choice("design", "Design", 0, CAPE_DESIGNS),
            theme("color", "Main color", 0),
            theme("color2", "Edge color", 1),
            Setting.slider("length", "Length", 0.5, 1.5, 0.05, 1.0, "x"),
            Setting.slider("width", "Width", 0.6, 1.6, 0.05, 1.0, "x"),
            Setting.slider("sway", "Sway", 0, 100, 1, 60, "%"),
            Setting.slider("opacity", "Opacity", 20, 100, 1, 85, "%"),
            glow(60));
        model("jetpack", "Jetpack", "3D jetpack with thruster flames", false,
            Setting.choice("design", "Design", 0, JETPACK_DESIGNS),
            theme("color", "Color", 0),
            theme("accent", "Accent color", 1),
            size(0.5, 2.0, 1.0),
            glow(70),
            Setting.toggle("flames", "Thruster flames", true));
        model("gyro", "Gyro Rings", "Spinning 3D rings around your body", false,
            Setting.slider("rings", "Rings", 1, 4, 1, 3, ""),
            theme("color", "Color", 0),
            theme("color2", "Second color", 1),
            Setting.slider("radius", "Radius", 0.5, 2.0, 0.05, 1.0, ""),
            speed("Speed", 1.0),
            Setting.slider("thickness", "Thickness", 0.3, 3.0, 0.05, 1.0, "x"),
            Setting.slider("tilt", "Tilt", 0, 90, 1, 30, "°"),
            glow(80));
        model("orbs", "Orbit Orbs", "3D shapes orbiting around you", false,
            Setting.choice("shape", "Shape", 0, ORB_SHAPES),
            theme("color", "Color", 0),
            theme("color2", "Second color", 1),
            Setting.slider("count", "Count", 1, 12, 1, 4, ""),
            Setting.slider("radius", "Radius", 0.4, 2.0, 0.05, 0.9, ""),
            speed("Speed", 1.0),
            size(0.3, 3.0, 1.0),
            Setting.slider("height", "Height", 0.2, 2.0, 0.05, 1.0, ""),
            Setting.slider("bob", "Bobbing", 0, 100, 1, 40, "%"),
            glow(70));
        model("drone", "Drone", "Little 3D companion floating next to you", false,
            Setting.choice("design", "Design", 0, DRONE_DESIGNS),
            theme("color", "Color", 0),
            theme("accent", "Accent color", 1),
            size(0.5, 3.0, 1.0),
            Setting.choice("side", "Side", 0, "Right", "Left"),
            glow(70));
        model("hologram", "Hologram", "Rotating wireframe shape around you", false,
            Setting.choice("shape", "Shape", 0, HOLO_SHAPES),
            theme("color", "Color", 0),
            size(0.5, 2.5, 1.0),
            speed("Spin", 1.0),
            Setting.slider("thickness", "Thickness", 0.3, 3.0, 0.05, 1.0, "x"),
            glow(80),
            Setting.toggle("inner", "Inner shape", true));
        model("rune", "Floor Rune", "Glowing rune circle under your feet", false,
            Setting.choice("design", "Design", 0, RUNE_DESIGNS),
            theme("color", "Color", 0),
            size(0.5, 3.0, 1.0),
            speed("Spin", 1.0),
            glow(80),
            Setting.toggle("pulse", "Pulse", true));

        // ---------------- Effects: shapes drawn by this mod around your own player (no vanilla particles)
        toggle("orbit_shapes", "Orbit Shapes", "Shapes circling you; they bounce back when you swing at the air", EFFECTS, true,
            Setting.choice("shape", "Shape", FxShapes.SQUARE, FxShapes.NAMES),
            theme("color", "Color", 0),
            theme("color2", "Second color", 1),
            Setting.slider("count", "Count", 1, 24, 1, 8, ""),
            Setting.slider("rings", "Rings", 1, 3, 1, 2, ""),
            Setting.slider("radius", "Radius", 0.5, 3.0, 0.05, 1.15, ""),
            Setting.slider("height", "Height", 0, 2.2, 0.05, 1.0, ""),
            size(0.3, 3.0, 1.0),
            speed("Orbit speed", 1.0),
            Setting.slider("spin", "Spin", 0, 3, 0.05, 1.0, "x"),
            Setting.slider("wave", "Wave", 0, 100, 1, 35, "%"),
            Setting.slider("fill", "Fill", 0, 100, 1, 55, "%"),
            glow(60),
            Setting.toggle("outline", "Neon outline", true),
            Setting.toggle("tumble", "Tumble in 3D", false),
            Setting.toggle("path", "Show orbit path", false),
            Setting.choice("trigger", "Bounce on", 0, ORBIT_TRIGGERS),
            Setting.choice("reaction", "Reaction", 0, ORBIT_REACTIONS),
            Setting.slider("bounce", "Bounce strength", 0, 250, 5, 100, "%"),
            Setting.slider("return", "Return speed", 0.4, 3.0, 0.05, 1.0, "x"),
            Setting.slider("elastic", "Elasticity", 0, 100, 1, 60, "%"));
        toggle("aura", "Aura Ring", "Glowing ring on the ground around you", EFFECTS, true,
            Setting.choice("style", "Style", 0, AURA_STYLES),
            theme("color", "Color", 0),
            theme("color2", "Second color", 1),
            Setting.slider("radius", "Radius", 0.3, 2.0, 0.05, 0.8, ""),
            speed("Speed", 1.0),
            size(0.4, 3.0, 1.0),
            glow(70),
            Setting.slider("orbiters", "Runners", 0, 12, 1, 3, ""),
            Setting.choice("shape", "Runner shape", FxShapes.DIAMOND, FxShapes.NAMES),
            Setting.toggle("pillars", "Light pillars", true),
            Setting.slider("pillar_height", "Pillar height", 0.3, 3.0, 0.05, 1.1, ""));
        toggle("glints", "Glints", "Twinkling star flashes around your body", EFFECTS, true,
            Setting.choice("shape", "Shape", FxShapes.STAR, FxShapes.NAMES),
            Setting.choice("where", "Where", 0, GLINT_AREAS),
            theme("color", "Color", 0),
            theme("color2", "Second color", 1),
            size(0.3, 3.0, 1.0),
            Setting.slider("amount", "Amount", 10, 300, 5, 100, "%"),
            speed("Twinkle speed", 1.0),
            Setting.slider("spread", "Spread", 0.4, 2.0, 0.05, 1.0, "x"),
            Setting.slider("drift", "Drift", 0, 100, 1, 40, "%"),
            glow(80));
        toggle("atmosphere", "Atmosphere", "Shapes drifting in the air around you: dust, snow, embers, fireflies, rain ...", EFFECTS, false,
            Setting.choice("mode", "Mode", 0, ATMOSPHERE_MODES),
            Setting.choice("shape", "Shape", 0, FxShapes.NAMES_AUTO),
            theme("color", "Color", 0),
            theme("color2", "Second color", 1),
            size(0.3, 3.0, 1.0),
            Setting.slider("amount", "Amount", 10, 300, 5, 100, "%"),
            Setting.slider("range", "Range", 3, 16, 1, 8, ""),
            Setting.slider("height", "Height", 2, 12, 0.5, 5, ""),
            speed("Speed", 1.0),
            Setting.slider("wind", "Wind", 0, 100, 1, 30, "%"),
            glow(50));
        toggle("hand_glow", "Hand Glow", "Glowing orb at your hand with little shapes circling it", EFFECTS, false,
            Setting.choice("hand", "Hand", 0, HAND_MODES),
            Setting.choice("shape", "Orbiter shape", FxShapes.DIAMOND, FxShapes.NAMES),
            theme("color", "Color", 0),
            theme("color2", "Second color", 1),
            size(0.3, 3.0, 1.0),
            speed("Speed", 1.0),
            glow(80),
            Setting.slider("orbiters", "Orbiters", 0, 6, 1, 3, ""),
            Setting.slider("sparks", "Sparks", 0, 10, 1, 3, ""));
        toggle("sword_trail", "Slash Trail", "Glowing ribbon that follows your swing", EFFECTS, false,
            theme("color", "Color", 0),
            theme("color2", "Edge color", 1),
            Setting.slider("length", "Length", 0.8, 3.5, 0.05, 1.8, ""),
            Setting.slider("intensity", "Intensity", 0.3, 1.5, 0.05, 1.0, "x"),
            Setting.slider("duration", "Fade time", 0.1, 1.0, 0.05, 0.35, "s"),
            glow(70),
            Setting.toggle("weapon_only", "Only with a sword", true));
        toggle("shoulder_wisp", "Shoulder Wisp", "Glowing wisp floating beside your shoulder", EFFECTS, false,
            Setting.choice("side", "Side", 0, WISP_SIDES),
            theme("color", "Color", 0),
            theme("color2", "Tail color", 1),
            size(0.3, 3.0, 1.0),
            speed("Speed", 1.0),
            glow(80),
            Setting.slider("tail", "Tail", 0, 100, 1, 60, "%"),
            Setting.slider("wander", "Wander", 0, 2, 0.05, 1.0, "x"));
        toggle("lightning_aura", "Lightning", "Electric bolts crackling around you", EFFECTS, false,
            theme("color", "Glow color", 0),
            rgb("color2", "Core color", 0xFFFFFF),
            Setting.slider("bolts", "Bolts", 1, 8, 1, 3, ""),
            Setting.slider("radius", "Radius", 0.4, 2.5, 0.05, 0.9, ""),
            Setting.slider("rate", "Flicker rate", 0.4, 3.0, 0.05, 1.0, "x"),
            Setting.slider("thickness", "Thickness", 0.3, 3.0, 0.05, 1.0, "x"),
            glow(80),
            Setting.toggle("ground", "Strike the ground", false));
        toggle("ender_swirl", "Helix Swirl", "Spiral of shapes rising around you", EFFECTS, false,
            Setting.choice("shape", "Shape", FxShapes.DIAMOND, FxShapes.NAMES),
            theme("color", "Color", 0),
            theme("color2", "Second color", 1),
            Setting.slider("strands", "Strands", 1, 4, 1, 2, ""),
            Setting.slider("count", "Shapes per strand", 4, 24, 1, 12, ""),
            Setting.slider("radius", "Radius", 0.3, 2.0, 0.05, 0.7, ""),
            Setting.slider("height", "Height", 0.5, 3.0, 0.05, 2.0, ""),
            Setting.slider("twist", "Twist", 0, 3, 0.05, 1.0, "x"),
            speed("Speed", 1.0),
            size(0.3, 3.0, 1.0),
            glow(70),
            Setting.toggle("reverse", "Reverse", false));
        toggle("soul_flames", "Flames", "Flame tongues licking around you", EFFECTS, false,
            Setting.choice("where", "Where", 0, FLAME_AREAS),
            theme("color", "Hot color", 0),
            theme("color2", "Tip color", 1),
            size(0.3, 3.0, 1.0),
            Setting.slider("amount", "Amount", 10, 300, 5, 100, "%"),
            Setting.slider("height", "Height", 0.3, 2.5, 0.05, 1.0, "x"),
            Setting.slider("spread", "Spread", 0.4, 2.0, 0.05, 1.0, "x"),
            glow(60));
        toggle("enchant_glyphs", "Rune Glyphs", "Magic runes flying towards you", EFFECTS, false,
            theme("color", "Color", 0),
            theme("color2", "Second color", 1),
            size(0.3, 3.0, 1.0),
            Setting.slider("amount", "Amount", 10, 300, 5, 100, "%"),
            speed("Speed", 1.0),
            glow(70));
        toggle("rain_cloud", "Rain Cloud", "A little cloud raining above your head", EFFECTS, false,
            rgb("cloud", "Cloud color", 0xDDE6F2),
            rgb("color", "Rain color", 0x4DA3FF),
            rgb("color2", "Rain fade color", 0xBFE3FF),
            Setting.slider("height", "Height", 0.2, 1.2, 0.05, 0.6, ""));
        toggle("beam", "Energy Beam", "Column of light rising from you", EFFECTS, false,
            theme("color", "Color", 0),
            theme("color2", "Top color", 1),
            Setting.slider("height", "Height", 1, 12, 0.25, 4, ""),
            Setting.slider("radius", "Radius", 0.1, 1.0, 0.05, 0.35, ""),
            speed("Speed", 1.0),
            glow(70),
            Setting.toggle("rings", "Rising rings", true));
        toggle("sky_aura", "Aura Sky", "Recolors the sky: aurora, gradient, nebula, neon grid or portal rings", EFFECTS, true,
            Setting.choice("style", "Style", 0, SKY_STYLES),
            theme("color", "Main color", 0),
            theme("color2", "Second color", 1),
            rgb("color3", "Accent color", 0x4DFFB5),
            Setting.slider("opacity", "Opacity", 0, 100, 1, 60, "%"),
            glow(70),
            speed("Speed", 1.0),
            Setting.slider("height", "Aurora height", 10, 70, 1, 34, "\u00b0"),
            Setting.slider("ribbons", "Ribbons", 1, 6, 1, 3, ""),
            Setting.toggle("stars", "Stars", true),
            Setting.slider("star_count", "Star amount", 20, 400, 10, 200, ""),
            Setting.toggle("horizon", "Horizon glow", true),
            Setting.choice("when", "Show", 0, SKY_WHEN),
            Setting.choice("dimension", "Dimension", 0, SKY_DIMENSIONS));

        // ---------------- Trails: shapes triggered by your own movement
        toggle("footsteps", "Footsteps", "Glowing shapes stamped on the ground where you walk", TRAILS, false,
            Setting.choice("shape", "Shape", FxShapes.SQUARE, FxShapes.NAMES),
            theme("color", "Color", 0),
            theme("color2", "Second color", 1),
            size(0.3, 3.0, 1.0),
            Setting.slider("life", "Life", 0.4, 4.0, 0.1, 1.6, "s"),
            Setting.slider("spacing", "Spacing", 0.4, 2.0, 0.05, 0.9, ""),
            glow(40));
        toggle("jump_crystal", "Jump Burst", "Ring and shards when you jump", TRAILS, false, burst(FxShapes.SHARD, 8, 1.6));
        toggle("landing_burst", "Landing Shockwave", "Shockwave ring and shapes when you land", TRAILS, false, burst(FxShapes.SQUARE, 12, 2.4));
        toggle("sparkle_trail", "Glint Trail", "Star glints trailing around you", TRAILS, false,
            shed(FxShapes.STAR, Setting.COLOR_THEME, Setting.COLOR_THEME, 0.8, 0.25));
        toggle("heart_trail", "Heart Trail", "Floating hearts", TRAILS, false, shed(FxShapes.HEART, 0xFF4D88, 0xFF9EC4, 1.3, 0.5));
        toggle("bubble_trail", "Bubble Trail", "Rising bubble rings", TRAILS, false, shed(FxShapes.RING, 0x66CCFF, 0xFFFFFF, 1.6, 0.45));
        toggle("note_trail", "Note Trail", "Musical notes floating up", TRAILS, false, shed(FxShapes.NOTE, Setting.COLOR_THEME, Setting.COLOR_THEME, 1.4, 0.6));
        toggle("flame_trail", "Flame Trail", "Flames behind your feet", TRAILS, false, shed(FxShapes.FLAME, 0xFF8A1F, 0xFF3D00, 0.7, 0.5));
        toggle("rainbow_trail", "Rainbow Trail", "Ribbon of color behind you", TRAILS, false,
            Setting.color("color", "Color", Setting.COLOR_RAINBOW, 0),
            Setting.color("color2", "Second color", Setting.COLOR_RAINBOW, 1),
            Setting.choice("style", "Style", 0, RIBBON_STYLES),
            Setting.slider("width", "Width", 0.1, 1.2, 0.05, 0.45, ""),
            Setting.slider("height", "Height", 0, 1.8, 0.05, 0.9, ""),
            Setting.slider("length", "Length", 0.4, 4.0, 0.1, 1.4, "s"),
            glow(60));
        toggle("cherry_trail", "Cherry Trail", "Cherry blossom petals drifting down", TRAILS, false, shed(FxShapes.PETAL, 0xFFB7D5, 0xFF7FAE, 2.0, -0.4));
        toggle("wing_trail", "Wing Trail", "Glints shed from the tips of your wings", TRAILS, false,
            shed(FxShapes.STAR, Setting.COLOR_THEME, Setting.COLOR_THEME, 0.9, 0.1));

        // ---------------- HUD: information widgets that only read your own state
        toggle("status_bar", "Info Panel", "Compact BAROX panel with the lines below", HUD, true);
        toggle("fps", "FPS", "Frames per second (Info Panel line)", HUD, true);
        toggle("direction", "Direction", "Compass direction (Info Panel line)", HUD, true);
        toggle("biome", "Biome", "Current biome name (Info Panel line)", HUD, false);
        toggle("ping", "Ping", "Connection latency (Info Panel line)", HUD, false);
        toggle("local_clock", "Clock", "Local device time (Info Panel line)", HUD, false);
        toggle("coordinates", "Coordinates", "Your XYZ in a compact pill", HUD, true);
        toggle("speed_graph", "Speed", "Blocks-per-second readout with a graph", HUD, true);
        toggle("potions_list", "Potions List", "Your active effects and timers", HUD, true);
        toggle("keybinds", "KeyBinds", "Overview of the BAROX keybinds", HUD, true);
        toggle("armor_hud", "Armor HUD", "Durability of the armor you wear", HUD, true);

        // ---------------- Misc: presentation widgets and interface options
        toggle("ticker", "Top Bar", "Top ticker bar with equalizer", MISC, true,
            Setting.text("text", "Text", "Welcome to BAROX VS - client side visuals only"),
            Setting.toggle("equalizer", "Equalizer", true),
            theme("color", "Highlight color", 0),
            Setting.slider("speed", "Word speed", 0.3, 3.0, 0.05, 1.0, "x"));
        toggle("music_card", "Now Playing", "Decorative music card (display only, no audio)", MISC, true,
            Setting.text("title", "Title", "BAROX VS"),
            Setting.text("artist", "Artist", "visuals only"),
            theme("color", "Color", 0));
        toggle("target_card", "Target Card", "Name, distance and health of the entity under your crosshair", MISC, true);
        toggle("hit_numbers", "Hit Numbers", "Floating damage numbers near the crosshair", MISC, true,
            Setting.slider("size", "Size", 0.8, 3.0, 0.1, 1.4, "x"));
        toggle("crosshair_ring", "Crosshair Ring", "Ring around the crosshair that fills with attack cooldown", MISC, true,
            theme("color", "Color", 0),
            Setting.slider("radius", "Radius", 4, 16, 1, 7, ""));
        toggle("toasts", "Toasts", "Enabled / Disabled notifications", MISC, true);
        options("fx", "Effects Quality", "Amount, size, opacity and safety options for every effect", MISC,
            Setting.choice("density", "Density", 1, DENSITIES),
            Setting.slider("amount", "Global amount", 25, 300, 5, 100, "%"),
            Setting.slider("size", "Global size", 0.5, 2.0, 0.05, 1.0, "x"),
            Setting.slider("opacity", "Global opacity", 20, 100, 1, 100, "%"),
            Setting.slider("max", "Max shapes", 100, 1500, 50, 700, ""),
            Setting.toggle("near_fade", "Fade near camera", true),
            Setting.toggle("first_person", "Show in first person", true));
        options("hud_layout", "HUD Layout", "Scale, opacity and corner of the HUD panels", MISC,
            Setting.choice("position", "Info Panel corner", 0, HUD_POSITIONS),
            Setting.slider("scale", "HUD scale", 60, 150, 5, 100, "%"),
            Setting.slider("opacity", "Panel opacity", 30, 100, 1, 82, "%"));
        options("gui_style", "Menu Style", "Look of this menu", MISC,
            Setting.slider("opacity", "Panel opacity", 40, 100, 1, 82, "%"),
            Setting.toggle("grid", "Cyber grid", true),
            Setting.toggle("animations", "Animations", true),
            Setting.toggle("preview_spin", "Spin preview", true));

        // The editable "Custom" theme. It is listed in the Themes column, not in a module column.
        options("theme_custom", "Custom theme", "Pick your own two theme colors", THEMES,
            Setting.color("primary", "Primary color", 0x19E6FF, 0),
            Setting.color("secondary", "Secondary color", 0x7B3DFF, 1));
    }

    public static List<Module> all() { return ALL; }

    public static Module byId(String id) { return BY_ID.get(id); }

    public static List<Module> inCategory(String category) {
        List<Module> out = new ArrayList<>();
        for (Module m : ALL) if (m.category().equals(category)) out.add(m);
        return out;
    }
}
