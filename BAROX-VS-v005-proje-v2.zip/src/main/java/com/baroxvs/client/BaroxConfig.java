package com.baroxvs.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/** Persistent client-side settings, stored in config/baroxvs.json. Every value is described by a {@link Setting}. */
public final class BaroxConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("baroxvs.json");

    /** Index into the theme list ({@link Themes}); Themes.CUSTOM_INDEX is the editable theme. */
    public int theme = Themes.DEFAULT_INDEX;

    /** Module id -> switch state. Missing ids fall back to the catalog default. */
    public Map<String, Boolean> modules = new HashMap<>();
    /** "module.setting" -> numeric value (slider value, choice index, toggle 0/1 or packed colour). */
    public Map<String, Double> values = new HashMap<>();
    /** "module.setting" -> text value. */
    public Map<String, String> texts = new HashMap<>();

    // ------------------------------------------------------------------ switches

    public boolean isOn(String id) {
        ModuleCatalog.Module module = ModuleCatalog.byId(id);
        boolean fallback = module != null && module.defaultOn();
        if (modules == null) return fallback;
        Boolean value = modules.get(id);
        return value == null ? fallback : value;
    }

    public void setOn(String id, boolean on) {
        if (modules == null) modules = new HashMap<>();
        modules.put(id, on);
    }

    // ------------------------------------------------------------------ settings

    private static String key(String module, String setting) { return module + "." + setting; }

    private static Setting lookup(String module, String setting) {
        ModuleCatalog.Module m = ModuleCatalog.byId(module);
        return m == null ? null : m.setting(setting);
    }

    /** Current numeric value of a setting (the default when the user never touched it). */
    public double num(String module, String setting) {
        Setting s = lookup(module, setting);
        Double stored = values == null ? null : values.get(key(module, setting));
        // asserts are only on in the offline tests: they catch code that reads an option the catalog does not define
        assert s != null || stored != null : "unknown setting " + module + "." + setting;
        if (s == null) return stored == null ? 0 : stored;
        return s.clamp(stored == null ? s.def : stored);
    }

    public int idx(String module, String setting) { return (int) num(module, setting); }

    public float f(String module, String setting) { return (float) num(module, setting); }

    public boolean flag(String module, String setting) { return num(module, setting) >= 0.5; }

    public void set(String module, String setting, double value) {
        if (values == null) values = new HashMap<>();
        Setting s = lookup(module, setting);
        double v = s == null ? value : s.clamp(value);
        if (s != null && v == s.def) values.remove(key(module, setting));
        else values.put(key(module, setting), v);
    }

    public String text(String module, String setting) {
        Setting s = lookup(module, setting);
        String stored = texts == null ? null : texts.get(key(module, setting));
        return stored != null ? stored : s == null ? "" : s.defText;
    }

    public void setText(String module, String setting, String value) {
        if (texts == null) texts = new HashMap<>();
        Setting s = lookup(module, setting);
        String text = value == null ? "" : value;
        if (s != null && text.equals(s.defText)) texts.remove(key(module, setting));
        else texts.put(key(module, setting), text);
    }

    /** True when the user changed anything of this module. */
    public boolean isModified(String module) {
        String prefix = module + ".";
        for (String k : values.keySet()) if (k.startsWith(prefix)) return true;
        for (String k : texts.keySet()) if (k.startsWith(prefix)) return true;
        return false;
    }

    /** True when the user changed this one setting. */
    public boolean isSettingModified(String module, String setting) {
        String k = key(module, setting);
        return (values != null && values.containsKey(k)) || (texts != null && texts.containsKey(k));
    }

    /** Restores one setting to its default. */
    public void resetSetting(String module, String setting) {
        String k = key(module, setting);
        if (values != null) values.remove(k);
        if (texts != null) texts.remove(k);
    }

    /** Restores every setting of a module (not its switch) to the defaults. */
    public void reset(String module) {
        String prefix = module + ".";
        values.keySet().removeIf(k -> k.startsWith(prefix));
        texts.keySet().removeIf(k -> k.startsWith(prefix));
    }

    /**
     * Resolved colour (0xRRGGBB) of a colour setting. "Theme" follows the selected theme, "Rainbow" cycles
     * with timeSec; phase shifts the rainbow so neighbouring shapes get different hues.
     */
    public int rgb(String module, String setting, double timeSec, double phase) {
        Setting s = lookup(module, setting);
        double v = num(module, setting);
        if (v == Setting.COLOR_RAINBOW) return Colors.rainbow((float) (timeSec * 0.25 + phase)) & 0xFFFFFF;
        if (v == Setting.COLOR_THEME) {
            Theme t = Themes.current(this);
            return (s != null && s.slot == 1 ? t.secondary() : t.primary()) & 0xFFFFFF;
        }
        return (int) v & 0xFFFFFF;
    }

    // ------------------------------------------------------------------ global options

    /** 1 = low, 2 = medium, 3 = high. */
    public int density() { return idx("fx", "density") + 1; }

    /** Multiplier applied to every effect count: density preset times the global amount slider. */
    public double amountScale() {
        double[] preset = {0.5, 1.0, 1.7};
        return preset[Math.max(0, Math.min(2, idx("fx", "density")))] * num("fx", "amount") / 100.0;
    }

    /** 0 = top left, 1 = top right, 2 = bottom left, 3 = bottom right. */
    public int hudPosition() { return idx("hud_layout", "position"); }

    // ------------------------------------------------------------------ persistence

    public static BaroxConfig load() {
        try {
            if (Files.exists(FILE)) {
                BaroxConfig loaded = GSON.fromJson(Files.readString(FILE), BaroxConfig.class);
                if (loaded != null) {
                    loaded.sanitize();
                    return loaded;
                }
            }
        } catch (Exception exception) {
            System.err.println("[BAROX VS] Config load failed; defaults will be used: " + exception.getMessage());
        }
        BaroxConfig config = new BaroxConfig();
        config.save();
        return config;
    }

    public void sanitize() {
        if (modules == null) modules = new HashMap<>();
        if (values == null) values = new HashMap<>();
        if (texts == null) texts = new HashMap<>();
        theme = Math.max(0, Math.min(Themes.CUSTOM_INDEX, theme));
    }

    public void save() {
        sanitize();
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(this));
        } catch (IOException exception) {
            System.err.println("[BAROX VS] Could not save config: " + exception.getMessage());
        }
    }
}
