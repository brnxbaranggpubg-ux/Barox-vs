package com.baroxvs.client;

/** Pure colour helpers (no Minecraft types), shared by the GUI, the HUD, the effects and the 3D models. */
public final class Colors {
    private Colors() {}

    /** Preset swatches offered by the colour picker (after the Theme and Rainbow entries). */
    public static final int[] PRESETS = {
        0xFF3B30, 0xFF8A1F, 0xFFD60A, 0x7CFF4D, 0x19D86B, 0x22E6D8,
        0x2D9CFF, 0x5B5CFF, 0xB44CFF, 0xFF4DDB, 0xFFFFFF, 0x20232B
    };

    public static int r(int argb) { return (argb >> 16) & 255; }
    public static int g(int argb) { return (argb >> 8) & 255; }
    public static int b(int argb) { return argb & 255; }
    public static int a(int argb) { return (argb >>> 24) & 255; }

    public static int argb(int a, int r, int g, int b) {
        return (clamp255(a) << 24) | (clamp255(r) << 16) | (clamp255(g) << 8) | clamp255(b);
    }

    public static int clamp255(int v) { return Math.max(0, Math.min(255, v)); }

    public static int withAlpha(int rgb, int alpha) { return (clamp255(alpha) << 24) | (rgb & 0xFFFFFF); }

    /** Linear blend of two colours (alpha included). */
    public static int lerp(int c0, int c1, float t) {
        t = Math.max(0f, Math.min(1f, t));
        return argb(Math.round(a(c0) + (a(c1) - a(c0)) * t), Math.round(r(c0) + (r(c1) - r(c0)) * t),
                Math.round(g(c0) + (g(c1) - g(c0)) * t), Math.round(b(c0) + (b(c1) - b(c0)) * t));
    }

    /** Multiplies the RGB channels (keeps alpha). f below 1 darkens, above 1 brightens. */
    public static int shade(int argb, float f) {
        return argb(a(argb), Math.round(r(argb) * f), Math.round(g(argb) * f), Math.round(b(argb) * f));
    }

    /** Mixes a colour towards white. */
    public static int lighten(int argb, float t) { return lerp(argb, withAlpha(0xFFFFFF, a(argb)), t); }

    /** HSB (all 0..1) to opaque 0xFFRRGGBB. */
    public static int hsb(float h, float s, float v) {
        h = h - (float) Math.floor(h);
        s = Math.max(0f, Math.min(1f, s));
        v = Math.max(0f, Math.min(1f, v));
        float hh = h * 6f;
        int i = (int) Math.floor(hh);
        float f = hh - i;
        float p = v * (1f - s);
        float q = v * (1f - s * f);
        float t = v * (1f - s * (1f - f));
        float rr, gg, bb;
        switch (i % 6) {
            case 0: rr = v; gg = t; bb = p; break;
            case 1: rr = q; gg = v; bb = p; break;
            case 2: rr = p; gg = v; bb = t; break;
            case 3: rr = p; gg = q; bb = v; break;
            case 4: rr = t; gg = p; bb = v; break;
            default: rr = v; gg = p; bb = q; break;
        }
        return argb(255, Math.round(rr * 255f), Math.round(gg * 255f), Math.round(bb * 255f));
    }

    /** Opaque RGB to {h, s, v}, each 0..1. */
    public static float[] toHsb(int rgb) {
        float rr = r(rgb) / 255f, gg = g(rgb) / 255f, bb = b(rgb) / 255f;
        float max = Math.max(rr, Math.max(gg, bb));
        float min = Math.min(rr, Math.min(gg, bb));
        float d = max - min;
        float h;
        if (d == 0f) h = 0f;
        else if (max == rr) h = (((gg - bb) / d) % 6f) / 6f;
        else if (max == gg) h = (((bb - rr) / d) + 2f) / 6f;
        else h = (((rr - gg) / d) + 4f) / 6f;
        if (h < 0f) h += 1f;
        return new float[]{h, max == 0f ? 0f : d / max, max};
    }

    /** Fully saturated rainbow colour for hue 0..1. */
    public static int rainbow(float hue) { return hsb(hue, 0.85f, 1f); }
}
