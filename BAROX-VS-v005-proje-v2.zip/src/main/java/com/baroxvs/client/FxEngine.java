package com.baroxvs.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * The effect engine of BAROX VS: every effect (orbiting shapes, glints, atmosphere, trails, the aura sky ...) is simulated
 * and turned into geometry here, with our own shapes ({@link FxShapes}). Nothing in this class, or anywhere else in the
 * mod, spawns a vanilla particle.
 *
 * <p>Pure Java (no Minecraft types). The game fills a {@link Body} once per frame and draws the resulting {@link #mesh}
 * in the world; the menu preview and the offline tests drive the very same code.
 */
final class FxEngine {
    /** Everything the effects need to know about the player and the camera, refreshed every frame. */
    static final class Body {
        /** Feet of the player (interpolated). */
        double x, y, z;
        /** Body yaw and head yaw/pitch in degrees (Minecraft convention: yaw 0 looks along +Z). */
        float yaw, headYaw, headPitch;
        /** Velocity in blocks per second. */
        double vx, vy, vz;
        boolean onGround = true, sneaking, inWater, firstPerson, holdingSword, rightHanded = true;
        /** Hand swing progress, 0 while the arm is at rest. */
        float swing;
        /** Set for exactly one frame when a swing starts: 0 none, 1 in the air, 2 at a block, 3 at an entity. */
        int swingEvent;
        double camX, camY, camZ;
        float camYaw, camPitch;
        /** World time of day in ticks (0..24000), used by the sky. */
        float timeOfDay = 6000f;
        /** Radius of the sky dome in blocks, and how far the dome centre is lifted above the camera. */
        float radius = 200f, skyLift;
        /** False when the sky must not be drawn (other dimension, underwater). */
        boolean skyVisible = true;
        /** Menu preview: no fading near the camera. */
        boolean preview;
    }

    // ------------------------------------------------------------------ state

    private final BaroxConfig cfg;
    private final Random rnd = new Random();
    /** Output of the last {@link #frame}: camera relative geometry. */
    final Mesh mesh = new Mesh();
    private final FxShapes.Cam cam = new FxShapes.Cam();
    private final ArrayList<P> pool = new ArrayList<>();
    private final Map<String, float[]> acc = new HashMap<>();
    private Body cur = new Body();

    /** Animation clock in seconds. */
    float time;
    private float dt;
    private float gAmount = 1f, gSize = 1f, gOpacity = 1f;
    private boolean nearFade = true;
    private int maxItems = 700;

    // player tracking
    private float smoothYaw, speed;
    private boolean yawInit, wasOnGround = true, moving, jumped, landed;
    private float minVy, impact, stepDist;
    private int stepSide = 1;
    private float fwdX, fwdZ, rgtX, rgtZ;
    private float lastSwing;

    // orbit shapes (spring offsets per shape)
    private static final int MAX_ORBIT = 72;
    private final float[] orbOff = new float[MAX_ORBIT * 3], orbVel = new float[MAX_ORBIT * 3];
    private final float[] orbAng = new float[MAX_ORBIT], orbSpin = new float[MAX_ORBIT], orbSpinV = new float[MAX_ORBIT];

    // atmosphere (a fixed field of shapes that wraps around the player)
    private static final int MAX_ATM = 260;
    private final double[] atmX = new double[MAX_ATM], atmY = new double[MAX_ATM], atmZ = new double[MAX_ATM];
    private final float[] atmPhase = new float[MAX_ATM];
    private int atmCount;

    // ribbons: slash trail and rainbow trail keep a short history
    private final ArrayList<double[]> slash = new ArrayList<>();
    private final ArrayList<double[]> ribbon = new ArrayList<>();
    private double lastRibX, lastRibZ;
    private boolean haveRib;

    // lightning
    private final ArrayList<float[]> bolts = new ArrayList<>();
    private float boltClock;

    // ------------------------------------------------------------------ free shapes (what particles used to be)

    private static final int NORMAL = 0, GROUND_RING = 1;

    private static final class P {
        int kind, shape;
        double x, y, z;
        float vx, vy, vz, grav, drag;
        float size0 = 0.1f, size1 = 0.1f, rx, ry, rz, wx, wy, wz, age, life = 1f;
        int rgb0 = 0xFFFFFF, rgb1 = 0xFFFFFF;
        float alpha = 1f, fill = 0.8f, glow = 0.5f, seed, dist;
        boolean tumble, outline = true;
        /** 0 = quick fade in, slow fade out; 1 = twinkle (sine); 2 = hold, then fade at the end. */
        int env;
    }

    FxEngine(BaroxConfig cfg) {
        this.cfg = cfg;
    }

    /** Forgets every shape on screen (world change, effects switched off). */
    void clear() {
        pool.clear();
        slash.clear();
        ribbon.clear();
        bolts.clear();
        haveRib = false;
        java.util.Arrays.fill(orbOff, 0f);
        java.util.Arrays.fill(orbVel, 0f);
        java.util.Arrays.fill(orbSpin, 0f);
        java.util.Arrays.fill(orbSpinV, 0f);
        mesh.clear();
    }

    int shapeCount() { return pool.size(); }

    // ------------------------------------------------------------------ config shortcuts

    private float f(String m, String s) { return cfg.f(m, s); }

    private int ix(String m, String s) { return cfg.idx(m, s); }

    private boolean fl(String m, String s) { return cfg.flag(m, s); }

    private int col(String m, String s, float phase) { return cfg.rgb(m, s, time, phase); }

    /** Menu preview: when set, only this module is drawn (even when it is switched off); null draws every enabled module. */
    private String only, skip;

    void only(String moduleId, String skipId) {
        this.only = moduleId;
        this.skip = skipId;
    }

    private boolean on(String id) {
        if (skip != null && skip.equals(id)) return false;
        return only != null ? only.equals(id) : cfg.isOn(id);
    }

    private float rf() { return rnd.nextFloat(); }

    private float rr(float a, float b) { return a + (b - a) * rnd.nextFloat(); }

    private static float clamp(float v, float lo, float hi) { return v < lo ? lo : Math.min(v, hi); }

    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }

    private static float smooth(float t) {
        t = clamp(t, 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    private static float wrapDeg(float d) {
        d %= 360f;
        if (d > 180f) d -= 360f;
        if (d < -180f) d += 360f;
        return d;
    }

    /** How many shapes to spawn this frame for a rate in shapes per second (fractions carry over). */
    private int take(String key, float perSecond) {
        float[] a = acc.computeIfAbsent(key, k -> new float[1]);
        a[0] += Math.max(0f, perSecond) * dt;
        int n = (int) a[0];
        if (n > 0) a[0] -= n;
        return Math.min(n, 10);
    }

    // ------------------------------------------------------------------ frame

    /** Advances every effect by dtSeconds and rebuilds {@link #mesh} for the given player and camera. */
    void frame(float dtSeconds, Body b) {
        cur = b;
        dt = clamp(dtSeconds, 0f, 0.05f);
        time += dt;
        cam.set(b.camYaw, b.camPitch);
        mesh.clear();
        gAmount = (float) cfg.amountScale();
        gSize = f("fx", "size");
        gOpacity = f("fx", "opacity") / 100f;
        nearFade = fl("fx", "near_fade") && !b.preview;
        maxItems = Math.max(50, (int) cfg.num("fx", "max"));
        track(b);
        boolean hide = b.firstPerson && !fl("fx", "first_person");
        if (hide) {
            pool.clear();
            return;
        }
        spawnAll(b);
        integrate();
        drawAll(b);
    }

    private void track(Body b) {
        if (!yawInit) {
            smoothYaw = b.yaw;
            yawInit = true;
        }
        smoothYaw += wrapDeg(b.yaw - smoothYaw) * Math.min(1f, dt * 18f);
        double yr = Math.toRadians(smoothYaw);
        fwdX = (float) -Math.sin(yr);
        fwdZ = (float) Math.cos(yr);
        rgtX = (float) -Math.cos(yr);
        rgtZ = (float) -Math.sin(yr);
        float hs = (float) Math.sqrt(b.vx * b.vx + b.vz * b.vz);
        speed += (hs - speed) * Math.min(1f, dt * 8f);
        moving = speed > 0.6f;
        jumped = false;
        landed = false;
        impact = 0f;
        if (wasOnGround && !b.onGround && b.vy > 2.0) jumped = true;
        if (!b.onGround) minVy = Math.min(minVy, (float) b.vy);
        if (!wasOnGround && b.onGround && minVy < -5f) {
            landed = true;
            impact = -minVy;
        }
        if (b.onGround) minVy = 0f;
        wasOnGround = b.onGround;
        lastSwing = b.swing;
    }

    // ------------------------------------------------------------------ geometry helpers

    /** Distance based fade so shapes never fill the screen when the camera is inside them. */
    private float camFade(double wx, double wy, double wz) {
        if (!nearFade) return 1f;
        double dx = wx - cur.camX, dy = wy - cur.camY, dz = wz - cur.camZ;
        float d = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        return clamp((d - 0.4f) / 0.9f, 0f, 1f);
    }

    private void shape(int shape, double wx, double wy, double wz, float s, float rx, float ry, float rz, boolean tumble,
                       int rgb0, int rgb1, float alpha, float fill, boolean outline, float glow, float seed) {
        float a = alpha * camFade(wx, wy, wz) * gOpacity;
        if (a <= 0.01f) return;
        FxShapes.draw(mesh, cam, shape, (float) (wx - cur.camX), (float) (wy - cur.camY), (float) (wz - cur.camZ),
            s * gSize, rx, ry, rz, tumble, rgb0, rgb1, a, fill, outline, glow, seed);
    }

    /** A vertical band that always turns its face to the camera (light pillars, rain, digital rain). */
    private void vband(double wx, double wy, double wz, float len, float width, int rgbBottom, int rgbTop, float aBottom, float aTop,
                       int layer) {
        float a = camFade(wx, wy, wz) * gOpacity;
        if (a <= 0.01f) return;
        float rx = (float) (wx - cur.camX), ry = (float) (wy - cur.camY), rz = (float) (wz - cur.camZ);
        float d = (float) Math.sqrt(rx * rx + rz * rz);
        float sx = d > 1e-4f ? -rz / d : 1f, sz = d > 1e-4f ? rx / d : 0f;
        float hw = width * 0.5f * gSize;
        int bot = FxShapes.argb(rgbBottom, aBottom * a), top = FxShapes.argb(rgbTop, aTop * a);
        mesh.quad(layer, rx - sx * hw, ry, rz - sz * hw, rx + sx * hw, ry, rz + sz * hw,
            rx + sx * hw, ry + len, rz + sz * hw, rx - sx * hw, ry + len, rz - sz * hw, bot, bot, top, top);
    }

    /** Flat band between two world points that turns towards the camera (slash ribbons, lightning, tails). */
    private void ribbonQuad(double ax, double ay, double az, double bx, double by, double bz, float widthA, float widthB,
                            int cA, int cB, int layer) {
        float pax = (float) (ax - cur.camX), pay = (float) (ay - cur.camY), paz = (float) (az - cur.camZ);
        float pbx = (float) (bx - cur.camX), pby = (float) (by - cur.camY), pbz = (float) (bz - cur.camZ);
        float dx = pbx - pax, dy = pby - pay, dz = pbz - paz;
        // side = direction x view
        float sx = dy * paz - dz * pay, sy = dz * pax - dx * paz, sz = dx * pay - dy * pax;
        float len = (float) Math.sqrt(sx * sx + sy * sy + sz * sz);
        if (len < 1e-6f) return;
        sx /= len;
        sy /= len;
        sz /= len;
        float wa = widthA * 0.5f, wb = widthB * 0.5f;
        mesh.quad(layer, pax - sx * wa, pay - sy * wa, paz - sz * wa, pax + sx * wa, pay + sy * wa, paz + sz * wa,
            pbx + sx * wb, pby + sy * wb, pbz + sz * wb, pbx - sx * wb, pby - sy * wb, pbz - sz * wb, cA, cA, cB, cB);
    }

    private void groundRing(double wx, double wy, double wz, float inner, float outer, int seg, int cA, int cB, float rot, float arc) {
        mesh.push();
        mesh.translate((float) (wx - cur.camX), (float) (wy - cur.camY), (float) (wz - cur.camZ));
        mesh.rotX((float) (Math.PI / 2));
        FxShapes.annulusArc(mesh, Mesh.GLOW, inner, outer, seg, rot, arc, cA, cB);
        mesh.pop();
    }

    // ------------------------------------------------------------------ player anchored points

    private final double[] tmpP = new double[3];

    /** Position of a hand (side +1 = the player's right hand, -1 = left). Result in tmpP. */
    private void handPos(Body b, int side) {
        float sw = (float) Math.sin(Math.min(1f, b.swing) * Math.PI);
        int swinging = (side > 0) == b.rightHanded ? 1 : 0;
        if (b.firstPerson) {
            double r = side * 0.42, u = -0.34 + 0.22 * sw * swinging, f = 0.62 + 0.3 * sw * swinging;
            tmpP[0] = b.camX + cam.rx * r + cam.ux * u + cam.fx * f;
            tmpP[1] = b.camY + cam.ry * r + cam.uy * u + cam.fy * f;
            tmpP[2] = b.camZ + cam.rz * r + cam.uz * u + cam.fz * f;
        } else {
            double shoulder = b.sneaking ? 1.1 : 1.38;
            tmpP[0] = b.x + rgtX * side * 0.38 + fwdX * (0.1 + 0.6 * sw * swinging);
            tmpP[1] = b.y + shoulder - 0.52 + 0.32 * sw * swinging;
            tmpP[2] = b.z + rgtZ * side * 0.38 + fwdZ * (0.1 + 0.6 * sw * swinging);
        }
    }

    /** Position of a wing tip, derived from the size of the wing cosmetic. Result in tmpP. */
    private void wingTip(Body b, int side) {
        float size = f("wings", "size"), spread = f("wings", "spread") / 100f;
        float out = 0.3f + 1.05f * size * (0.55f + 0.45f * spread);
        float back = 0.3f + f("wings", "back");
        tmpP[0] = b.x - fwdX * back + rgtX * side * out;
        tmpP[1] = b.y + (b.sneaking ? 1.3 : 1.55) + f("wings", "height") + 0.35 * size;
        tmpP[2] = b.z - fwdZ * back + rgtZ * side * out;
    }

    /** A random point near the player: where 0 = whole body, 1 = head, 2 = hands, 3 = feet, 4 = wings, 5 = above the head. */
    private void bodyPoint(Body b, int where, float spread) {
        float sneak = b.sneaking ? 0.82f : 1f;
        double a = rf() * Math.PI * 2;
        float r;
        switch (where) {
            case 1 -> {
                r = rr(0.25f, 0.6f) * spread;
                tmpP[0] = b.x + Math.cos(a) * r;
                tmpP[1] = b.y + 1.75 * sneak + rr(-0.2f, 0.35f);
                tmpP[2] = b.z + Math.sin(a) * r;
            }
            case 2 -> {
                handPos(b, rf() < 0.5f ? 1 : -1);
                tmpP[0] += rr(-0.12f, 0.12f) * spread;
                tmpP[1] += rr(-0.12f, 0.12f) * spread;
                tmpP[2] += rr(-0.12f, 0.12f) * spread;
            }
            case 3 -> {
                r = rr(0.1f, 0.7f) * spread;
                tmpP[0] = b.x + Math.cos(a) * r;
                tmpP[1] = b.y + rr(0f, 0.3f);
                tmpP[2] = b.z + Math.sin(a) * r;
            }
            case 4 -> {
                wingTip(b, rf() < 0.5f ? 1 : -1);
                float k = rr(0.25f, 1f);
                tmpP[0] = b.x + (tmpP[0] - b.x) * k;
                tmpP[2] = b.z + (tmpP[2] - b.z) * k;
                tmpP[1] = b.y + 1.3 * sneak + (tmpP[1] - b.y - 1.3 * sneak) * k + rr(-0.35f, 0.15f);
            }
            case 5 -> {
                r = rr(0.1f, 0.9f) * spread;
                tmpP[0] = b.x + Math.cos(a) * r;
                tmpP[1] = b.y + 2.2 * sneak + rr(0f, 0.5f);
                tmpP[2] = b.z + Math.sin(a) * r;
            }
            default -> {
                r = rr(0.4f, 0.8f) * spread;
                tmpP[0] = b.x + Math.cos(a) * r;
                tmpP[1] = b.y + rr(0.1f, 1.95f) * sneak;
                tmpP[2] = b.z + Math.sin(a) * r;
            }
        }
    }

    // ------------------------------------------------------------------ the pool

    private P spawn(int shape, double x, double y, double z, float life, float size0, float size1, int rgb0, int rgb1) {
        if (pool.size() >= maxItems) return null;
        P p = new P();
        p.shape = shape;
        p.x = x;
        p.y = y;
        p.z = z;
        p.life = Math.max(0.05f, life);
        p.size0 = size0;
        p.size1 = size1;
        p.rgb0 = rgb0;
        p.rgb1 = rgb1;
        p.seed = rf();
        pool.add(p);
        return p;
    }

    private void integrate() {
        for (int i = pool.size() - 1; i >= 0; i--) {
            P p = pool.get(i);
            p.age += dt;
            if (p.age >= p.life) {
                int last = pool.size() - 1;
                pool.set(i, pool.get(last));
                pool.remove(last);
                continue;
            }
            p.vy += p.grav * dt;
            float damp = (float) Math.exp(-p.drag * dt);
            p.vx *= damp;
            p.vy *= damp;
            p.vz *= damp;
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.z += p.vz * dt;
            p.rx += p.wx * dt;
            p.ry += p.wy * dt;
            p.rz += p.wz * dt;
        }
    }

    private void drawPool() {
        for (P p : pool) {
            double dx = p.x - cur.camX, dy = p.y - cur.camY, dz = p.z - cur.camZ;
            p.dist = (float) (dx * dx + dy * dy + dz * dz);
        }
        Collections.sort(pool, (a, c) -> Float.compare(c.dist, a.dist));
        for (P p : pool) {
            float t = p.age / p.life;
            float env;
            switch (p.env) {
                case 1 -> env = (float) Math.pow(Math.sin(Math.PI * t), 0.8);
                case 2 -> env = smooth(t / 0.08f) * (1f - smooth((t - 0.6f) / 0.4f));
                default -> env = smooth(t / 0.12f) * (1f - smooth((t - 0.45f) / 0.55f));
            }
            float size = lerp(p.size0, p.size1, t);
            int c0 = FxShapes.mix(p.rgb0, p.rgb1, t * 0.9f), c1 = FxShapes.mix(p.rgb1, p.rgb0, 0.35f);
            if (p.kind == GROUND_RING) {
                float a = p.alpha * env * gOpacity * camFade(p.x, p.y, p.z);
                if (a > 0.01f) {
                    float thick = Math.max(0.02f, size * 0.12f);
                    groundRing(p.x, p.y, p.z, Math.max(0f, size - thick), size, 28, FxShapes.argb(c0, 0f), FxShapes.argb(c0, a), 0f, (float) (Math.PI * 2));
                    groundRing(p.x, p.y, p.z, Math.max(0f, size - thick * 2.4f), Math.max(0.001f, size - thick), 28, FxShapes.argb(c1, 0f), FxShapes.argb(c0, a * 0.5f), 0f, (float) (Math.PI * 2));
                }
            } else {
                shape(p.shape, p.x, p.y, p.z, size, p.rx, p.ry, p.rz, p.tumble, c0, c1, p.alpha * env, p.fill, p.outline, p.glow, p.seed);
            }
        }
    }

    // ------------------------------------------------------------------ spawning (modules that emit free shapes)

    private void spawnAll(Body b) {
        if (on("glints")) glints(b);
        if (on("soul_flames")) flames(b);
        if (on("enchant_glyphs")) glyphs(b);
        if (on("rain_cloud")) rain(b);
        if (on("shoulder_wisp")) wispTails(b);
        if (on("hand_glow")) handSparks(b);
        if (on("footsteps")) footsteps(b);
        if (on("jump_crystal") && jumped) burst(b, "jump_crystal", 1f);
        if (on("landing_burst") && landed) burst(b, "landing_burst", clamp(impact / 12f, 0.4f, 1.6f));
        for (String id : SHED_IDS) if (on(id)) shedTrail(b, id);
        if (on("wings") && fl("wings", "sparkles")) cosmeticSparkles(b, true);
        if (on("crown") && fl("crown", "sparkles")) cosmeticSparkles(b, false);
        if (on("jetpack") && fl("jetpack", "flames")) jetFlames(b);
    }

    /** Sparkles of the wing and crown cosmetics (their "sparkles" switch), drawn as our own star shapes. */
    private void cosmeticSparkles(Body b, boolean wings) {
        int n = take(wings ? "wing_sparkle" : "crown_sparkle", (wings ? 9f : 5f) * gAmount);
        for (int i = 0; i < n; i++) {
            if (wings) {
                bodyPoint(b, 4, 1f);
            } else {
                double a = rf() * Math.PI * 2;
                tmpP[0] = b.x + Math.cos(a) * 0.28;
                tmpP[1] = b.y + (b.sneaking ? 1.85 : 2.05) + rr(0f, 0.25f);
                tmpP[2] = b.z + Math.sin(a) * 0.28;
            }
            int c0 = wings ? col("wings", "accent", rf()) : col("crown", "gem", rf());
            int c1 = wings ? col("wings", "color2", rf()) : col("crown", "color", rf());
            P p = spawn(FxShapes.STAR, tmpP[0], tmpP[1], tmpP[2], rr(0.5f, 0.9f), 0.05f, 0.05f, c0, c1);
            if (p == null) return;
            p.vy = rr(0f, 0.25f);
            p.rz = rr(0f, 6.28f);
            p.wz = rr(-2f, 2f);
            p.env = 1;
            p.fill = 1f;
            p.glow = 0.8f;
        }
    }

    /** Thruster flames of the jetpack cosmetic: flame shapes shooting downwards from the nozzles. */
    private void jetFlames(Body b) {
        if (b.onGround && !moving) return;
        boolean twin = ix("jetpack", "design") != 1;
        int n = take("jet_flames", 30f * gAmount);
        double y = b.y + (b.sneaking ? 0.5 : 0.58);
        for (int i = 0; i < n; i++) {
            double side = twin ? (rf() < 0.5f ? -0.1 : 0.1) : 0.0;
            P p = spawn(FxShapes.FLAME, b.x - fwdX * 0.32 + rgtX * side, y, b.z - fwdZ * 0.32 + rgtZ * side, rr(0.2f, 0.35f), 0.07f, 0.02f,
                col("jetpack", "accent", rf()), 0xFF8A1F);
            if (p == null) return;
            p.vy = -rr(1.4f, 2.4f);
            p.vx = rr(-0.15f, 0.15f);
            p.vz = rr(-0.15f, 0.15f);
            p.rx = (float) Math.PI;
            p.ry = rr(0f, 6.28f);
            p.glow = 0.7f;
        }
    }

    private void glints(Body b) {
        final String M = "glints";
        float rate = 16f * f(M, "amount") / 100f * gAmount;
        int n = take(M, rate);
        float size = f(M, "size"), drift = f(M, "drift") / 100f, speedK = Math.max(0.3f, f(M, "speed"));
        for (int i = 0; i < n; i++) {
            bodyPoint(b, ix(M, "where"), f(M, "spread"));
            P p = spawn(ix(M, "shape"), tmpP[0], tmpP[1], tmpP[2], rr(0.5f, 1f) / speedK, 0.075f * size * rr(0.6f, 1.25f), 0f,
                col(M, "color", rf()), col(M, "color2", rf()));
            if (p == null) return;
            p.size1 = p.size0;
            p.vx = rr(-0.15f, 0.15f) * drift;
            p.vy = rr(0f, 0.4f) * drift;
            p.vz = rr(-0.15f, 0.15f) * drift;
            p.rz = rr(0f, 6.28f);
            p.wz = rr(-1.5f, 1.5f);
            p.env = 1;
            p.fill = 1f;
            p.glow = f(M, "glow") / 100f;
            p.tumble = false;
        }
    }

    private void flames(Body b) {
        final String M = "soul_flames";
        int n = take(M, 20f * f(M, "amount") / 100f * gAmount);
        float size = f(M, "size"), h = f(M, "height");
        for (int i = 0; i < n; i++) {
            bodyPoint(b, ix(M, "where") == 0 ? 3 : 0, f(M, "spread"));
            float s = 0.15f * size * rr(0.7f, 1.25f);
            P p = spawn(FxShapes.FLAME, tmpP[0], tmpP[1], tmpP[2], rr(0.5f, 0.9f) * (0.6f + 0.4f * h), s, s * 0.25f,
                col(M, "color", rf()), col(M, "color2", rf()));
            if (p == null) return;
            p.vy = rr(0.7f, 1.4f) * h;
            p.vx = rr(-0.1f, 0.1f);
            p.vz = rr(-0.1f, 0.1f);
            p.ry = rr(0f, 6.28f);
            p.wy = rr(-1f, 1f);
            p.glow = f(M, "glow") / 100f;
            p.env = 0;
        }
    }

    private void glyphs(Body b) {
        final String M = "enchant_glyphs";
        int n = take(M, 7f * f(M, "amount") / 100f * gAmount);
        float size = f(M, "size");
        for (int i = 0; i < n; i++) {
            double a = rf() * Math.PI * 2;
            float r = rr(1.1f, 1.7f);
            double sx = b.x + Math.cos(a) * r, sz = b.z + Math.sin(a) * r, sy = b.y + rr(0.9f, 2.4f);
            P p = spawn(FxShapes.GLYPH, sx, sy, sz, rr(1.0f, 1.7f) / Math.max(0.3f, f(M, "speed")), 0.15f * size, 0.1f * size,
                col(M, "color", rf()), col(M, "color2", rf()));
            if (p == null) return;
            // glyphs fly towards the player like the letters of an enchanting table, then fade out
            float tx = (float) (b.x - sx), ty = (float) (b.y + 1.1 - sy), tz = (float) (b.z - sz);
            p.vx = tx * 0.55f;
            p.vy = ty * 0.55f + rr(0.1f, 0.4f);
            p.vz = tz * 0.55f;
            p.drag = 0.2f;
            p.glow = f(M, "glow") / 100f;
            p.tumble = false;
            p.fill = 0.9f;
            p.env = 1;
        }
    }

    private void rain(Body b) {
        final String M = "rain_cloud";
        double cy = b.y + 2.35 + f(M, "height");
        int n = take(M, 34f * gAmount);
        for (int i = 0; i < n; i++) {
            double a = rf() * Math.PI * 2;
            float r = rr(0f, 0.55f);
            P p = spawn(FxShapes.SQUARE, b.x + Math.cos(a) * r, cy - 0.1, b.z + Math.sin(a) * r, rr(0.45f, 0.7f), 0.012f, 0.012f,
                col(M, "color", rf()), col(M, "color2", rf()));
            if (p == null) return;
            p.vy = -rr(5f, 7f);
            p.grav = -6f;
            p.kind = NORMAL;
            p.fill = 1f;
            p.outline = false;
            p.glow = 0f;
            p.env = 2;
            p.tumble = false;
            p.alpha = 0.75f;
        }
    }

    private void wispTails(Body b) {
        final String M = "shoulder_wisp";
        int n = take(M, 36f * f(M, "tail") / 100f);
        for (int side : wispSides(M)) {
            for (int i = 0; i < n; i++) {
                wispPos(b, M, side);
                float s = 0.05f * f(M, "size");
                P p = spawn(FxShapes.DOT, tmpP[0], tmpP[1], tmpP[2], rr(0.35f, 0.6f), s, s * 0.2f, col(M, "color", rf()), col(M, "color2", rf()));
                if (p == null) return;
                p.glow = 1f;
                p.vy = rr(-0.1f, 0.15f);
                p.env = 0;
            }
        }
    }

    private int[] wispSides(String m) {
        int c = ix(m, "side");
        return c == 0 ? new int[] {1} : c == 1 ? new int[] {-1} : new int[] {1, -1};
    }

    private void wispPos(Body b, String m, int side) {
        float sp = f(m, "speed");
        float t = time * sp + side * 1.7f;
        float wander = f(m, "wander");
        double base = b.sneaking ? 1.35 : 1.62;
        tmpP[0] = b.x + rgtX * side * 0.55 - fwdX * 0.1 + Math.sin(t * 1.3) * 0.2 * wander;
        tmpP[1] = b.y + base + 0.18 + Math.sin(t * 1.9 + 1f) * 0.14 * wander;
        tmpP[2] = b.z + rgtZ * side * 0.55 - fwdZ * 0.1 + Math.cos(t * 1.1) * 0.2 * wander;
    }

    private void handSparks(Body b) {
        final String M = "hand_glow";
        int sparks = (int) f(M, "sparks");
        if (sparks <= 0) return;
        int n = take(M, sparks * 3f * gAmount);
        for (int i = 0; i < n; i++) {
            handPos(b, handSide(M, i));
            float s = 0.045f * f(M, "size");
            P p = spawn(FxShapes.STAR, tmpP[0], tmpP[1], tmpP[2], rr(0.35f, 0.7f), s, s * 0.3f, col(M, "color", rf()), col(M, "color2", rf()));
            if (p == null) return;
            p.vx = rr(-0.3f, 0.3f);
            p.vy = rr(0.1f, 0.5f);
            p.vz = rr(-0.3f, 0.3f);
            p.rz = rr(0f, 6.28f);
            p.wz = rr(-3f, 3f);
            p.env = 1;
            p.fill = 1f;
            p.glow = 0.8f;
        }
    }

    private int handSide(String m, int i) {
        int c = ix(m, "hand");
        if (c == 0) return cur.rightHanded ? 1 : -1;   // main hand
        if (c == 1) return 1;
        if (c == 2) return -1;
        return (i & 1) == 0 ? 1 : -1;
    }

    // ---- trails

    /** Trail modules that simply shed shapes (the shape, colours, size, life and rise of each are options). */
    private static final String[] SHED_IDS = {"sparkle_trail", "heart_trail", "bubble_trail", "note_trail", "flame_trail",
        "cherry_trail", "wing_trail"};

    private static float shedRate(String id) {
        return switch (id) {
            case "sparkle_trail" -> 22f;
            case "heart_trail" -> 5f;
            case "bubble_trail" -> 8f;
            case "note_trail" -> 4f;
            case "flame_trail" -> 16f;
            case "cherry_trail" -> 9f;
            default -> 20f;
        };
    }

    private static int shedWhere(String id) {
        return switch (id) {
            case "note_trail" -> 1;
            case "flame_trail" -> 3;
            case "cherry_trail" -> 5;
            case "wing_trail" -> 4;
            default -> 0;
        };
    }

    private boolean whenOk(String id, Body b) {
        int w = ix(id, "when");
        if (w == 0) return moving;
        if (w == 2) return !b.onGround;
        return true;
    }

    private void shedTrail(Body b, String id) {
        if (!whenOk(id, b)) return;
        int n = take(id, shedRate(id) * f(id, "amount") / 100f * gAmount);
        float size = f(id, "size"), rise = f(id, "rise"), spread = f(id, "spread"), life = f(id, "life");
        int where = shedWhere(id);
        for (int i = 0; i < n; i++) {
            bodyPoint(b, where, spread);
            float s = 0.085f * size * rr(0.75f, 1.2f);
            P p = spawn(ix(id, "shape"), tmpP[0], tmpP[1], tmpP[2], life * rr(0.8f, 1.2f), s, s * 0.35f, col(id, "color", rf()), col(id, "color2", rf()));
            if (p == null) return;
            p.vx = rr(-0.25f, 0.25f) * spread;
            p.vz = rr(-0.25f, 0.25f) * spread;
            p.vy = rise * 0.9f + rr(-0.1f, 0.2f);
            p.drag = 0.9f;
            p.rz = rr(0f, 6.28f);
            p.wz = rr(-2f, 2f) * f(id, "spin");
            p.wy = rr(-2f, 2f) * f(id, "spin");
            p.wx = rr(-2f, 2f) * f(id, "spin");
            p.tumble = id.equals("cherry_trail");
            p.glow = f(id, "glow") / 100f;
            p.env = shapeIsSparkle(id) ? 1 : 0;
            if (id.equals("cherry_trail")) {
                p.vx += rgtX * rr(-0.2f, 0.2f);
                p.drag = 0.4f;
            }
        }
    }

    private static boolean shapeIsSparkle(String id) { return id.equals("sparkle_trail") || id.equals("wing_trail"); }

    private void footsteps(Body b) {
        final String M = "footsteps";
        if (!b.onGround || b.inWater) {
            stepDist = 0f;
            return;
        }
        stepDist += speed * dt;
        float spacing = Math.max(0.3f, f(M, "spacing"));
        if (stepDist < spacing || !moving) return;
        stepDist = 0f;
        stepSide = -stepSide;
        double heading = Math.atan2(b.vx, b.vz);
        double px = b.x + rgtX * stepSide * 0.17, pz = b.z + rgtZ * stepSide * 0.17;
        float s = 0.1f * f(M, "size");
        P p = spawn(ix(M, "shape"), px, b.y + 0.03, pz, f(M, "life"), s, s, col(M, "color", rf()), col(M, "color2", rf()));
        if (p == null) return;
        p.tumble = true;
        p.rx = (float) (Math.PI / 2);
        p.ry = (float) -heading;
        p.rz = 0f;
        p.glow = f(M, "glow") / 100f;
        p.env = 2;
        p.fill = 0.6f;
    }

    /** Jump and landing effect: an expanding ring on the ground plus shapes flying out. */
    private void burst(Body b, String id, float power) {
        int count = Math.round(f(id, "count") * Math.min(1.5f, power) * Math.min(1.5f, gAmount));
        float size = f(id, "size");
        int c0 = col(id, "color", 0f), c1 = col(id, "color2", 0.3f);
        if (fl(id, "ring")) {
            P r = spawn(FxShapes.RING, b.x, b.y + 0.04, b.z, 0.7f, 0.2f, f(id, "radius") * (0.7f + 0.5f * power), c0, c1);
            if (r != null) {
                r.kind = GROUND_RING;
                r.env = 0;
                r.alpha = 0.95f;
            }
            P r2 = spawn(FxShapes.RING, b.x, b.y + 0.05, b.z, 0.9f, 0.1f, f(id, "radius") * (0.5f + 0.35f * power), c1, c0);
            if (r2 != null) {
                r2.kind = GROUND_RING;
                r2.env = 0;
                r2.alpha = 0.7f;
            }
        }
        for (int i = 0; i < count; i++) {
            double a = (i + rf() * 0.6) * Math.PI * 2 / Math.max(1, count);
            float out = rr(1.2f, 2.8f) * power;
            float s = 0.09f * size * rr(0.8f, 1.2f);
            P p = spawn(ix(id, "shape"), b.x + Math.cos(a) * 0.25, b.y + 0.1, b.z + Math.sin(a) * 0.25, f(id, "life") * rr(0.8f, 1.2f), s, s * 0.3f, c0, c1);
            if (p == null) return;
            p.vx = (float) Math.cos(a) * out;
            p.vz = (float) Math.sin(a) * out;
            p.vy = rr(1.5f, 4f) * (id.equals("jump_crystal") ? 0.6f : 1f);
            p.grav = -9f;
            p.drag = 1.2f;
            p.rx = rf() * 6.28f;
            p.ry = rf() * 6.28f;
            p.wx = rr(-6f, 6f);
            p.wy = rr(-6f, 6f);
            p.wz = rr(-6f, 6f);
            p.tumble = true;
            p.glow = f(id, "glow") / 100f;
            p.env = 0;
        }
    }

    // ------------------------------------------------------------------ drawing of everything

    private void drawAll(Body b) {
        if (on("sky_aura") && b.skyVisible) FxSky.build(mesh, cfg, b, time, gOpacity);
        if (on("beam")) beam(b);
        if (on("aura")) aura(b);
        if (on("ender_swirl")) helix(b);
        if (on("rainbow_trail")) rainbowTrail(b);
        if (on("sword_trail")) slashTrail(b);
        if (on("atmosphere")) atmosphere(b);
        drawPool();
        if (on("lightning_aura")) lightning(b);
        if (on("rain_cloud")) cloud(b);
        if (on("shoulder_wisp")) wisps(b);
        if (on("hand_glow")) hands(b);
        orbit(b);
    }

    // ---- orbit shapes (the squares that bounce back when you hit the air)

    private void orbit(Body b) {
        final String M = "orbit_shapes";
        if (!on(M)) {
            java.util.Arrays.fill(orbOff, 0f);
            java.util.Arrays.fill(orbVel, 0f);
            return;
        }
        int count = Math.max(1, Math.min(24, (int) f(M, "count")));
        int rings = Math.max(1, Math.min(3, (int) f(M, "rings")));
        int total = count * rings;
        int trigger = ix(M, "trigger");
        boolean fire = switch (trigger) {
            case 0 -> b.swingEvent == 1;
            case 1 -> b.swingEvent >= 1;
            case 2 -> b.swingEvent == 3;
            case 3 -> jumped;
            default -> false;
        };
        int reaction = ix(M, "reaction");
        float bounce = f(M, "bounce") / 100f;
        if (fire) kick(b, total, 4.2f * bounce, reaction);

        // spring: the shapes are pushed away and come back, overshooting a little
        float omega = 9.5f * f(M, "return");
        float zeta = clamp(0.9f - 0.75f * f(M, "elastic") / 100f, 0.08f, 1f);
        int steps = Math.max(1, (int) Math.ceil(dt / 0.012f));
        float h = dt / steps;
        for (int s = 0; s < steps; s++) {
            for (int i = 0; i < total; i++) {
                for (int k = 0; k < 3; k++) {
                    int j = i * 3 + k;
                    float acc = -omega * omega * orbOff[j] - 2f * zeta * omega * orbVel[j];
                    orbVel[j] += acc * h;
                    orbOff[j] += orbVel[j] * h;
                }
                orbSpin[i] += orbSpinV[i] * h;
                orbSpinV[i] *= (float) Math.exp(-2.2f * h);
            }
        }

        int shapeId = ix(M, "shape");
        float radius = f(M, "radius"), height = f(M, "height"), size = 0.11f * f(M, "size"), spd = f(M, "speed");
        float spin = f(M, "spin"), wave = f(M, "wave") / 100f, fill = f(M, "fill") / 100f, glow = f(M, "glow") / 100f;
        boolean tumble = fl(M, "tumble"), outline = fl(M, "outline"), path = fl(M, "path");
        for (int ring = 0; ring < rings; ring++) {
            float dir = (ring & 1) == 0 ? 1f : -1f;
            float rad = radius * (1f + 0.22f * ring);
            double cy = b.y + height + (ring - (rings - 1) * 0.5f) * 0.3f;
            if (path) {
                mesh.push();
                mesh.translate((float) (b.x - cur.camX), (float) (cy - cur.camY), (float) (b.z - cur.camZ));
                mesh.rotX((float) (Math.PI / 2));
                float a = 0.22f * gOpacity;
                FxShapes.annulus(mesh, Mesh.GLOW, rad - 0.006f, rad + 0.006f, 48, FxShapes.argb(col(M, "color", 0f), a), FxShapes.argb(col(M, "color2", 0f), a));
                mesh.pop();
            }
            for (int k = 0; k < count; k++) {
                int i = ring * count + k;
                double ang = dir * time * spd * 0.9 + k * Math.PI * 2 / count + ring * 0.6;
                orbAng[i] = (float) ang;
                float y = (float) (Math.sin(time * 1.7 + k * 1.3 + ring) * wave * 0.2);
                double wx = b.x + Math.cos(ang) * rad + orbOff[i * 3];
                double wy = cy + y + orbOff[i * 3 + 1];
                double wz = b.z + Math.sin(ang) * rad + orbOff[i * 3 + 2];
                float t = count > 1 ? k / (float) (count - 1) : 0f;
                int c0 = FxShapes.mix(col(M, "color", k * 0.07f), col(M, "color2", k * 0.07f), t);
                int c1 = FxShapes.mix(col(M, "color2", k * 0.07f), col(M, "color", k * 0.07f), t);
                float sp = (time * 0.9f * spin + k * 0.7f) * (ring % 2 == 0 ? 1f : -1f) + orbSpin[i];
                shape(shapeId, wx, wy, wz, size, sp * 0.7f + k, sp * 1.1f + ring, sp * 0.5f, tumble, c0, c1, 0.95f, fill, outline, glow, k * 0.37f + ring);
            }
        }
    }

    /** The reaction of the orbit shapes to a swing: they get an impulse and the spring brings them back. */
    private void kick(Body b, int total, float strength, int reaction) {
        double hy = Math.toRadians(b.headYaw), hp = Math.toRadians(b.headPitch);
        float lx = (float) (-Math.sin(hy) * Math.cos(hp)), ly = (float) -Math.sin(hp), lz = (float) (Math.cos(hy) * Math.cos(hp));
        for (int i = 0; i < total; i++) {
            float dx = (float) Math.cos(orbAng[i]), dz = (float) Math.sin(orbAng[i]);
            float k = strength * rr(0.8f, 1.2f);
            switch (reaction) {
                case 0 -> {
                    orbVel[i * 3] += dx * k;
                    orbVel[i * 3 + 2] += dz * k;
                    orbVel[i * 3 + 1] += rr(-0.15f, 0.15f) * k;
                }
                case 1 -> {
                    orbVel[i * 3] -= dx * k;
                    orbVel[i * 3 + 2] -= dz * k;
                }
                case 2 -> {
                    orbVel[i * 3] += lx * k;
                    orbVel[i * 3 + 1] += ly * k * 0.6f;
                    orbVel[i * 3 + 2] += lz * k;
                }
                default -> {
                    orbVel[i * 3] += rr(-1f, 1f) * k;
                    orbVel[i * 3 + 1] += rr(-1f, 1f) * k * 0.6f;
                    orbVel[i * 3 + 2] += rr(-1f, 1f) * k;
                }
            }
            orbSpinV[i] += (rf() < 0.5f ? 1f : -1f) * strength * rr(0.8f, 1.6f);
        }
    }

    // ---- aura ring on the ground

    private void aura(Body b) {
        final String M = "aura";
        float radius = f(M, "radius"), spd = f(M, "speed"), thick = 0.05f * f(M, "size");
        int c0 = col(M, "color", 0f), c1 = col(M, "color2", 0f);
        float a = 0.9f * gOpacity * camFade(b.x, b.y, b.z);
        if (a <= 0.01f) return;
        double gy = b.y + 0.03;
        int style = ix(M, "style");
        float rot = time * spd * 0.8f;
        float pulse = 1f + 0.04f * (float) Math.sin(time * 2.4f);
        if (style == 0 || style == 1) {
            groundRing(b.x, gy, b.z, radius * pulse - thick, radius * pulse, 48, FxShapes.argb(c0, a), FxShapes.argb(c1, a * 0.1f), 0f, (float) (Math.PI * 2));
            groundRing(b.x, gy, b.z, radius * pulse, radius * pulse + thick * 0.8f, 48, FxShapes.argb(c1, a * 0.1f), FxShapes.argb(c0, a * 0.9f), 0f, (float) (Math.PI * 2));
            if (style == 1) {
                groundRing(b.x, gy + 0.005, b.z, radius * 0.7f - thick, radius * 0.7f, 40, FxShapes.argb(c1, a), FxShapes.argb(c0, a * 0.2f), -rot, (float) (Math.PI * 2));
            }
        } else if (style == 2) {
            int dashes = 10;
            for (int i = 0; i < dashes; i++) {
                float start = rot + i * (float) (Math.PI * 2) / dashes;
                groundRing(b.x, gy, b.z, radius - thick * 1.4f, radius, 6, FxShapes.argb(c0, a), FxShapes.argb(c1, a * 0.6f), start, (float) (Math.PI * 2) / dashes * 0.6f);
            }
        } else {
            groundRing(b.x, gy, b.z, radius - thick * 0.6f, radius, 48, FxShapes.argb(c0, a), FxShapes.argb(c1, a * 0.5f), 0f, (float) (Math.PI * 2));
            int runes = 8;
            for (int i = 0; i < runes; i++) {
                double ang = rot * 0.6 + i * Math.PI * 2 / runes;
                shape(FxShapes.GLYPH, b.x + Math.cos(ang) * radius * 1.25, gy + 0.01, b.z + Math.sin(ang) * radius * 1.25, 0.09f * f(M, "size"),
                    (float) (Math.PI / 2), (float) -ang, 0f, true, c0, c1, 0.9f, 0.7f, true, 0.4f, i * 0.31f);
            }
        }
        // expanding pulse
        float ph = (time * spd * 0.45f) % 1f;
        groundRing(b.x, gy, b.z, radius * (1f + ph * 0.9f) - thick * 0.6f, radius * (1f + ph * 0.9f), 48, FxShapes.argb(c0, 0f), FxShapes.argb(c0, a * 0.55f * (1f - ph)), 0f, (float) (Math.PI * 2));
        // little shapes running around the ring
        int orb = (int) f(M, "orbiters");
        for (int i = 0; i < orb; i++) {
            double ang = rot * 1.3 + i * Math.PI * 2 / Math.max(1, orb);
            shape(ix(M, "shape"), b.x + Math.cos(ang) * radius, gy + 0.12 + 0.05 * Math.sin(time * 3 + i), b.z + Math.sin(ang) * radius,
                0.055f * f(M, "size"), time + i, time * 1.3f + i, time * 0.7f, true, c0, c1, 0.95f, 0.8f, true, f(M, "glow") / 100f, i);
        }
        // light pillars
        if (fl(M, "pillars")) {
            float h = f(M, "pillar_height");
            int n = 22;
            for (int i = 0; i < n; i++) {
                double ang = i * Math.PI * 2 / n + rot * 0.15;
                float flick = 0.55f + 0.45f * (float) Math.sin(time * 2.2 + i * 1.7);
                vband(b.x + Math.cos(ang) * radius, gy, b.z + Math.sin(ang) * radius, h * (0.45f + 0.55f * flick), 0.045f * f(M, "size"),
                    c0, c1, 0.5f * flick, 0f, Mesh.HALO);
            }
        }
    }

    // ---- energy beam

    private void beam(Body b) {
        final String M = "beam";
        float h = f(M, "height"), r = f(M, "radius") * (1f + 0.06f * (float) Math.sin(time * 3f)), spd = f(M, "speed");
        int c0 = col(M, "color", 0f), c1 = col(M, "color2", 0f);
        float a = gOpacity * camFade(b.x, b.y + 1, b.z);
        if (a <= 0.01f) return;
        int sides = 14;
        double rot = time * spd * 0.6;
        double by = b.y - cur.camY;
        for (int pass = 0; pass < 2; pass++) {
            float rad = pass == 0 ? r : r * 0.35f;
            int layer = pass == 0 ? Mesh.HALO : Mesh.GLOW;
            float aBottom = (pass == 0 ? 0.5f : 0.85f) * a * f(M, "glow") / 100f, aTop = 0f;
            int cb = FxShapes.argb(pass == 0 ? c0 : FxShapes.light(c0, 0.6f), aBottom), ct = FxShapes.argb(c1, aTop);
            for (int i = 0; i < sides; i++) {
                double a0 = rot + i * Math.PI * 2 / sides, a1 = rot + (i + 1) * Math.PI * 2 / sides;
                float x0 = (float) (b.x - cur.camX + Math.cos(a0) * rad), z0 = (float) (b.z - cur.camZ + Math.sin(a0) * rad);
                float x1 = (float) (b.x - cur.camX + Math.cos(a1) * rad), z1 = (float) (b.z - cur.camZ + Math.sin(a1) * rad);
                mesh.quad(layer, x0, (float) by, z0, x1, (float) by, z1, x1, (float) by + h, z1, x0, (float) by + h, z0, cb, cb, ct, ct);
            }
        }
        if (fl(M, "rings")) {
            for (int k = 0; k < 3; k++) {
                float u = (time * spd * 0.28f + k / 3f) % 1f;
                groundRing(b.x, b.y + u * h, b.z, r * 1.15f - 0.03f, r * 1.15f, 28, FxShapes.argb(c0, a * 0.8f * (1f - u)), FxShapes.argb(c1, a * 0.8f * (1f - u)), 0f, (float) (Math.PI * 2));
            }
        }
    }

    // ---- helix swirl

    private void helix(Body b) {
        final String M = "ender_swirl";
        int strands = (int) f(M, "strands"), per = (int) f(M, "count");
        float radius = f(M, "radius"), h = f(M, "height"), spd = f(M, "speed"), size = 0.06f * f(M, "size"), twist = f(M, "twist");
        float dir = fl(M, "reverse") ? -1f : 1f;
        int shapeId = ix(M, "shape");
        for (int s = 0; s < strands; s++) {
            for (int j = 0; j < per; j++) {
                float u = (j / (float) per + time * spd * 0.16f) % 1f;
                double ang = dir * time * spd * 1.5 + s * Math.PI * 2 / strands + u * twist * Math.PI * 2;
                float env = (float) Math.sin(Math.PI * u);
                float rad = radius * (0.85f + 0.15f * (float) Math.sin(time * 2 + j));
                int c0 = FxShapes.mix(col(M, "color", 0f), col(M, "color2", 0f), u);
                int c1 = FxShapes.mix(col(M, "color2", 0f), col(M, "color", 0f), u);
                shape(shapeId, b.x + Math.cos(ang) * rad, b.y + 0.05 + u * h, b.z + Math.sin(ang) * rad, size * (0.55f + 0.45f * env),
                    time + j, time * 1.4f + s, time * 0.6f, true, c0, c1, env, 0.75f, true, f(M, "glow") / 100f, j);
            }
        }
    }

    // ---- lightning

    private void lightning(Body b) {
        final String M = "lightning_aura";
        boltClock -= dt;
        int n = Math.max(1, (int) f(M, "bolts"));
        float radius = f(M, "radius");
        if (boltClock <= 0f || bolts.size() != n) {
            boltClock = 0.1f / Math.max(0.3f, f(M, "rate"));
            bolts.clear();
            boolean ground = fl(M, "ground");
            for (int i = 0; i < n; i++) {
                int seg = 7;
                float[] pts = new float[(seg + 1) * 3 + 1];
                double a = rf() * Math.PI * 2;
                double sx = b.x + Math.cos(a) * 0.3, sy = b.y + rr(0.4f, 1.7f), sz = b.z + Math.sin(a) * 0.3;
                double ex, ey, ez;
                if (ground) {
                    ex = b.x + Math.cos(a) * radius * rr(0.5f, 1f);
                    ey = b.y + 0.02;
                    ez = b.z + Math.sin(a) * radius * rr(0.5f, 1f);
                    sy = b.y + rr(2.2f, 3.2f);
                    sx = ex + rr(-0.3f, 0.3f);
                    sz = ez + rr(-0.3f, 0.3f);
                } else {
                    ex = b.x + Math.cos(a) * radius * rr(0.7f, 1.2f);
                    ey = sy + rr(-0.8f, 0.8f);
                    ez = b.z + Math.sin(a) * radius * rr(0.7f, 1.2f);
                }
                for (int j = 0; j <= seg; j++) {
                    float u = j / (float) seg;
                    float jit = j == 0 || j == seg ? 0f : 0.16f;
                    pts[j * 3] = (float) (sx + (ex - sx) * u + rr(-jit, jit));
                    pts[j * 3 + 1] = (float) (sy + (ey - sy) * u + rr(-jit, jit));
                    pts[j * 3 + 2] = (float) (sz + (ez - sz) * u + rr(-jit, jit));
                }
                pts[(seg + 1) * 3] = rr(0.6f, 1f);
                bolts.add(pts);
            }
        }
        int c0 = col(M, "color", 0f), c1 = col(M, "color2", 0f);
        float w = 0.035f * f(M, "thickness") * gSize;
        for (float[] pts : bolts) {
            int seg = (pts.length - 1) / 3 - 1;
            float a = pts[pts.length - 1] * gOpacity;
            for (int j = 0; j < seg; j++) {
                double ax = pts[j * 3], ay = pts[j * 3 + 1], az = pts[j * 3 + 2];
                double bx = pts[j * 3 + 3], by = pts[j * 3 + 4], bz = pts[j * 3 + 5];
                float fade = camFade(ax, ay, az);
                ribbonQuad(ax, ay, az, bx, by, bz, w * 5f, w * 5f, FxShapes.argb(c0, 0.35f * a * fade * f(M, "glow") / 100f), FxShapes.argb(c0, 0.35f * a * fade * f(M, "glow") / 100f), Mesh.HALO);
                ribbonQuad(ax, ay, az, bx, by, bz, w, w, FxShapes.argb(c1, a * fade), FxShapes.argb(c1, a * fade), Mesh.GLOW);
            }
        }
    }

    // ---- slash trail (ribbon behind a swinging weapon)

    private void slashTrail(Body b) {
        final String M = "sword_trail";
        float life = f(M, "duration");
        boolean ok = b.swing > 0f && (!fl(M, "weapon_only") || b.holdingSword);
        if (ok) {
            float u = clamp(b.swing, 0f, 1f);
            float side = b.rightHanded ? 1f : -1f;
            float yawOff = lerp(55f, -55f, u) * side, pitchOff = lerp(-26f, 24f, u);
            double yr = Math.toRadians(b.headYaw + yawOff), pr = Math.toRadians(b.headPitch + pitchOff);
            double dx = -Math.sin(yr) * Math.cos(pr), dy = -Math.sin(pr), dz = Math.cos(yr) * Math.cos(pr);
            double ex = b.firstPerson ? b.camX : b.x, ey = b.firstPerson ? b.camY : b.y + (b.sneaking ? 1.27 : 1.62), ez = b.firstPerson ? b.camZ : b.z;
            float len = f(M, "length");
            slash.add(new double[] {ex + dx * 0.8, ey + dy * 0.8, ez + dz * 0.8, ex + dx * (0.8 + len), ey + dy * (0.8 + len), ez + dz * (0.8 + len), time});
            if (slash.size() > 80) slash.remove(0);
        }
        while (!slash.isEmpty() && time - slash.get(0)[6] > life) slash.remove(0);
        if (slash.size() < 2) return;
        int c0 = col(M, "color", 0f), c1 = col(M, "color2", 0f);
        float width = f(M, "intensity");
        for (int i = 0; i + 1 < slash.size(); i++) {
            double[] p = slash.get(i), q = slash.get(i + 1);
            if (q[6] - p[6] > 0.12) continue; // a gap between two swings
            float a0 = 1f - (time - (float) p[6]) / life, a1 = 1f - (time - (float) q[6]) / life;
            a0 = clamp(a0, 0f, 1f);
            a1 = clamp(a1, 0f, 1f);
            float fade = camFade(p[3], p[4], p[5]) * gOpacity;
            float g = f(M, "glow") / 100f;
            quadWorld(p, q, 0, 3, FxShapes.argb(c1, a0 * 0.15f * fade), FxShapes.argb(c0, a0 * 0.9f * fade * width), FxShapes.argb(c0, a1 * 0.9f * fade * width), FxShapes.argb(c1, a1 * 0.15f * fade), Mesh.GLOW);
            quadWorld(p, q, 0, 3, FxShapes.argb(c1, 0f), FxShapes.argb(c0, a0 * 0.5f * fade * g), FxShapes.argb(c0, a1 * 0.5f * fade * g), FxShapes.argb(c1, 0f), Mesh.HALO);
        }
    }

    /** A quad between the base/tip points of two slash samples (indices of the three coordinates inside the sample arrays). */
    private void quadWorld(double[] p, double[] q, int baseIdx, int tipIdx, int c0, int c1, int c2, int c3, int layer) {
        mesh.quad(layer,
            (float) (p[baseIdx] - cur.camX), (float) (p[baseIdx + 1] - cur.camY), (float) (p[baseIdx + 2] - cur.camZ),
            (float) (p[tipIdx] - cur.camX), (float) (p[tipIdx + 1] - cur.camY), (float) (p[tipIdx + 2] - cur.camZ),
            (float) (q[tipIdx] - cur.camX), (float) (q[tipIdx + 1] - cur.camY), (float) (q[tipIdx + 2] - cur.camZ),
            (float) (q[baseIdx] - cur.camX), (float) (q[baseIdx + 1] - cur.camY), (float) (q[baseIdx + 2] - cur.camZ), c0, c1, c2, c3);
    }

    // ---- rainbow ribbon

    private void rainbowTrail(Body b) {
        final String M = "rainbow_trail";
        float life = f(M, "length");
        if (!haveRib || Math.hypot(b.x - lastRibX, b.z - lastRibZ) > 0.07) {
            if (moving || !haveRib) {
                ribbon.add(new double[] {b.x, b.y, b.z, time});
                lastRibX = b.x;
                lastRibZ = b.z;
                haveRib = true;
                if (ribbon.size() > 160) ribbon.remove(0);
            }
        }
        while (!ribbon.isEmpty() && time - ribbon.get(0)[3] > life) ribbon.remove(0);
        if (ribbon.size() < 2) return;
        float width = f(M, "width") * 0.5f, h = f(M, "height");
        boolean vertical = ix(M, "style") == 1;
        int n = ribbon.size();
        for (int i = 0; i + 1 < n; i++) {
            double[] p = ribbon.get(i), q = ribbon.get(i + 1);
            double dx = q[0] - p[0], dz = q[2] - p[2];
            double len = Math.hypot(dx, dz);
            if (len < 1e-5 || len > 1.5) continue;
            double sx = -dz / len, sz = dx / len;
            float a0 = clamp(1f - (time - (float) p[3]) / life, 0f, 1f), a1 = clamp(1f - (time - (float) q[3]) / life, 0f, 1f);
            float fade = camFade(p[0], p[1] + h, p[2]) * gOpacity;
            int ca = col(M, "color", (float) (p[3] * 0.25)), cb = col(M, "color", (float) (q[3] * 0.25));
            int ca2 = col(M, "color2", (float) (p[3] * 0.25)), cb2 = col(M, "color2", (float) (q[3] * 0.25));
            float g = f(M, "glow") / 100f;
            for (int pass = 0; pass < 2; pass++) {
                int layer = pass == 0 ? Mesh.GLOW : Mesh.HALO;
                float k = pass == 0 ? 0.85f : 0.5f * g;
                float wk = pass == 0 ? 1f : 1.6f;
                int c0 = FxShapes.argb(ca, a0 * k * fade), c1 = FxShapes.argb(cb, a1 * k * fade);
                int d0 = FxShapes.argb(ca2, a0 * k * fade), d1 = FxShapes.argb(cb2, a1 * k * fade);
                if (vertical) {
                    float hh = width * wk;
                    mesh.quad(layer, (float) (p[0] - cur.camX), (float) (p[1] + h - cur.camY), (float) (p[2] - cur.camZ),
                        (float) (q[0] - cur.camX), (float) (q[1] + h - cur.camY), (float) (q[2] - cur.camZ),
                        (float) (q[0] - cur.camX), (float) (q[1] + h + hh * 2 - cur.camY), (float) (q[2] - cur.camZ),
                        (float) (p[0] - cur.camX), (float) (p[1] + h + hh * 2 - cur.camY), (float) (p[2] - cur.camZ), c0, c1, d1, d0);
                } else {
                    mesh.quad(layer, (float) (p[0] + sx * width * wk - cur.camX), (float) (p[1] + h - cur.camY), (float) (p[2] + sz * width * wk - cur.camZ),
                        (float) (q[0] + sx * width * wk - cur.camX), (float) (q[1] + h - cur.camY), (float) (q[2] + sz * width * wk - cur.camZ),
                        (float) (q[0] - sx * width * wk - cur.camX), (float) (q[1] + h - cur.camY), (float) (q[2] - sz * width * wk - cur.camZ),
                        (float) (p[0] - sx * width * wk - cur.camX), (float) (p[1] + h - cur.camY), (float) (p[2] - sz * width * wk - cur.camZ), c0, c1, d1, d0);
                }
            }
        }
    }

    // ---- atmosphere (a field of shapes drifting around the player)

    private void atmosphere(Body b) {
        final String M = "atmosphere";
        int mode = ix(M, "mode");
        float range = f(M, "range"), height = f(M, "height"), size = f(M, "size"), spd = f(M, "speed"), wind = f(M, "wind") / 100f;
        if (b.preview) { // the menu box is small: keep the field inside it and draw the shapes a little larger
            range = Math.min(range, 3.2f);
            height = Math.min(height, 3.4f);
            size *= 2.2f;
        }
        int want = Math.min(MAX_ATM, Math.round(80f * f(M, "amount") / 100f * gAmount));
        while (atmCount < want) {
            int i = atmCount++;
            atmX[i] = b.x + rr(-range, range);
            atmY[i] = b.y + rr(-0.5f, height);
            atmZ[i] = b.z + rr(-range, range);
            atmPhase[i] = rf() * 6.28f;
        }
        if (atmCount > want) atmCount = want;
        int autoShape = switch (mode) {
            case 1 -> FxShapes.SQUARE;
            case 2 -> FxShapes.SQUARE;
            case 3 -> FxShapes.ORB;
            case 5 -> FxShapes.RING;
            case 6 -> FxShapes.PETAL;
            default -> FxShapes.SQUARE;
        };
        int shapeId = FxShapes.resolve(ix(M, "shape"), autoShape);
        float glow = f(M, "glow") / 100f;
        float windX = (float) Math.cos(time * 0.13) * wind, windZ = (float) Math.sin(time * 0.11) * wind;
        double top = b.y + height;
        for (int i = 0; i < atmCount; i++) {
            float ph = atmPhase[i];
            float vx, vy, vz;
            switch (mode) {
                case 1 -> { // snow
                    vx = (float) Math.sin(time * 0.8 + ph) * 0.25f + windX * 1.2f;
                    vy = -0.9f * spd - 0.25f * (ph % 1f);
                    vz = (float) Math.cos(time * 0.7 + ph) * 0.25f + windZ * 1.2f;
                }
                case 2 -> { // embers
                    vx = (float) Math.sin(time * 1.3 + ph) * 0.3f + windX * 1.5f;
                    vy = (0.55f + 0.5f * (ph % 1f)) * spd;
                    vz = (float) Math.cos(time * 1.1 + ph) * 0.3f + windZ * 1.5f;
                }
                case 3 -> { // fireflies wander
                    vx = (float) Math.sin(time * 0.6 + ph * 3) * 0.35f * spd;
                    vy = (float) Math.sin(time * 0.5 + ph * 2) * 0.18f * spd;
                    vz = (float) Math.cos(time * 0.55 + ph * 4) * 0.35f * spd;
                }
                case 4 -> { // rain
                    vx = windX * 2f;
                    vy = -13f * spd;
                    vz = windZ * 2f;
                }
                case 5 -> { // bubbles
                    vx = (float) Math.sin(time * 0.9 + ph) * 0.18f + windX;
                    vy = 0.45f * spd;
                    vz = (float) Math.cos(time * 0.8 + ph) * 0.18f + windZ;
                }
                case 6 -> { // leaves
                    vx = (float) Math.sin(time * 1.1 + ph) * 0.7f + windX * 2f;
                    vy = -0.55f * spd;
                    vz = (float) Math.cos(time * 0.9 + ph) * 0.7f + windZ * 2f;
                }
                case 7 -> { // digital rain
                    vx = 0f;
                    vy = -(2.4f + 2.2f * (ph % 1f)) * spd;
                    vz = 0f;
                }
                default -> { // motes
                    vx = (float) Math.sin(time * 0.7 + ph) * 0.12f + windX * 0.5f;
                    vy = (float) Math.sin(time * 0.9 + ph * 2) * 0.08f;
                    vz = (float) Math.cos(time * 0.6 + ph) * 0.12f + windZ * 0.5f;
                }
            }
            atmX[i] += vx * dt;
            atmY[i] += vy * dt;
            atmZ[i] += vz * dt;
            // wrap around the player so the field follows them
            double ddx = atmX[i] - b.x, ddz = atmZ[i] - b.z;
            if (ddx > range) atmX[i] -= 2 * range; else if (ddx < -range) atmX[i] += 2 * range;
            if (ddz > range) atmZ[i] -= 2 * range; else if (ddz < -range) atmZ[i] += 2 * range;
            if (atmY[i] > top) atmY[i] -= height + 0.5; else if (atmY[i] < b.y - 0.5) atmY[i] += height + 0.5;
            double dx = atmX[i] - b.x, dz = atmZ[i] - b.z;
            float edge = 1f - smooth((float) (Math.sqrt(dx * dx + dz * dz) / range - 0.6) / 0.4f);
            float vEdge = smooth((float) (atmY[i] - (b.y - 0.5)) / 0.8f) * (1f - smooth((float) (atmY[i] - (top - 1.0)) / 1.0f));
            float a = edge * vEdge;
            if (a <= 0.02f) continue;
            int c0 = col(M, "color", ph * 0.1f), c1 = col(M, "color2", ph * 0.1f);
            if (mode == 4) {
                vband(atmX[i], atmY[i], atmZ[i], 0.55f * Math.max(0.4f, spd), 0.012f * size, c0, c1, 0.5f * a, 0.05f * a, Mesh.GLOW);
            } else if (mode == 7) {
                for (int k = 0; k < 6; k++) {
                    float ka = a * (1f - k / 6f);
                    shape(FxShapes.SQUARE, atmX[i], atmY[i] + k * 0.13, atmZ[i], 0.035f * size, 0f, 0f, 0f, false,
                        k == 0 ? FxShapes.light(c0, 0.7f) : c0, c1, 0.95f * ka, 0.9f, false, k == 0 ? glow : 0f, ph);
                }
            } else {
                float tw = mode == 3 ? 0.35f + 0.65f * (float) Math.pow(Math.sin(time * 2.3 + ph * 3) * 0.5 + 0.5, 2) : 0.55f + 0.45f * (float) Math.sin(time * 2.0 + ph * 5);
                float s = (mode == 3 ? 0.05f : mode == 1 ? 0.035f : mode == 6 ? 0.07f : mode == 5 ? 0.08f : 0.03f) * size * (0.7f + 0.6f * (ph % 1f));
                shape(shapeId, atmX[i], atmY[i], atmZ[i], s, time * 0.8f + ph, time * 0.6f + ph * 2, time * 1.1f + ph,
                    mode == 1 || mode == 6 || shapeId == FxShapes.CUBE, c0, c1, 0.9f * a * tw, 0.8f, true, glow, ph);
            }
        }
    }

    // ---- hand glow, shoulder wisps, rain cloud

    private void hands(Body b) {
        final String M = "hand_glow";
        int mode = ix(M, "hand");
        int n = mode == 3 ? 2 : 1;
        int orbiters = (int) f(M, "orbiters");
        for (int i = 0; i < n; i++) {
            int side = handSide(M, i);
            handPos(b, side);
            double hx = tmpP[0], hy = tmpP[1], hz = tmpP[2];
            int c0 = col(M, "color", 0f), c1 = col(M, "color2", 0f);
            float pulse = 1f + 0.12f * (float) Math.sin(time * 4f + i);
            float s = 0.07f * f(M, "size") * pulse;
            shape(FxShapes.ORB, hx, hy, hz, s, 0f, 0f, 0f, false, c0, c1, 0.95f, 1f, false, f(M, "glow") / 100f * 1.4f, 0f);
            for (int k = 0; k < orbiters; k++) {
                double ang = time * f(M, "speed") * 3.2 + k * Math.PI * 2 / orbiters + i;
                float r = 0.17f * f(M, "size");
                shape(ix(M, "shape"), hx + Math.cos(ang) * r, hy + Math.sin(ang * 0.7) * r * 0.5, hz + Math.sin(ang) * r, s * 0.45f,
                    (float) ang, (float) ang * 1.3f, 0f, true, c1, c0, 0.9f, 0.8f, true, 0.5f, k);
            }
        }
    }

    private void wisps(Body b) {
        final String M = "shoulder_wisp";
        for (int side : wispSides(M)) {
            wispPos(b, M, side);
            int c0 = col(M, "color", 0f), c1 = col(M, "color2", 0f);
            float s = 0.075f * f(M, "size");
            shape(FxShapes.ORB, tmpP[0], tmpP[1], tmpP[2], s, 0f, 0f, 0f, false, c0, c1, 0.95f, 1f, false, f(M, "glow") / 100f * 1.4f, 0f);
        }
    }

    private void cloud(Body b) {
        final String M = "rain_cloud";
        double cy = b.y + 2.35 + f(M, "height") + 0.06 * Math.sin(time * 1.4);
        float a = 0.8f * gOpacity * camFade(b.x, cy, b.z);
        if (a <= 0.01f) return;
        int c0 = col(M, "cloud", 0f);
        float[][] puffs = {{0f, 0f, 0f, 0.5f}, {0.32f, -0.03f, 0.1f, 0.38f}, {-0.3f, -0.02f, -0.08f, 0.4f}, {0.08f, 0.1f, -0.18f, 0.32f}, {-0.12f, 0.06f, 0.2f, 0.3f}};
        for (float[] p : puffs) {
            float bob = (float) Math.sin(time * 1.2 + p[0] * 5) * 0.02f;
            mesh.push();
            mesh.translate((float) (b.x - cur.camX) + p[0], (float) (cy - cur.camY) + p[1] + bob, (float) (b.z - cur.camZ) + p[2]);
            mesh.box(Mesh.SOLID, 0f, 0f, 0f, p[3], p[3] * 0.6f, p[3], FxShapes.argb(c0, a));
            mesh.pop();
        }
    }
}
