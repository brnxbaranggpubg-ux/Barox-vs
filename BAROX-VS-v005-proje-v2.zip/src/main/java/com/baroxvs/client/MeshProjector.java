package com.baroxvs.client;

import java.util.Arrays;

/**
 * Turns a {@link Mesh} into depth sorted, lit, screen space triangles. Used by the 3D preview in the menu
 * (the game draws the result with plain GUI triangles) and by the offline renders of the tests.
 * Pure Java: no Minecraft types.
 */
final class MeshProjector {
    /** Screen space vertices of the output triangles: 6 floats per triangle. */
    float[] xy = new float[0];
    /** Vertex colours of the output triangles: 3 ARGB ints per triangle. */
    int[] argb = new int[0];
    /** Layer (Mesh.SOLID / GLOW / HALO) of every output triangle. */
    byte[] layer = new byte[0];
    /** Number of output triangles, sorted far to near. */
    int count;

    private long[] keys = new long[0];
    private float[] depth = new float[0];
    // view of the last project() call, used by point()
    private float pCyaw = 1f, pSyaw, pCp = 1f, pSp, pScale = 1f, pOx, pOy, pCx, pCy, pCz;

    /** Projects one model space point with the view of the last {@link #project} call. out = {x, y} in screen pixels. */
    void point(float x, float y, float z, float[] out) {
        float px = x - pCx, py = y - pCy, pz = z - pCz;
        float x1 = px * pCyaw + pz * pSyaw, z1 = -px * pSyaw + pz * pCyaw;
        float y2 = py * pCp - z1 * pSp;
        out[0] = pOx + x1 * pScale;
        out[1] = pOy - y2 * pScale;
    }

    /**
     * @param yaw    rotation around the vertical axis in radians; 0 looks at the model from behind
     * @param pitch  tilt of the camera in radians; positive looks from above
     * @param scale  pixels per block
     * @param ox     screen x of the model centre
     * @param oy     screen y of the model centre
     * @param cx,cy,cz model space point that is placed on (ox, oy)
     */
    void project(Mesh m, float yaw, float pitch, float scale, float ox, float oy, float cx, float cy, float cz) {
        int cap = m.count * 2;
        if (xy.length < cap * 6) {
            xy = new float[cap * 6];
            argb = new int[cap * 3];
            layer = new byte[cap];
            keys = new long[cap];
            depth = new float[cap];
        }
        float cyaw = (float) Math.cos(yaw), syaw = (float) Math.sin(yaw);
        float cp = (float) Math.cos(pitch), sp = (float) Math.sin(pitch);
        pCyaw = cyaw; pSyaw = syaw; pCp = cp; pSp = sp; pScale = scale; pOx = ox; pOy = oy; pCx = cx; pCy = cy; pCz = cz;
        // light direction in view space: up, slightly to the right and towards the viewer
        float lx = 0.35f, ly = 0.75f, lz = 0.56f;
        float ll = (float) Math.sqrt(lx * lx + ly * ly + lz * lz);
        lx /= ll; ly /= ll; lz /= ll;

        float[] sx = new float[4], sy = new float[4], sz = new float[4];
        int tris = 0;
        for (int q = 0; q < m.count; q++) {
            if (m.back[q]) continue;
            for (int v = 0; v < 4; v++) {
                float x = m.pos[q * 12 + v * 3] - cx, y = m.pos[q * 12 + v * 3 + 1] - cy, z = m.pos[q * 12 + v * 3 + 2] - cz;
                float x1 = x * cyaw + z * syaw, z1 = -x * syaw + z * cyaw;
                float y2 = y * cp - z1 * sp, z2 = y * sp + z1 * cp;
                sx[v] = ox + x1 * scale;
                sy[v] = oy - y2 * scale;
                sz[v] = z2;
            }
            float nx = m.nrm[q * 3], ny = m.nrm[q * 3 + 1], nz = m.nrm[q * 3 + 2];
            float nx1 = nx * cyaw + nz * syaw, nz1 = -nx * syaw + nz * cyaw;
            float ny2 = ny * cp - nz1 * sp, nz2 = ny * sp + nz1 * cp;
            int lyr = m.layer[q];
            float light = 1f;
            if (lyr == Mesh.SOLID) {
                float d = nx1 * lx + ny2 * ly + nz2 * lz;
                light = 0.55f + 0.45f * Math.max(0f, d);
            }
            boolean degenerate = sx[3] == sx[2] && sy[3] == sy[2] && sz[3] == sz[2];
            int[] c = new int[4];
            for (int v = 0; v < 4; v++) c[v] = lit(m.col[q * 4 + v], light);
            tris = emit(tris, lyr, sx[0], sy[0], sx[1], sy[1], sx[2], sy[2], (sz[0] + sz[1] + sz[2]) / 3f, c[0], c[1], c[2]);
            if (!degenerate) tris = emit(tris, lyr, sx[0], sy[0], sx[2], sy[2], sx[3], sy[3], (sz[0] + sz[2] + sz[3]) / 3f, c[0], c[2], c[3]);
        }
        count = tris;
        // far (small z) first
        for (int i = 0; i < tris; i++) keys[i] = ((long) sortable(depth[i]) << 32) | (i & 0xFFFFFFFFL);
        Arrays.sort(keys, 0, tris);
        float[] oxy = new float[tris * 6];
        int[] oc = new int[tris * 3];
        byte[] ol = new byte[tris];
        for (int i = 0; i < tris; i++) {
            int src = (int) (keys[i] & 0xFFFFFFFFL);
            System.arraycopy(xy, src * 6, oxy, i * 6, 6);
            System.arraycopy(argb, src * 3, oc, i * 3, 3);
            ol[i] = layer[src];
        }
        System.arraycopy(oxy, 0, xy, 0, tris * 6);
        System.arraycopy(oc, 0, argb, 0, tris * 3);
        System.arraycopy(ol, 0, layer, 0, tris);
    }

    private int emit(int t, int lyr, float x0, float y0, float x1, float y1, float x2, float y2, float z, int c0, int c1, int c2) {
        xy[t * 6] = x0; xy[t * 6 + 1] = y0; xy[t * 6 + 2] = x1; xy[t * 6 + 3] = y1; xy[t * 6 + 4] = x2; xy[t * 6 + 5] = y2;
        argb[t * 3] = c0; argb[t * 3 + 1] = c1; argb[t * 3 + 2] = c2;
        layer[t] = (byte) lyr;
        depth[t] = z;
        return t + 1;
    }

    private static int lit(int c, float f) {
        return Colors.argb(Colors.a(c), Math.round(Colors.r(c) * f), Math.round(Colors.g(c) * f), Math.round(Colors.b(c) * f));
    }

    /** Maps a float to an int that sorts the same way. */
    private static int sortable(float f) {
        int bits = Float.floatToIntBits(f);
        return bits ^ ((bits >> 31) & 0x7FFFFFFF);
    }
}
