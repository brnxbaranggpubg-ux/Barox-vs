package com.baroxvs.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.registry.Registries;

/**
 * Draws the 3D cosmetics (wings, halo, crown, tail ...) on your own player. It is an ordinary feature renderer,
 * like the cape or the elytra layer, and it only ever draws on the local player: other players never see it.
 */
final class CosmeticFeature extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {
    // The meshes are indexed by frame: 0 = feet, 1 = body, 2 = head (CosmeticModels.FEET/BODY/HEAD) and 3 = wings.
    private static final int WINGS = 3;
    private static final Mesh[] MESHES = {new Mesh(), new Mesh(), new Mesh(), new Mesh()};
    private static final MeshRenderer RENDERER = new MeshRenderer();
    private static final CosmeticModels.Anim ANIM = new CosmeticModels.Anim();
    private static float activity;

    CosmeticFeature(FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel> context) {
        super(context);
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, PlayerEntityRenderState state,
                       float limbAngle, float limbDistance) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null || state.id != player.getId() || state.invisible || player.isSpectator()) return;
        BaroxConfig config = BaroxVsClient.config();

        CosmeticModels.Anim anim = ANIM;
        anim.time = state.age / 20f;
        anim.sneaking = state.sneaking;
        anim.airborne = !player.isOnGround() && !player.isTouchingWater();
        float target = anim.airborne ? 1f : (float) Math.min(1.0, player.getVelocity().horizontalLength() * 7.0);
        activity += (target - activity) * 0.12f;
        anim.activity = activity;

        boolean any = false;
        for (Mesh mesh : MESHES) mesh.clear();
        for (ModuleCatalog.Module module : ModuleCatalog.all()) {
            if (!module.model3d() || !config.isOn(module.id())) continue;
            String id = module.id();
            int slot;
            if (id.equals("wings")) {
                if (config.flag("wings", "hide_elytra") && wearsElytra(player)) continue;
                slot = WINGS;
            } else {
                slot = CosmeticModels.frameOf(id);
            }
            CosmeticModels.build(id, MESHES[slot], config, anim);
            any = true;
        }
        if (!any) return;

        PlayerEntityModel model = this.getContextModel();
        for (int slot = 0; slot < MESHES.length; slot++) {
            Mesh mesh = MESHES[slot];
            if (mesh.count == 0) continue;
            matrices.push();
            if (slot == CosmeticModels.FEET) {
                matrices.translate(0f, CosmeticModels.NECK, 0f);
            } else if (slot == CosmeticModels.HEAD) {
                model.head.rotate(matrices);
            } else {
                model.body.rotate(matrices);
            }
            boolean fullbright = slot == WINGS && config.flag("wings", "fullbright");
            RENDERER.draw(mesh, matrices, vertexConsumers, light, fullbright);
            matrices.pop();
        }
    }

    private static boolean wearsElytra(ClientPlayerEntity player) {
        return Registries.ITEM.getId(player.getEquippedStack(EquipmentSlot.CHEST).getItem()).getPath().equals("elytra");
    }
}
