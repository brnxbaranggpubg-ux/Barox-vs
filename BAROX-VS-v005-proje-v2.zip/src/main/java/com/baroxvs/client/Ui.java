package com.baroxvs.client;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;

import java.util.Locale;

/** Small drawing helpers shared by the HUD and the ClickGUI. Uses DrawContext primitives and plain GUI triangles. */
final class Ui {
    private Ui() {}

    static final int WHITE = 0xFFFFFFFF;
    static final int MUTED = 0xFFA3A8B3;
    static final int DIM = 0xFF6F7480;
    static final int PANEL = 0xD00C0D12;

    // ---------------------------------------------------------------- colours

    static int alpha(int argb, int a) {
        return (Math.max(0, Math.min(255, a)) << 24) | (argb & 0xFFFFFF);
    }

    /** Multiplies the alpha channel of a colour by m (0..1). */
    static int fade(int argb, float m) {
        return alpha(argb, Math.round((argb >>> 24) * Math.max(0f, Math.min(1f, m))));
    }

    static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = Math.round(((a >>> 24) & 255) + (((b >>> 24) & 255) - ((a >>> 24) & 255)) * t);
        int ar = Math.round(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int ag = Math.round(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int ab = Math.round((a & 255) + ((b & 255) - (a & 255)) * t);
        return (aa << 24) | (ar << 16) | (ag << 8) | ab;
    }

    // ---------------------------------------------------------------- shapes

    /** Filled rectangle with rounded corners of radius r (pixel scanlines, no overlap so alpha stays even). */
    static void roundRect(DrawContext c, int x1, int y1, int x2, int y2, int r, int color) {
        r = Math.min(r, Math.min((x2 - x1) / 2, (y2 - y1) / 2));
        if (r <= 0) {
            c.fill(x1, y1, x2, y2, color);
            return;
        }
        c.fill(x1, y1 + r, x2, y2 - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            c.fill(x1 + inset, y1 + i, x2 - inset, y1 + i + 1, color);
            c.fill(x1 + inset, y2 - i - 1, x2 - inset, y2 - i, color);
        }
    }

    /** Glass panel: a thin accent outline around a dark body. */
    static void panel(DrawContext c, int x1, int y1, int x2, int y2, int accent, int bg, int radius, int outlineAlpha) {
        roundRect(c, x1, y1, x2, y2, radius, alpha(accent, outlineAlpha));
        roundRect(c, x1 + 1, y1 + 1, x2 - 1, y2 - 1, Math.max(0, radius - 1), bg);
    }

    /** Cyber corner marks: four small L shaped brackets just outside the rectangle's corners. */
    static void brackets(DrawContext c, int x1, int y1, int x2, int y2, int len, int color) {
        c.fill(x1 - 1, y1 - 1, x1 + len, y1, color);
        c.fill(x1 - 1, y1 - 1, x1, y1 + len, color);
        c.fill(x2 - len, y1 - 1, x2 + 1, y1, color);
        c.fill(x2, y1 - 1, x2 + 1, y1 + len, color);
        c.fill(x1 - 1, y2, x1 + len, y2 + 1, color);
        c.fill(x1 - 1, y2 - len, x1, y2 + 1, color);
        c.fill(x2 - len, y2, x2 + 1, y2 + 1, color);
        c.fill(x2, y2 - len, x2 + 1, y2 + 1, color);
    }

    static void circle(DrawContext c, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int hw = (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy + r * 0.5)));
            c.fill(cx - hw, cy + dy, cx + hw + 1, cy + dy + 1, color);
        }
    }

    /** Circle whose colour fades from top to bottom, used for theme swatches. */
    static void gradientCircle(DrawContext c, int cx, int cy, int r, int top, int bottom) {
        for (int dy = -r; dy <= r; dy++) {
            int hw = (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy + r * 0.5)));
            c.fill(cx - hw, cy + dy, cx + hw + 1, cy + dy + 1, lerp(top, bottom, (dy + r) / (2f * r)));
        }
    }

    /** Ring outline. progress 0..1 draws an arc clockwise from the top. */
    static void ring(DrawContext c, int cx, int cy, int r, int color, float progress) {
        int steps = Math.max(24, r * 8);
        int n = Math.round(steps * Math.max(0f, Math.min(1f, progress)));
        for (int i = 0; i < n; i++) {
            double a = -Math.PI / 2.0 + Math.PI * 2.0 * i / steps;
            int x = (int) Math.round(cx + Math.cos(a) * r);
            int y = (int) Math.round(cy + Math.sin(a) * r);
            c.fill(x, y, x + 1, y + 1, color);
        }
    }

    /** Right-pointing triangle, h pixels tall. */
    static void triangleRight(DrawContext c, int x, int y, int h, int color) {
        for (int i = 0; i < h; i++) {
            int w = 1 + Math.min(i, h - 1 - i);
            c.fill(x, y + i, x + w, y + i + 1, color);
        }
    }

    /** Left-pointing triangle, h pixels tall. */
    static void triangleLeft(DrawContext c, int x, int y, int h, int color) {
        int full = 1 + (h - 1) / 2;
        for (int i = 0; i < h; i++) {
            int w = 1 + Math.min(i, h - 1 - i);
            c.fill(x + full - w, y + i, x + full, y + i + 1, color);
        }
    }

    /** Small X made of two diagonals, size x size pixels. */
    static void cross(DrawContext c, int x, int y, int size, int color) {
        for (int i = 0; i < size; i++) {
            c.fill(x + i, y + i, x + i + 1, y + i + 1, color);
            c.fill(x + size - 1 - i, y + i, x + size - i, y + i + 1, color);
        }
    }

    /** 7x7 "sliders" glyph: three lines with knobs, the settings icon of a module row. */
    static void slidersIcon(DrawContext c, int x, int y, int color) {
        c.fill(x, y + 1, x + 7, y + 2, fade(color, 0.55f));
        c.fill(x, y + 3, x + 7, y + 4, fade(color, 0.55f));
        c.fill(x, y + 5, x + 7, y + 6, fade(color, 0.55f));
        c.fill(x + 4, y, x + 6, y + 3, color);
        c.fill(x + 1, y + 2, x + 3, y + 5, color);
        c.fill(x + 3, y + 4, x + 5, y + 7, color);
    }

    /** 7x7 category icons drawn from rectangles, so they never depend on font glyphs. */
    static void icon(DrawContext c, int index, int x, int y, int color) {
        switch (index) {
            case 0 -> { // four point star
                c.fill(x + 3, y, x + 4, y + 7, color);
                c.fill(x, y + 3, x + 7, y + 4, color);
                c.fill(x + 1, y + 1, x + 2, y + 2, color);
                c.fill(x + 5, y + 1, x + 6, y + 2, color);
                c.fill(x + 1, y + 5, x + 2, y + 6, color);
                c.fill(x + 5, y + 5, x + 6, y + 6, color);
            }
            case 1 -> { // arrow
                for (int i = 0; i < 7; i++) {
                    c.fill(x, y + i, x + 1 + 2 * Math.min(i, 6 - i), y + i + 1, color);
                }
            }
            case 2 -> { // diamond
                for (int i = 0; i < 7; i++) {
                    int k = Math.min(i, 6 - i);
                    c.fill(x + 3 - k, y + i, x + 4 + k, y + i + 1, color);
                }
            }
            case 3 -> { // framed square
                c.drawBorder(x, y, 7, 7, color);
                c.fill(x + 2, y + 2, x + 5, y + 5, color);
            }
            case 4 -> { // three dots
                c.fill(x, y + 3, x + 2, y + 5, color);
                c.fill(x + 3, y + 3, x + 5, y + 5, color);
                c.fill(x + 6, y + 3, x + 7, y + 5, color);
                c.fill(x, y + 1, x + 7, y + 2, Ui.fade(color, 0.5f));
            }
            default -> circle(c, x + 3, y + 3, 3, color);
        }
    }

    // ---------------------------------------------------------------- 3D preview

    /**
     * Draws the triangles of a {@link MeshProjector} as plain GUI geometry (no textures, vertex colours only), in the
     * current matrix of the context. Triangles are re-wound so they always face the screen, whatever the culling is.
     */
    static void drawProjected(DrawContext ctx, MeshProjector pr) {
        if (pr.count == 0) return;
        Matrix4f matrix = ctx.getMatrices().peek().getPositionMatrix();
        ctx.draw(provider -> {
            VertexConsumer buffer = provider.getBuffer(RenderLayer.getGui());
            for (int t = 0; t < pr.count; t++) {
                float ax = pr.xy[t * 6], ay = pr.xy[t * 6 + 1];
                float bx = pr.xy[t * 6 + 2], by = pr.xy[t * 6 + 3];
                float cx = pr.xy[t * 6 + 4], cy = pr.xy[t * 6 + 5];
                int ca = glow(pr.argb[t * 3], pr.layer[t]);
                int cb = glow(pr.argb[t * 3 + 1], pr.layer[t]);
                int cc = glow(pr.argb[t * 3 + 2], pr.layer[t]);
                float area = (bx - ax) * (cy - by) - (by - ay) * (cx - bx);
                if (area == 0f || Float.isNaN(area)) continue;
                if (area > 0f) { // GUI quads are counter clockwise on screen (y down), i.e. negative area
                    float tx = bx, ty = by;
                    bx = cx;
                    by = cy;
                    cx = tx;
                    cy = ty;
                    int tc = cb;
                    cb = cc;
                    cc = tc;
                }
                buffer.vertex(matrix, ax, ay, 0f).color(ca);
                buffer.vertex(matrix, bx, by, 0f).color(cb);
                buffer.vertex(matrix, cx, cy, 0f).color(cc);
                buffer.vertex(matrix, cx, cy, 0f).color(cc);
            }
        });
    }

    /** The additive glow layer is only approximated in the menu: a little brighter and more transparent. */
    private static int glow(int argb, int layer) {
        if (layer != Mesh.HALO) return argb;
        return Colors.argb(Colors.a(argb) * 3 / 5, Colors.r(argb) + 40, Colors.g(argb) + 40, Colors.b(argb) + 40);
    }

    // ---------------------------------------------------------------- text

    static void text(DrawContext c, TextRenderer tr, String s, int x, int y, int color, float scale, boolean shadow) {
        if (((color >>> 24) & 255) < 8) return;
        if (scale == 1f) {
            c.drawText(tr, s, x, y, color, shadow);
            return;
        }
        MatrixStack m = c.getMatrices();
        m.push();
        m.translate(x, y, 0f);
        m.scale(scale, scale, 1f);
        c.drawText(tr, s, 0, 0, color, shadow);
        m.pop();
    }

    static int width(TextRenderer tr, String s, float scale) {
        return (int) Math.ceil(tr.getWidth(s) * scale);
    }

    static void textRight(DrawContext c, TextRenderer tr, String s, int right, int y, int color, float scale, boolean shadow) {
        text(c, tr, s, right - width(tr, s, scale), y, color, scale, shadow);
    }

    static void textCentered(DrawContext c, TextRenderer tr, String s, int cx, int y, int color, float scale, boolean shadow) {
        text(c, tr, s, cx - width(tr, s, scale) / 2, y, color, scale, shadow);
    }

    /** Shortens a string with "..." so it fits in maxWidth pixels at the given scale. */
    static String fit(TextRenderer tr, String s, int maxWidth, float scale) {
        if (width(tr, s, scale) <= maxWidth) return s;
        String out = s;
        while (out.length() > 1 && width(tr, out + "...", scale) > maxWidth) out = out.substring(0, out.length() - 1);
        return out + "...";
    }

    /** The end of a string that fits in maxWidth pixels (what a text field shows while you type at the end). */
    static String tail(TextRenderer tr, String s, int maxWidth) {
        String out = s;
        while (out.length() > 1 && tr.getWidth(out) > maxWidth) out = out.substring(1);
        return out;
    }

    /** Number with a decimal comma, e.g. 10,84. */
    static String num(double value, int decimals) {
        return String.format(Locale.ROOT, "%." + decimals + "f", value).replace('.', ',');
    }
}
