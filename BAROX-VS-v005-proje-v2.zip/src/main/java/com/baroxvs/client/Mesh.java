package com.baroxvs.client;

import java.util.Arrays;

/**
 * CPU side quad soup used by every 3D cosmetic. Pure Java (no Minecraft types) so the same code
 * builds the models in the game, in the menu preview and in the offline tests.
 *
 * <p>Coordinates are "design space": units are blocks, +X is to the player's left when looking at their
 * back (it does not matter, everything is mirrored), +Y is up and +Z points backwards, away from the face.
 * A small transform stack lets models be built like a skeleton: push, translate, rotate, emit, pop.
 */
final class Mesh {
    /** Lit and alpha blended (no face culling, so the reverse copy of a sheet is skipped). */
    static final int SOLID = 0;
    /** Fullbright and alpha blended, no face culling (neon edges, energy panels). */
    static final int GLOW = 1;
    /** Fullbright and additive, draws only front faces (soft halos): sheets need their reverse copy here. */
    static final int HALO = 2;

    float[] pos = new float[1024 * 12];
    float[] nrm = new float[1024 * 3];
    int[] col = new int[1024 * 4];
    byte[] layer = new byte[1024];
    /** True for the reverse side copy of a double sided sheet (only needed by layers that cull back faces). */
    boolean[] back = new boolean[1024];
    int count;
    private boolean markBack;

    // ---------------------------------------------------------------- transform stack (3x4 affine, row major)

    private final float[][] stack = new float[40][12];
    private int depth;
    private boolean mirrored;
    private final boolean[] mirrorStack = new boolean[40];

    Mesh() { identity(stack[0]); }

    private static void identity(float[] m) {
        Arrays.fill(m, 0f);
        m[0] = 1f;
        m[5] = 1f;
        m[10] = 1f;
    }

    void clear() {
        count = 0;
        markBack = false;
        depth = 0;
        mirrored = false;
        identity(stack[0]);
    }

    void push() {
        System.arraycopy(stack[depth], 0, stack[depth + 1], 0, 12);
        mirrorStack[depth] = mirrored;
        depth++;
    }

    void pop() {
        depth--;
        mirrored = mirrorStack[depth];
    }

    void translate(float x, float y, float z) {
        float[] m = stack[depth];
        m[3] += m[0] * x + m[1] * y + m[2] * z;
        m[7] += m[4] * x + m[5] * y + m[6] * z;
        m[11] += m[8] * x + m[9] * y + m[10] * z;
    }

    void scale(float x, float y, float z) {
        float[] m = stack[depth];
        for (int r = 0; r < 3; r++) {
            m[r * 4] *= x;
            m[r * 4 + 1] *= y;
            m[r * 4 + 2] *= z;
        }
        int negatives = (x < 0 ? 1 : 0) + (y < 0 ? 1 : 0) + (z < 0 ? 1 : 0);
        if ((negatives & 1) == 1) mirrored = !mirrored;
    }

    void scale(float s) { scale(s, s, s); }

    /** Rotation about the local X axis (radians). */
    void rotX(float a) {
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        float[] m = stack[depth];
        for (int r = 0; r < 3; r++) {
            float y = m[r * 4 + 1], z = m[r * 4 + 2];
            m[r * 4 + 1] = y * c + z * s;
            m[r * 4 + 2] = -y * s + z * c;
        }
    }

    /** Rotation about the local Y axis (radians). */
    void rotY(float a) {
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        float[] m = stack[depth];
        for (int r = 0; r < 3; r++) {
            float x = m[r * 4], z = m[r * 4 + 2];
            m[r * 4] = x * c - z * s;
            m[r * 4 + 2] = x * s + z * c;
        }
    }

    /** Rotation about the local Z axis (radians). */
    void rotZ(float a) {
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        float[] m = stack[depth];
        for (int r = 0; r < 3; r++) {
            float x = m[r * 4], y = m[r * 4 + 1];
            m[r * 4] = x * c + y * s;
            m[r * 4 + 1] = -x * s + y * c;
        }
    }

    /**
     * Multiplies the transform by a rotation whose columns are the given axes (right, up, forward, expressed in the
     * current frame). Used to turn a flat shape so it faces a camera.
     */
    void basis(float rx, float ry, float rz, float ux, float uy, float uz, float fx, float fy, float fz) {
        float[] m = stack[depth];
        for (int r = 0; r < 3; r++) {
            float a = m[r * 4], b = m[r * 4 + 1], c = m[r * 4 + 2];
            m[r * 4] = a * rx + b * ry + c * rz;
            m[r * 4 + 1] = a * ux + b * uy + c * uz;
            m[r * 4 + 2] = a * fx + b * fy + c * fz;
        }
    }

    private final float[] tmp = new float[3];
    private final float[] qp = new float[12];
    private final int[] qc = new int[4];

    /** Transforms a local point into design space (result in tmp). */
    private void tf(float x, float y, float z) {
        float[] m = stack[depth];
        tmp[0] = m[0] * x + m[1] * y + m[2] * z + m[3];
        tmp[1] = m[4] * x + m[5] * y + m[6] * z + m[7];
        tmp[2] = m[8] * x + m[9] * y + m[10] * z + m[11];
    }

    /** Local point to design space, for models that need to place things by another part's position. */
    float[] toWorld(float x, float y, float z) {
        tf(x, y, z);
        return new float[]{tmp[0], tmp[1], tmp[2]};
    }

    // ---------------------------------------------------------------- emission

    private void grow() {
        int cap = layer.length * 2;
        pos = Arrays.copyOf(pos, cap * 12);
        nrm = Arrays.copyOf(nrm, cap * 3);
        col = Arrays.copyOf(col, cap * 4);
        layer = Arrays.copyOf(layer, cap);
        back = Arrays.copyOf(back, cap);
    }

    /** Appends every quad of another mesh as it is (layers, normals, colours and back flags are copied). */
    void append(Mesh src) {
        while (count + src.count > layer.length) grow();
        System.arraycopy(src.pos, 0, pos, count * 12, src.count * 12);
        System.arraycopy(src.nrm, 0, nrm, count * 3, src.count * 3);
        System.arraycopy(src.col, 0, col, count * 4, src.count * 4);
        System.arraycopy(src.layer, 0, layer, count, src.count);
        System.arraycopy(src.back, 0, back, count, src.count);
        count += src.count;
    }

    /** One quad with per-vertex colours; vertices are given counter clockwise as seen from the front. */
    void quad(int lyr, float x0, float y0, float z0, float x1, float y1, float z1,
              float x2, float y2, float z2, float x3, float y3, float z3, int c0, int c1, int c2, int c3) {
        if (count == layer.length) grow();
        float[] p = qp;
        tf(x0, y0, z0); p[0] = tmp[0]; p[1] = tmp[1]; p[2] = tmp[2];
        tf(x1, y1, z1); p[3] = tmp[0]; p[4] = tmp[1]; p[5] = tmp[2];
        tf(x2, y2, z2); p[6] = tmp[0]; p[7] = tmp[1]; p[8] = tmp[2];
        tf(x3, y3, z3); p[9] = tmp[0]; p[10] = tmp[1]; p[11] = tmp[2];
        int[] c = qc;
        c[0] = c0; c[1] = c1; c[2] = c2; c[3] = c3;
        if (mirrored) { // keep the winding (and so the normal) pointing outwards after a mirror
            swap(p, 3, 9);
            int t = c[1]; c[1] = c[3]; c[3] = t;
        }
        int o = count * 12;
        System.arraycopy(p, 0, pos, o, 12);
        // normal from the diagonals (robust for degenerate triangles, where vertex 3 repeats vertex 2)
        float ax = p[6] - p[0], ay = p[7] - p[1], az = p[8] - p[2];
        float bx = p[9] - p[3], by = p[10] - p[4], bz = p[11] - p[5];
        float nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
        float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (len < 1e-9f) { nx = 0; ny = 1; nz = 0; len = 1; }
        nrm[count * 3] = nx / len;
        nrm[count * 3 + 1] = ny / len;
        nrm[count * 3 + 2] = nz / len;
        System.arraycopy(c, 0, col, count * 4, 4);
        layer[count] = (byte) lyr;
        back[count] = markBack;
        count++;
    }

    private static void swap(float[] p, int a, int b) {
        for (int i = 0; i < 3; i++) {
            float t = p[a + i];
            p[a + i] = p[b + i];
            p[b + i] = t;
        }
    }

    void quad(int lyr, float x0, float y0, float z0, float x1, float y1, float z1,
              float x2, float y2, float z2, float x3, float y3, float z3, int c) {
        quad(lyr, x0, y0, z0, x1, y1, z1, x2, y2, z2, x3, y3, z3, c, c, c, c);
    }

    void tri(int lyr, float x0, float y0, float z0, float x1, float y1, float z1,
             float x2, float y2, float z2, int c0, int c1, int c2) {
        quad(lyr, x0, y0, z0, x1, y1, z1, x2, y2, z2, x2, y2, z2, c0, c1, c2, c2);
    }

    /** Quad visible from both sides (flat sheets such as membranes). */
    void sheet(int lyr, float x0, float y0, float z0, float x1, float y1, float z1,
               float x2, float y2, float z2, float x3, float y3, float z3, int c0, int c1, int c2, int c3) {
        quad(lyr, x0, y0, z0, x1, y1, z1, x2, y2, z2, x3, y3, z3, c0, c1, c2, c3);
        markBack = true;
        quad(lyr, x3, y3, z3, x2, y2, z2, x1, y1, z1, x0, y0, z0, c3, c2, c1, c0);
        markBack = false;
    }

    void sheetTri(int lyr, float x0, float y0, float z0, float x1, float y1, float z1,
                  float x2, float y2, float z2, int c0, int c1, int c2) {
        tri(lyr, x0, y0, z0, x1, y1, z1, x2, y2, z2, c0, c1, c2);
        markBack = true;
        tri(lyr, x2, y2, z2, x1, y1, z1, x0, y0, z0, c2, c1, c0);
        markBack = false;
    }

    // ---------------------------------------------------------------- primitives

    /** Axis aligned box in the local frame, centred on (cx, cy, cz). */
    void box(int lyr, float cx, float cy, float cz, float sx, float sy, float sz, int c) {
        float x0 = cx - sx / 2, x1 = cx + sx / 2, y0 = cy - sy / 2, y1 = cy + sy / 2, z0 = cz - sz / 2, z1 = cz + sz / 2;
        int top = Colors.shade(c, 1.0f), side = Colors.shade(c, 0.82f), end = Colors.shade(c, 0.68f), bottom = Colors.shade(c, 0.55f);
        quad(lyr, x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0, top);          // top (+Y)
        quad(lyr, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, bottom);       // bottom (-Y)
        quad(lyr, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, side);         // back (+Z)
        quad(lyr, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, side);         // front (-Z)
        quad(lyr, x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, end);          // +X
        quad(lyr, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, end);          // -X
    }

    /**
     * Box stretched between two points (bones, edges, beams). w is the width and h the height of the cross section.
     * The colour blends from c0 at the first point to c1 at the second.
     */
    void bar(int lyr, float x0, float y0, float z0, float x1, float y1, float z1, float w, float h, int c0, int c1) {
        float dx = x1 - x0, dy = y1 - y0, dz = z1 - z0;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-6f) return;
        dx /= len; dy /= len; dz /= len;
        // pick a helper axis that is not parallel to the bar
        float hx = 0, hy = 0, hz = 1;
        if (Math.abs(dz) > 0.9f) { hx = 0; hy = 1; hz = 0; }
        float ux = dy * hz - dz * hy, uy = dz * hx - dx * hz, uz = dx * hy - dy * hx;
        float ul = (float) Math.sqrt(ux * ux + uy * uy + uz * uz);
        ux /= ul; uy /= ul; uz /= ul;
        float vx = dy * uz - dz * uy, vy = dz * ux - dx * uz, vz = dx * uy - dy * ux;
        float a = w / 2f, b = h / 2f;
        float[][] ring = new float[4][3];
        float[][] sgn = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
        for (int i = 0; i < 4; i++) {
            ring[i][0] = ux * a * sgn[i][0] + vx * b * sgn[i][1];
            ring[i][1] = uy * a * sgn[i][0] + vy * b * sgn[i][1];
            ring[i][2] = uz * a * sgn[i][0] + vz * b * sgn[i][1];
        }
        for (int i = 0; i < 4; i++) {
            int j = (i + 1) & 3;
            quad(lyr, x0 + ring[i][0], y0 + ring[i][1], z0 + ring[i][2], x0 + ring[j][0], y0 + ring[j][1], z0 + ring[j][2],
                    x1 + ring[j][0], y1 + ring[j][1], z1 + ring[j][2], x1 + ring[i][0], y1 + ring[i][1], z1 + ring[i][2],
                    Colors.shade(c0, i % 2 == 0 ? 0.9f : 0.72f), Colors.shade(c0, i % 2 == 0 ? 0.9f : 0.72f),
                    Colors.shade(c1, i % 2 == 0 ? 0.9f : 0.72f), Colors.shade(c1, i % 2 == 0 ? 0.9f : 0.72f));
        }
        quad(lyr, x0 + ring[3][0], y0 + ring[3][1], z0 + ring[3][2], x0 + ring[2][0], y0 + ring[2][1], z0 + ring[2][2],
                x0 + ring[1][0], y0 + ring[1][1], z0 + ring[1][2], x0 + ring[0][0], y0 + ring[0][1], z0 + ring[0][2], Colors.shade(c0, 0.6f));
        quad(lyr, x1 + ring[0][0], y1 + ring[0][1], z1 + ring[0][2], x1 + ring[1][0], y1 + ring[1][1], z1 + ring[1][2],
                x1 + ring[2][0], y1 + ring[2][1], z1 + ring[2][2], x1 + ring[3][0], y1 + ring[3][1], z1 + ring[3][2], Colors.shade(c1, 0.6f));
    }

    void bar(int lyr, float x0, float y0, float z0, float x1, float y1, float z1, float w, int c) {
        bar(lyr, x0, y0, z0, x1, y1, z1, w, w, c, c);
    }

    /** Square bar whose colour blends from c0 to c1. */
    void bar(int lyr, float x0, float y0, float z0, float x1, float y1, float z1, float w, int c0, int c1) {
        bar(lyr, x0, y0, z0, x1, y1, z1, w, w, c0, c1);
    }

    /**
     * Extrudes a flat polygon (x, y pairs in the local XY plane, star shaped around its centre) along Z.
     * The colour runs from cBase at the smallest x to cTip at the largest x.
     */
    void prism(int lyr, float[] xy, int n, float thick, int cBase, int cTip) {
        float minX = Float.MAX_VALUE, maxX = -Float.MAX_VALUE, cx = 0, cy = 0;
        for (int i = 0; i < n; i++) {
            minX = Math.min(minX, xy[i * 2]);
            maxX = Math.max(maxX, xy[i * 2]);
            cx += xy[i * 2];
            cy += xy[i * 2 + 1];
        }
        cx /= n;
        cy /= n;
        float span = Math.max(1e-5f, maxX - minX);
        float h = thick / 2f;
        int[] cols = new int[n];
        for (int i = 0; i < n; i++) cols[i] = Colors.lerp(cBase, cTip, (xy[i * 2] - minX) / span);
        int cc = Colors.lerp(cBase, cTip, (cx - minX) / span);
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            float ax = xy[i * 2], ay = xy[i * 2 + 1], bx = xy[j * 2], by = xy[j * 2 + 1];
            if (thick > 1e-5f) {
                tri(lyr, cx, cy, h, ax, ay, h, bx, by, h, cc, cols[i], cols[j]);                                  // front (+Z)
                tri(lyr, cx, cy, -h, bx, by, -h, ax, ay, -h, Colors.shade(cc, 0.8f), Colors.shade(cols[j], 0.8f), Colors.shade(cols[i], 0.8f)); // back
                quad(lyr, ax, ay, -h, bx, by, -h, bx, by, h, ax, ay, h, Colors.shade(cols[i], 0.7f), Colors.shade(cols[j], 0.7f),
                        Colors.shade(cols[j], 0.7f), Colors.shade(cols[i], 0.7f));                                  // rim
            } else {
                sheetTri(lyr, cx, cy, 0, ax, ay, 0, bx, by, 0, cc, cols[i], cols[j]);
            }
        }
    }

    /** Flat ring in the local XZ plane (a horizontal washer) with the given radii and height. */
    void ring(int lyr, float inner, float outer, float height, int seg, int cA, int cB) {
        float h = height / 2f;
        for (int i = 0; i < seg; i++) {
            float a0 = (float) (Math.PI * 2 * i / seg), a1 = (float) (Math.PI * 2 * (i + 1) / seg);
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            int ca = Colors.lerp(cA, cB, Math.abs(2f * i / seg - 1f)), cb = Colors.lerp(cA, cB, Math.abs(2f * (i + 1) / seg - 1f));
            quad(lyr, c0 * inner, h, s0 * inner, c0 * outer, h, s0 * outer, c1 * outer, h, s1 * outer, c1 * inner, h, s1 * inner, ca, ca, cb, cb);
            quad(lyr, c1 * inner, -h, s1 * inner, c1 * outer, -h, s1 * outer, c0 * outer, -h, s0 * outer, c0 * inner, -h, s0 * inner,
                    Colors.shade(cb, 0.6f), Colors.shade(cb, 0.6f), Colors.shade(ca, 0.6f), Colors.shade(ca, 0.6f));
            quad(lyr, c1 * outer, -h, s1 * outer, c1 * outer, h, s1 * outer, c0 * outer, h, s0 * outer, c0 * outer, -h, s0 * outer,
                    Colors.shade(cb, 0.85f), Colors.shade(cb, 0.85f), Colors.shade(ca, 0.85f), Colors.shade(ca, 0.85f));
            quad(lyr, c0 * inner, -h, s0 * inner, c0 * inner, h, s0 * inner, c1 * inner, h, s1 * inner, c1 * inner, -h, s1 * inner,
                    Colors.shade(ca, 0.7f), Colors.shade(ca, 0.7f), Colors.shade(cb, 0.7f), Colors.shade(cb, 0.7f));
        }
    }

    /** Flat ring in the XZ plane, visible from both sides, fading from cInner (inner edge) to cOuter (outer edge). */
    void fadeRing(int lyr, float inner, float outer, int seg, int cInner, int cOuter) {
        for (int i = 0; i < seg; i++) {
            float a0 = (float) (Math.PI * 2 * i / seg), a1 = (float) (Math.PI * 2 * (i + 1) / seg);
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            sheet(lyr, c0 * inner, 0, s0 * inner, c0 * outer, 0, s0 * outer, c1 * outer, 0, s1 * outer, c1 * inner, 0, s1 * inner,
                    cInner, cOuter, cOuter, cInner);
        }
    }

    /** Cylinder or cone frustum along +Y from y = 0 (radius rb) to y = height (radius rt), closed with caps. */
    void cylinder(int lyr, float rb, float rt, float height, int seg, int cBottom, int cTop) {
        for (int i = 0; i < seg; i++) {
            float a0 = (float) (Math.PI * 2 * i / seg), a1 = (float) (Math.PI * 2 * (i + 1) / seg);
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            float shade = 0.78f + 0.22f * (float) Math.cos(a0 + 0.9);
            int cb = Colors.shade(cBottom, shade), ct = Colors.shade(cTop, shade);
            quad(lyr, c1 * rb, 0, s1 * rb, c0 * rb, 0, s0 * rb, c0 * rt, height, s0 * rt, c1 * rt, height, s1 * rt, cb, cb, ct, ct);
            if (rt > 1e-5f) tri(lyr, 0, height, 0, c1 * rt, height, s1 * rt, c0 * rt, height, s0 * rt, Colors.shade(cTop, 1.0f), ct, ct);
            if (rb > 1e-5f) tri(lyr, 0, 0, 0, c0 * rb, 0, s0 * rb, c1 * rb, 0, s1 * rb, Colors.shade(cBottom, 0.6f), Colors.shade(cb, 0.7f), Colors.shade(cb, 0.7f));
        }
    }

    /** Regular pyramid with its base in the local XZ plane at y = 0 and the apex at (0, height, 0). */
    void pyramid(int lyr, float radius, float height, int sides, int cBase, int cTip) {
        for (int i = 0; i < sides; i++) {
            float a0 = (float) (Math.PI * 2 * i / sides), a1 = (float) (Math.PI * 2 * (i + 1) / sides);
            float x0 = (float) Math.cos(a0) * radius, z0 = (float) Math.sin(a0) * radius;
            float x1 = (float) Math.cos(a1) * radius, z1 = (float) Math.sin(a1) * radius;
            tri(lyr, x1, 0, z1, x0, 0, z0, 0, height, 0, cBase, cBase, cTip);
            tri(lyr, x0, 0, z0, x1, 0, z1, 0, 0, 0, Colors.shade(cBase, 0.6f), Colors.shade(cBase, 0.6f), Colors.shade(cBase, 0.6f));
        }
    }

    /** Double pyramid (octahedron-like crystal) along the local Y axis. */
    void bipyramid(int lyr, float radius, float up, float down, int sides, int cTop, int cBottom, int cMid) {
        for (int i = 0; i < sides; i++) {
            float a0 = (float) (Math.PI * 2 * i / sides), a1 = (float) (Math.PI * 2 * (i + 1) / sides);
            float x0 = (float) Math.cos(a0) * radius, z0 = (float) Math.sin(a0) * radius;
            float x1 = (float) Math.cos(a1) * radius, z1 = (float) Math.sin(a1) * radius;
            float shade = 0.75f + 0.25f * (float) Math.cos(a0 + 0.6);
            tri(lyr, x1, 0, z1, x0, 0, z0, 0, up, 0, Colors.shade(cMid, shade), Colors.shade(cMid, shade), cTop);
            tri(lyr, x0, 0, z0, x1, 0, z1, 0, -down, 0, Colors.shade(cMid, shade * 0.8f), Colors.shade(cMid, shade * 0.8f), cBottom);
        }
    }

    /** Low poly sphere (icosahedron, optionally split once) centred on the local origin. */
    void sphere(int lyr, float r, int subdivisions, int cTop, int cBottom) {
        float t = (1f + (float) Math.sqrt(5)) / 2f;
        float[][] v = {
            {-1, t, 0}, {1, t, 0}, {-1, -t, 0}, {1, -t, 0}, {0, -1, t}, {0, 1, t}, {0, -1, -t}, {0, 1, -t}, {t, 0, -1}, {t, 0, 1}, {-t, 0, -1}, {-t, 0, 1}
        };
        int[][] f = {
            {0, 11, 5}, {0, 5, 1}, {0, 1, 7}, {0, 7, 10}, {0, 10, 11}, {1, 5, 9}, {5, 11, 4}, {11, 10, 2}, {10, 7, 6}, {7, 1, 8},
            {3, 9, 4}, {3, 4, 2}, {3, 2, 6}, {3, 6, 8}, {3, 8, 9}, {4, 9, 5}, {2, 4, 11}, {6, 2, 10}, {8, 6, 7}, {9, 8, 1}
        };
        for (int[] face : f) {
            float[] a = norm(v[face[0]]), b = norm(v[face[1]]), c = norm(v[face[2]]);
            if (subdivisions <= 0) {
                sphereTri(lyr, a, b, c, r, cTop, cBottom);
            } else {
                float[] ab = norm(mid(a, b)), bc = norm(mid(b, c)), ca = norm(mid(c, a));
                sphereTri(lyr, a, ab, ca, r, cTop, cBottom);
                sphereTri(lyr, b, bc, ab, r, cTop, cBottom);
                sphereTri(lyr, c, ca, bc, r, cTop, cBottom);
                sphereTri(lyr, ab, bc, ca, r, cTop, cBottom);
            }
        }
    }

    private void sphereTri(int lyr, float[] a, float[] b, float[] c, float r, int cTop, int cBottom) {
        int ca = Colors.lerp(cBottom, cTop, a[1] * 0.5f + 0.5f), cb = Colors.lerp(cBottom, cTop, b[1] * 0.5f + 0.5f), cc = Colors.lerp(cBottom, cTop, c[1] * 0.5f + 0.5f);
        tri(lyr, a[0] * r, a[1] * r, a[2] * r, b[0] * r, b[1] * r, b[2] * r, c[0] * r, c[1] * r, c[2] * r, ca, cb, cc);
    }

    private static float[] norm(float[] v) {
        float l = (float) Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        return new float[]{v[0] / l, v[1] / l, v[2] / l};
    }

    private static float[] mid(float[] a, float[] b) { return new float[]{(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2}; }

    // ---------------------------------------------------------------- bounds (tests)

    float[] bounds() {
        float[] b = {Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE};
        for (int i = 0; i < count * 4; i++) {
            for (int k = 0; k < 3; k++) {
                float v = pos[i * 3 + k];
                b[k] = Math.min(b[k], v);
                b[k + 3] = Math.max(b[k + 3], v);
            }
        }
        return b;
    }

    boolean finite() {
        for (int i = 0; i < count * 12; i++) if (Float.isNaN(pos[i]) || Float.isInfinite(pos[i])) return false;
        for (int i = 0; i < count * 3; i++) if (Float.isNaN(nrm[i]) || Float.isInfinite(nrm[i])) return false;
        return true;
    }
}
