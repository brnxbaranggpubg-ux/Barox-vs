package com.baroxvs.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public final class BaroxVsClient implements ClientModInitializer {
    /** One row of the KeyBinds panel. moduleId is null for keys that are not a module switch. */
    public record KeyEntry(String label, KeyBinding key, String moduleId) {}

    private static final BaroxConfig CONFIG = BaroxConfig.load();
    private static final HudRenderer HUD = new HudRenderer(CONFIG);
    private static final List<KeyEntry> KEY_ENTRIES = new ArrayList<>();
    private static KeyBinding openMenuKey;
    private static KeyBinding toggleHudKey;
    private static boolean hudEnabled = true;

    @Override
    public void onInitializeClient() {
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.baroxvs.open_menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                "key.category.baroxvs"));
        toggleHudKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.baroxvs.toggle_hud", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_ALT,
                "key.category.baroxvs"));
        KEY_ENTRIES.add(new KeyEntry("Click GUI", openMenuKey, null));
        KEY_ENTRIES.add(new KeyEntry("HUD", toggleHudKey, null));
        addModuleKey("wings", "Wings", GLFW.GLFW_KEY_Z);
        addModuleKey("aura", "Aura Ring", GLFW.GLFW_KEY_V);
        addModuleKey("hand_glow", "Hand Glow", GLFW.GLFW_KEY_B);
        addModuleKey("sky_aura", "Aura Sky", GLFW.GLFW_KEY_N);

        // 3D cosmetics: one more feature renderer on the player model (draws on your own player only)
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((entityType, entityRenderer, registrationHelper, context) -> {
            if (entityRenderer instanceof PlayerEntityRenderer playerRenderer) {
                registrationHelper.register(new CosmeticFeature(playerRenderer));
            }
        });

        new FxRenderer(CONFIG).register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            HUD.tick(client);
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null && client.player != null) client.setScreen(new BaroxMenuScreen(CONFIG));
            }
            while (toggleHudKey.wasPressed()) {
                hudEnabled = !hudEnabled;
                if (hudEnabled) HUD.toast("HUD", true);
            }
            for (KeyEntry entry : KEY_ENTRIES) {
                if (entry.moduleId() == null) continue;
                while (entry.key().wasPressed()) {
                    if (client.player != null) toggleModule(entry.moduleId());
                }
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (hudEnabled) HUD.render(drawContext, client);
        });
    }

    private static void addModuleKey(String moduleId, String label, int defaultKey) {
        KeyBinding key = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.baroxvs.toggle_" + moduleId, InputUtil.Type.KEYSYM, defaultKey, "key.category.baroxvs"));
        KEY_ENTRIES.add(new KeyEntry(label, key, moduleId));
    }

    /** Flips a module switch, saves it and shows the Enabled / Disabled toast. */
    public static void toggleModule(String id) {
        boolean now = !CONFIG.isOn(id);
        CONFIG.setOn(id, now);
        CONFIG.save();
        ModuleCatalog.Module module = ModuleCatalog.byId(id);
        HUD.toast(module != null ? module.name() : id, now);
    }

    static BaroxConfig config() { return CONFIG; }

    public static List<KeyEntry> keyEntries() { return KEY_ENTRIES; }

    public static KeyBinding openMenuKey() { return openMenuKey; }
}
